var app = angular.module("app", ['ngRoute','ngResource','ngJSONPath']);
app.config(function($routeProvider){
    $routeProvider        
         .when("/loginUser",{
        	templateUrl: "./loginUser.html",
        	controller: 'codeScanningCtrl'
        }).when("/adminUser",{
        	templateUrl: "./adminUser.html",
        	controller: 'adminUserCtrl'
        })
        .when("/apiscan",{
        	templateUrl: "./apiscan.html"
        })
        .when("/selectAPIsource",{
        	templateUrl: "./selectAPIsource.html",
        	controller: 'codeScanningCtrl'
        })
        .when("/scanReport",{
        	templateUrl: "./scanReport.html",
        	controller: 'reportController'
        }).when("/remediate",{
        	templateUrl: "./UpdateVulnerabilityRule.html",
        	controller: 'remediateCtrl'
        })
        .when('/report',{
        	templateUrl: "./scanReport.html",
        	controller: 'reportController'
           
        }).when("/policydetails",{
        	templateUrl: "./policydetails.html",
        	controller: 'policydetailsCtrl'
        }).when('/error',{
        	templateUrl: "./appError.html",
        	controller: 'errorCtrl'           
        }).otherwise({			
        	template: "",
        	controller: 'authenticationCtrl',
		});;        
});

app
.controller(
		'applicationCtrl',
		[
				'$scope',
				'$http',
				'$window','$location','apiAppService',
				function($scope, $http, $window,$location,apiAppService) {
					$scope.checkProjectRemediated = function(pageUrl) {
						var projectRemediate=apiAppService.projectRemediate;						
						if(projectRemediate=="true"){							
							var req = {
									method : 'POST',
									url : './isAPIProxyChanged',
									headers : {
										'Content-Type' : undefined
									},
									params : {}
								}
								$http(req)
										.then(function(
														response) {											
											var json = JSON
											.parse(JSON
													.stringify(response.data));
											if (json["result"] == "exist") {
												if(document.getElementById("validation_successMsg")!=null){
													document.getElementById("validation_successMsg").innerHTML = "Changes found in APIProxy, Rescan your project.";
												}												
											} else {						
												if (json["isProjectDownloaded"] == "true") {													
													apiAppService.setProjectRemediate("false");//Setting this flag in apiAppService, which is used while loggingOut/moving to any menus for showing 'Project Remediated dialog message'
														$location.path('/'+pageUrl);
														if(pageUrl=="loginUser"){
															disableAllMenu();
														}																											
												}else{
													if(pageUrl.includes("scanReport")){														
														apiAppService.setEnableUpdatePolicyBtn("false"); //Enabling Remediate button to solve Remeidate button disabling issue
														$location.path('/'+pageUrl);
													}else
														showMessageDialog("Your project is remediated. Please download the project, otherwise your changes will get lost.");
												}																	
											}
										},
										function(error) {														
											showMessageDialog("Could not check project remediate.");
										});							
						}else{							
							if(pageUrl=="loginUser"){
								disableAllMenu();
							}
							if(pageUrl=="scanReport"){
								$scope.loadPrvPage();
							}
							$location.path('/'+pageUrl);
						}															
					};
					
					$scope.loadPrvPage=function(){
						apiAppService.setShowPreviousReportTab("true");												
						apiAppService.setReportJson("");						
						apiAppService.setEnableUpdatePolicyBtn("true");						
						apiAppService.setIsProjectScanned(false);
					}										
					
					$scope.logoutAPIApp = function(checkProjectRemediated) {
						if(checkProjectRemediated==true){
							var projectRemediate=apiAppService.projectRemediate;						
							if(projectRemediate=="true"){														
								var req = {
										method : 'POST',
										url : './isProjectRemediated',
										headers : {
											'Content-Type' : 'text/plain'
										},
										params : {}
									}
									$http(req)
											.then(function(
															response) {																												
														var logoutStatus=response.data;
														if(logoutStatus=="Success"){															
																disableAllMenu();															
																apiAppService.setProjectRemediate("false");//Setting this flag in apiAppService, which is used while loggingOut/moving to any menus for showing 'Project Remediated dialog message'
																$scope.logout();
														}else{
															showMessageDialog("Your project is remediated. Please download the project, otherwise your changes will get lost.");
														}
													},
													function(error) {														
														showMessageDialog("Could not check project remediate.");
													});
							}else{							
								disableAllMenu();				
								$scope.logout();
							}
						}else{							
							disableAllMenu();			
							$scope.logout();
						}																					
					};
					
					$scope.logout = function() {
						var req = {
								method : 'POST',
								url : './logout',
								headers : {
									'Content-Type' : "text/plain"
								},
								params : {}
							}
							$http(req)
									.then(function(
													response) {																												
										if(response.data!="index"){
												$window.location.href = response.data;
										}else{
											$location.path("/"+response.data);
										}
											},
											function(error) {														
												showMessageDialog("Could not logout application.");
											});																				
					};					
					
					$scope.downloadAPIProxy = function() {
						var projectZipFileName="Project";
						$http.post("./fetchProjectName",{"headers" : {
							'Content-Type' : 'text/plain'
						}}).then(function (response) {projectZipFileName=response.data;});
						
						
						var config = { responseType: 'blob' }
						var httpPromise=$http.post("./downloadAPIProxy",{"headers" : {
							'Content-Type' : undefined
						}}, config);
						httpPromise.then(function (response) {							
							var blob = new Blob([response.data], { type: 'application/octet-stream' });
					        var link = document.createElement('a');
					        link.href = window.URL.createObjectURL(blob);
					        link.download = projectZipFileName+".zip";

					        document.body.appendChild(link);

					        link.click();

					        document.body.removeChild(link);
						},function (error){showMessageDialog("Could not download project.");});
						
						
					};
				}]);

app
.controller(
		'authenticationCtrl',
		[
				'$scope',
				'$http',
				'$window','$location','apiAppService',
				function($scope, $http, $window,$location,apiAppService) {
					$http.post("/checkUserAccess",{headers:{"Content-Type":"text/plain"}})
			        .success(function (response) {
			            var userRole = response;
			            if(userRole!="error" && userRole!="index"){
			            	enableAllMenu();
			            	apiAppService.setUserRole(userRole.toLowerCase());
			            	if(userRole.toLowerCase()!="user"){								
								$location.path('/adminUser');
								document.getElementById("adminMenuId").style.display="block";
							}else{
								$location.path('/apiscan');
								document.getElementById("adminMenuId").style.display="none";
							}
			            }else{
			            	if(userRole=="error"){
			            		apiAppService.setErrorMessage("You are not authorized to access this page.");
			            		disableAllMenu();
			            		$("#loginLinkId").addClass('disableMenu');
			            		$location.path("/error");
			            	}else
			            		$location.path("/loginUser");
			            }			            
			        })
			        .error(function () {
			        	apiAppService.setErrorMessage("You are not authorized to access this page.");
	            		disableAllMenu();
	            		$("#loginLinkId").addClass('disableMenu');
	            		$location.path("/error");
			         });
				}]);
app
.controller(
		'errorCtrl',
		[
				'$scope',
				'$http',
				'$window','$location','apiAppService',
				function($scope, $http, $window,$location,apiAppService) {
					$scope.errorMessage=apiAppService.errorMessage;
				}]);