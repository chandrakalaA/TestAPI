app
		.controller(
				'reportController',
				[
						'$scope',
						'$http',
						'$window','$location','apiAppService','$route',
						function($scope, $http, $window,$location,apiAppService,$route) {
							document.getElementById("reportTab_msg_div_id").style.display="none";
							var obj = apiAppService.reportJson; //Fetching JsonReport content from previous page via angularService
							
							// The value will be passing from PreviousReport page to enable/disable UpdatePolicy button for the Report.							
							var enableUpdatePolicyBtn = apiAppService.enableUpdatePolicyBtn; //Fetching value via AngularService
							
							var isProjectScanned = apiAppService.isProjectScanned;
							
							document.getElementById("loader").style.display = "none";														
							
							$scope.arrow = [];	
							$scope.critical = 0;
							$scope.high = 0;
							$scope.medium = 0;
							$scope.low = 0;
							var x = document.getElementById("reportTab_dashboard");							
							if(obj!=undefined && obj!=""){ 
								//obj contains report json, if obj.length==0 means the user might have not scanned the project and he is directly trying to check the Reports page.
								//If the user did not scan any project and if he is trying to check any previous report's dashboard then all these buttons should be disabled.
								if (isProjectScanned != null
										&& isProjectScanned != "undefined" && isProjectScanned != undefined) {
									if (isProjectScanned == "true") {
										document.getElementById("downloadProjectBtnId").disabled=false;
										document.getElementById("downloadPdfBtnId").disabled=false;										
									} else {
										document.getElementById("downloadProjectBtnId").disabled=true;
									}
								}else{
									document.getElementById("downloadProjectBtnId").disabled=true;
								}																
								var result = JSON.parse(obj);								
																
								x.style.display="block";
								if(result.reportTO!=null && result.reportTO!="" && result.reportTO!=undefined && result.reportTO!='undefined'){
									$scope.projectName = result.reportTO.projectId;
									$scope.currentDate = result.reportTO.lastUpdatedDate;
									$scope.totalPolicyNo = result.reportTO.totalPolicyScanned;
									$scope.totalAvailablePolicy = result.reportTO.totalSecurityPoliciesAvailable;
									$scope.totalAPIScanned = result.reportTO.totalAPIScanned;
									$scope.versionId = result.reportTO.versionId;
									
									$scope.critical = result.reportTO.critical;
									$scope.high = result.reportTO.high;
									$scope.medium = result.reportTO.medium;
									$scope.low = result.reportTO.low;
								}
								
								if(result.apiMappingOWASP!=null && result.apiMappingOWASP!="" && result.apiMappingOWASP!=undefined && result.apiMappingOWASP!='undefined'){
									//MappingOWASP
									$scope.injection = result.apiMappingOWASP.injection;
									$scope.meslog = result.apiMappingOWASP.insufficientLoggingMonitoring;
									$scope.brokenAuth = result.apiMappingOWASP.brokenAuthentication;
									$scope.sesnitiveDataExpo = result.apiMappingOWASP.sensitiveDataExposure;
									$scope.xmlExtEntity = result.apiMappingOWASP.xmlExternalEntity;
									$scope.brokenAcess = result.apiMappingOWASP.brokenAcessControl;

									$scope.crossSiteScrpt = result.apiMappingOWASP.crossSiteScripting; 
									$scope.insecureDesr = result.apiMappingOWASP.insecureDeserialization;
								}					
								
								
								if(result.policyMap!=null && result.policyMap!="null" && result.policyMap!="" && result.policyMap!=undefined && result.policyMap!='undefined'){
									$scope.policyMap=result.policyMap;									
								}
								if(result.policyGroupTotalList!=null && result.policyGroupTotalList!="null" && result.policyGroupTotalList!="" && result.policyGroupTotalList!=undefined && result.policyGroupTotalList!='undefined'){
									$scope.policyGroupTotalList=result.policyGroupTotalList;									
								}								
							}else{
								x.style.display="none";
								document.getElementById("downloadProjectBtnId").disabled=true;
								document.getElementById("downloadPdfBtnId").disabled=true;								
							}

							$scope.errVisibility = true;

							//load arrow										               
							$scope.loadArrow = function(trendsList, index) {
								var countArrayb = [ 'data1' ];
								var countArrayl = [ 'data2' ];
								var countArrayv = [ "x" ];
											
								if(trendsList.length>0){
									if (trendsList.length == 1) {
										$scope.arrow[index] = null;
									} else {
										for (j = 0; j < 2; j++) {
											countArrayb[j + 1] = trendsList[j].vulCount;
											countArrayl[j + 1] = trendsList[j].vulCount;
											countArrayv[j + 1] = trendsList[j].lastUpdated;														
										}
				
										if (countArrayb[1] == countArrayb[2]) {
											$scope.arrow[index] = null;				
										} else if (countArrayb[1] < countArrayb[2]) {
											$scope.arrow[index] = true;		
										} else {
											$scope.arrow[index] = false;
										}			
									}
								}
							};
										
							// load trends																				
							$scope.loadTrends = function(trendsListForProject,index, prevReportRowData, moreDetailsClicked) {
								var trendsList=trendsListForProject;
								var barWidth=600;
								if(moreDetailsClicked){
									reportList=Array.from(trendsListForProject);
									if(reportList.length>0 && prevReportRowData.lastUpdated!=null){
										var arrayIndex=reportListFromSelectedRow(reportList, prevReportRowData);
										if(arrayIndex!=""){
											if(arrayIndex==0){
												reportList.splice(0,1);
											}else{
												reportList.splice(0,arrayIndex);
											}										
										}																			
									}
									trendsList=reportList;
								}																											
								var trendsListLength=trendsList.length;
								if(trendsList.length>8){//Fetching only last 8 scanned details in graph, if it has more than 8 scans then taking only upto 8.
									trendsListLength=8;
								}																																	
								var countArrayb = [ 'No. of Vulnerability' ];
								var countArrayl = [ 'No. of Vulnerability ' ];
								var countArrayv = [ "x" ]
								var indx = 1;
								for (i = (trendsListLength) - 1; i >= 0; i--) {
									countArrayb[indx] = trendsList[i].vulCount;
									countArrayl[indx] = trendsList[i].vulCount;
									countArrayv[indx] = trendsList[i].lastUpdated;
									indx = indx + 1;
								}
								// trend chart creation
								if(trendsListLength==5){
									barWidth=550;
								}else if(trendsListLength==4){
									barWidth=450;
								}else if(trendsListLength==3){
									barWidth=350;
								}else if(trendsListLength==2){
									barWidth=250;
								}else if(trendsListLength==1){
									barWidth=150;
								}else{
									barWidth=600;
								}
								var chart = c3.generate({
									size : {
										height : 280,
										width : barWidth
									},
									// bindto:document.getElementById('chart'+index),
									bindto : document
											.getElementById('trendChartDivId'),
									data : {
										x : 'x',
										columns : [ countArrayv, countArrayb,
												countArrayl ],
										type : 'bar',
										types : {
											'No. of Vulnerability ' : 'line',
										}
									},tooltip: {
								        grouped: false // Default true
								    },
									legend : {
										hide : true
									},
									bar : {
										width : {
											ratio : 0.4
										// this makes bar width 50% of length
										// between ticks
										}
									},
									axis : {
										x : {
											label : {
												text : '',
												position : 'outer-right'
											},
											type : 'category',
											tick : {
												multiline : true,
												width : 60
											},
										},
										y : {
											label : {
												text : 'No of vulnerability',
												position : 'outer-middle'
											}
										},
									}
								});
								document.getElementById("trendGraphDialog").style.display = "block";
							};

							$scope.downloadVariable = function() {
								var link = document.createElement("a");
								link.download = "scanningreport.json";
								var data = "text/json;charset=utf-8,"
										+ encodeURIComponent(JSON.stringify(
												$scope.codeScanningResults,
												null, '\t'));
								link.href = "data:" + data;
								link.click();
							};

							/* Code for Previous Report */							
							$scope.prevReportList = "";

							var updatePolicyBtn=document.getElementById("updatePolicyBtnId");
							if(updatePolicyBtn!=null){
								if (enableUpdatePolicyBtn != null
										&& enableUpdatePolicyBtn != "undefined" && enableUpdatePolicyBtn != undefined) {
									if (enableUpdatePolicyBtn == "true") {
										document
												.getElementById("updatePolicyBtnId").disabled = true;
									} else {
										document
												.getElementById("updatePolicyBtnId").disabled = false;
									}
								} else {
									document.getElementById("updatePolicyBtnId").disabled = true;
								}
							}							
							
							$scope.loadPreviousReports = function() {
								document.getElementById("downloadPdfBtnId").disabled=true;
								var xpr = document.getElementById("reportTab_dashboard");
								xpr.style.display="none";
								document.getElementById("reportTab_msg_div_id").style.display="none";
								
								var req = {
									method : 'POST',
									url : './loadPreviousReports',
									headers : {
										'Content-Type' : undefined
									}
								}
								var checkCurrReport = true;
								$http(req)
										.then(
												function(response) {
													var prevReportList = response.data;
													if (prevReportList.length > 0) {
														$scope.prevReportList = prevReportList;
														$scope.currentdate= prevReportList[0].lastUpdated;
														if(obj!=undefined && obj!=""){ //obj contains report json, if obj.length==0 means the user might have not scanned the project and he is directly trying to check the Reports page.
															//If the user did not scan any project and if he is trying to check any previous report's dashboard then all these buttons should be disabled.
															if (isProjectScanned != null
																	&& isProjectScanned != "undefined") {
																if (isProjectScanned == "true") {
																	prevReportList[0].previousReportList[0].prevReportName = "Current Report"; // Making first record's LastUpdate as Current Report.
																}
															}
														}
																																										
														for (i = 0; i < prevReportList.length; i++) {
															prevReportList[i].previousReportRowData=prevReportList[i].previousReportList[0];
															//Loading Upward/Downward Arrow for each project based on comparing last 2 LastUpdated dates
															$scope.loadArrow(prevReportList[i].previousReportList,i);
														}
													} else {
														document.getElementById("demo").innerHTML = 'No reports available for this user';
													}
												},
												function(error) {
													showMessageDialog("Could not fetch Previous Reports.");
												});

							};																					
							
							$scope.showPrevReportDetails = function(prevReport) {
								document.getElementById("downloadPdfBtnId").disabled=false;
								var reportContentJson="";
								if(prevReport.lastUpdated != null){
									if (prevReport.prevReportName == "Current Report") {// Disabling										
										apiAppService.setEnableUpdatePolicyBtn("false");
									} else {										
										apiAppService.setEnableUpdatePolicyBtn("true");
									}
								}
								if(prevReport.reportLocation!=null && prevReport.reportLocation.length>0){
									var req = {
											method : 'POST',
											url : './fetchReportContent',
											headers : {
												'Content-Type' : 'text/plain'
											},
											params : {"reportLocation" :prevReport.reportLocation}
										}
										$http(req)
												.then(
														function(response) {
															reportContentJson=JSON.stringify(response.data);
															if(reportContentJson.length>0){																																
																apiAppService.setReportJson(reportContentJson);
																$route.reload();
															}
														},
														function(error) {
															showMessageDialog("Could not fetch report details.");
														});									
								}																
							};
							$scope.showTrendForSelectedItem = function(prevReportForProjectList, prevReportRowData, rowIndex) {
								var reportList=Array.from(prevReportForProjectList);								
								if(reportList.length>0 && prevReportRowData.lastUpdated!=null){
									var arrayIndex=reportListFromSelectedRow(reportList, prevReportRowData);
									if(arrayIndex!=""){
										if(arrayIndex==0){
											reportList.splice(0,1);
										}else{
											reportList.splice(0,arrayIndex);
										}										
									}
									if(reportList.length>0){
										$scope.loadArrow(reportList, rowIndex);										
									}									
								}																						
							};
							function reportListFromSelectedRow(reportsList, prevReportRowData){
								var arrayIndex="";							
								for(row=0;row<reportsList.length;row++){
									if(reportsList[row].lastUpdated==prevReportRowData.lastUpdated){
										arrayIndex=row;
										return arrayIndex;
									}
								}
								return arrayIndex;
							}

							$scope.loadUpdatePolicy = function() {
								var req = {
									method : 'POST',
									url : './loadUpdatePolicy',
									headers : {
										'Content-Type' : undefined
									},
									params : {}
								}
								$http(req)
										.then(
												function(response) {
													$location.path('/remediate');
												},
												function(error) {
													showMessageDialog("Could not load Update Policy page.");
												});
							};
							
							function showAdminName() {																
								var userRole=apiAppService.userRole;
								if(userRole!=null && userRole!= 'undefined'){															
									if(userRole=="user"){																
										if (isProjectScanned != null
												&& isProjectScanned != "undefined") {
											if (isProjectScanned == "true") {
												fetchProjectAdminNameForUser(); // Fetching ProjectAdminName for displaying in UI if the User logs-in.
											}
										}																
									}
								}								
							};
							
							function fetchProjectAdminNameForUser() {								
								var req = {
										method : 'POST',
										url : './fetchProjectAdminNameForUser',
										headers : {
											'Content-Type' : 'text/plain'
										},
										params : {}
									}
									$http(req)
											.then(function(
															response) {																												
														var projectAdminName=response.data;
														if(projectAdminName!=null && projectAdminName!= 'undefined'){
															if(projectAdminName.length>0){
																//document.getElementById("projectAdmin_HeadingId").innerHTML="Project Admin - "+projectAdminName;
																document.getElementById("projectAdmin_HeadingId").textContent="Project Admin - "+projectAdminName;
															}																																												
														}
													},
													function(error) {														
														showMessageDialog("Could not fetch Project Admin");
													});
								
							};
							
							$scope.reportenble = function() {
								var rep = document.getElementById("reportTab_dashboard");
								if(obj!=undefined && obj!=""){									
									rep.style.display="block";		
									document.getElementById("downloadPdfBtnId").disabled=false;
									document.getElementById("reportTab_msg_div_id").style.display="none";
								}else{
									rep.style.display="none";
									document.getElementById("reportTab_msg_div_id").style.display="block";
								}
							};
														
							$scope.countOfPoliciesEnabled = function(policyList) {
								var noOfPolicyEnabled=0;
								if(policyList!=undefined){
									angular.forEach(policyList, function (policyDTO) {
								        if (policyDTO.isEnabled)
								        	noOfPolicyEnabled+=1;
								    });
									return noOfPolicyEnabled+'/'+policyList.length;
								}
								return "";
							}
							
							$scope.$on( '$viewContentLoaded' , function(){								
									var fl = apiAppService.showPreviousReportTab;																	
									if(fl=="true" ){
									
									var ele=document.getElementById("home");
									
									ele.classList.remove("active");
									
					var ele2=document.getElementById("menu2");
		
								ele2.classList.add("in");
								ele2.classList.add("active");
																	
									var ele3=document.getElementById("hm");
									ele3.classList.remove("active");
									var ele4=document.getElementById("m2");
									
									ele4.classList.add("active");
																		
									apiAppService.setShowPreviousReportTab("false");
									
								$scope.loadPreviousReports();																	
								}
									
									showAdminName();																		

									if(obj!=undefined && obj!=""){																			
										/*Chart.js*/
										var ctx = document.getElementById("chartContainer");
										var myChart = new Chart(ctx, {
										  type: 'pie',
										  data: {
										    labels: ['Critical', 'High', 'Medium', 'Low'],
										    datasets: [{
//										      label: '# of Tomatoes',
										      data: [$scope.critical, $scope.high, $scope.medium, $scope.low],
										      backgroundColor: [
										        '#FF0000',
										        '#FF8C00',
										        '#4169E1',
										        '#FF69B4'
										      ],										     
										      borderWidth: 2
										    }]
										  },
										  options: {
										   	cutoutPercentage: 60,
										    responsive: true,
										    legend: {
									            display: false
									         },
										    plugins: {
										        labels: {
										        	render: 'percentage',
										            fontColor: 'white',
										            fontSize: 14,
										            precision: 2,
										            fontStyle: 'bold'
										        }
										    }
										  }
										});
										
									}

					        } );

						} ]);

app.filter('previousReportTableFilter',
		function() {
			return function(dataArray, searchTerm) {
				// If no array is given, exit.
				if (!dataArray) {
					return;
				}
				// If no search term exists, return the array unfiltered.
				else if (!searchTerm) {
					return dataArray;
				}
				// Otherwise, continue.
				else {
					// Convert filter text to lower case.
					var term = searchTerm.toLowerCase();
					var searchBy = document
							.getElementById('prevReportFilterCriteria').value;
					if (searchBy.length > 0) {
						// Return the array and filter it by looking for any
						// occurrences of the search term in each items id or
						// name.
						return dataArray.filter(function(item) {
							if (item[searchBy] != 'undefined') {
								var projectId = item[searchBy].toLowerCase()
										.indexOf(term) > -1;
								return projectId;
							} else {
								return dataArray;
							}
						});
					} else {
						return dataArray;
					}
				}
			}
		});
app
		.directive(
				'policyTotalRepeatDirective',
				function() {
					return function($scope, element, attrs) {
						if ($scope.$last) {
							// The below code will be executed once the ng-repeat view is rendered
							// Below code is for moving the needle in the speedometer based on policyGroup total value.
							$scope
									.$evalAsync(function() {
										var policyGroupTotalList = $scope.policyGroupTotalList;
										if (policyGroupTotalList != undefined
												&& policyGroupTotalList.length > 0) {
											for (var policyRow = 0; policyRow < policyGroupTotalList.length; policyRow++) {
												var policyGroupTotal = policyGroupTotalList[policyRow].policyGroupTotal;
												speedometer(
														policyGroupTotal,
														policyGroupTotalList[policyRow].policyGroupName,
														policyRow);
											}
										}
									});
						}

					}
				});

function speedometer(policyGroupTotal, policyGroupName, index) {	
	var obj=$('#speedometer'+'_'+index);
		var speedometerDiv = obj.attr('chart-data');
		var value=0;
		if(speedometerDiv==policyGroupName){
			value=policyGroupTotal;
		}				
		if (value > 100 && value < 1000) {
			value = (value / 10);
		} else if (value > 1000 && value < 10000) {
			value = (value / 100);
		} else if (value > 10000 && value < 100000) {
			value = (value / 1000);
		}
		obj.find('.speedometer_handler').css({
			'transform' : 'rotate(' + (value * 1.8) + 'deg)'
		});
}