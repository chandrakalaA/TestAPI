app.directive('fileModel', [ '$parse', function($parse) {
	return {
		restrict : 'E',
		link : function(scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function() {
				scope.$apply(function() {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
} ]);

app.controller('usersController', function($scope) {
	$scope.headingTitle = "User List";
});

app
		.controller(
				'codeScanningCtrl',
				[
						'$location',
						'$window',
						'$http',
						'$scope',
						'$q',
						'apiAppService',
						'jsonPath',
						'myfactory',
						function($location, $window, $http, $scope, $q,
								apiAppService, jsonPath, myfactory) {														
							document.getElementById("loader").style.display = "none";
							
							$scope.init = function() {								
								disableAllMenu();
							};
							
							//Fetching list of ProjectNames for the logged-in user based on their role
							$http.get("./fetchProjectsForUser").then(
									function(response) {
										$scope.projectList = response.data;
									});

							$scope.dataUpload = true;
							$scope.errVisibility = false;
							$scope.codeScanningResults;
							$scope.authentication;
							$scope.inputvalidation;
							$scope.loggingAuditing;
							$scope.authenticationValue;
							$scope.loggingValue;
							$scope.inputvalidationValue;
							$scope.result;
							$scope.clear = function() {
								$scope.codeScanningResults = "";
								$scope.authentication = "";
								$scope.inputvalidation = "";
								$scope.loggingAuditing = "";
								$scope.authenticationValue = "";
								$scope.loggingValue = "";
								$scope.inputvalidationValue = "";
								document.getElementById("file").value = "";
								document.getElementById("gitUrl").value = "";
								document.getElementById("folderID").value = "";
								document.getElementById("username").value = "";
								document.getElementById("password").value = "";
							}

							// var me = $scope;
							$scope.downloadVariable = function() {
								var link = document.createElement("a");
								link.download = "scanningreport.json";
								var data = "text/json;charset=utf-8,"
										+ encodeURIComponent(JSON.stringify(
												$scope.codeScanningResults,
												null, '\t'));
								link.href = "data:" + data;
								link.click();
							};

							$scope.loginSubmit = function() {
								var username = $('#inputUser').val();
								var password = $('#password').val();
								$http({
									method : "GET",
									url : "./login",
									params : {
										"username" : username,
										"password" : password
									}
								})
										.then(
												function successCallback(
														response) {
													var json = JSON
															.parse(JSON
																	.stringify(response.data));
													if (json["result"] != "Fail") {														
														enableAllMenu();
														var userRole=json["result"];
														if(userRole!=null && userRole!= 'undefined'){
															apiAppService.setUserRole(userRole.toLowerCase());
															if(userRole.toLowerCase()!="user"){																																
																$location.path('/adminUser');
																document.getElementById("adminMenuId").style.display="block";
															}else{
																$location.path('/apiscan');
																document.getElementById("adminMenuId").style.display="none";
															}															
														}else{
															$location.path('/apiscan');
															document.getElementById("adminMenuId").style.display="none";
														}														
													} else {
														showMessageDialog("Incorrect Credentials");  

													}
													myfactory.set(username);
												},
												function errorCallback(response) {
													showMessageDialog("Incorrect Credentials");  
												});

							}
							
							/* Git Url */
							$scope.downloadGitProject = function() {
								var projectId="";
								var projectName="";								
								if($scope.adminUserDTO!=null && $scope.adminUserDTO!='undefined'){
									projectId=$scope.adminUserDTO.projectId;
									projectName=$scope.adminUserDTO.projectName;
								}

								document.getElementById("loader").style.display = "block";
								var gitUrl = $('#gitUrl').val();
								var username = $('#username').val();
								var password = $('#password').val();
								var folder = $('#folderID').val();
								
								var projectNameWithZip=projectName;
								if(folder!=null && folder!='undefined'){
									if(folder.includes(".zip")){
										projectNameWithZip=projectName+".zip";
									}
									if(folder != projectNameWithZip){
										showMessageDialog("You are not authorized to upload this project ! Please select the correct project.");
										document.getElementById("loader").style.display = "none";
									}else{
										$http({
											method : "GET",
											url : "./gitupload",
											params : {
												"gitUrl" : gitUrl,
												"username" : username,
												"password" : password,
												"folder" : folder,
												"projectId" : projectId
											}
										})
												.then(
														function successCallback(
																response) {															
															var result = response.data;
															myfactory.set(response);
															var output = response.data;
															
															var json_git = response.data;
															if (json_git["errorMsg"] == "error in shared flow") {
																var filename = json_git["errorMsgfilepath"];
																showMessageDialog("Please upload shared flow bundle"+filename);
															
																//showMessageDialog("Please upload shared flow bundle.");
																document
																.getElementById("loader").style.display = "none"; 
																document.getElementById("whole_div").style.display = 'none';
																document.getElementById("shared_div_git").style.display = 'block';
																}
															else {
															
															apiAppService.setReportJson(JSON.stringify(response.data));

															$scope.errVisibility = true;
															
															apiAppService.setEnableUpdatePolicyBtn("false"); //Enabling Remediate button to solve Remeidate button disabling issue
															
															apiAppService.setIsProjectScanned("true");
															$location.path('/scanReport');
														}},
														function errorCallback(response) {
															document
																	.getElementById("loader").style.display = "none";
															$scope.codeScanningResults = "";
															$scope.authentication = "";
															$scope.inputvalidation = "";
															$scope.loggingAuditing = "";
															$scope.authenticationValue = "";
															$scope.loggingValue = "";
															$scope.inputvalidationValue = "";
															document
																	.getElementById("file").value = "";
															showMessageDialog("Please select valid proxy bundle.");

														});
									}
								}																															
							}
							
							
							
							$scope.downloadGitProjectshared = function() {
								var projectId="";
								var projectName="";								
								if($scope.adminUserDTO!=null && $scope.adminUserDTO!='undefined'){
									projectId=$scope.adminUserDTO.projectId;
									projectName=$scope.adminUserDTO.projectName;
								}

								document.getElementById("loader").style.display = "block";
								var gitUrl = $('#gitUrlshared').val();
								var username = $('#usernameshared').val();
								var password = $('#passwordshared').val();
								var folder = $('#folderIDshared').val();
								
								var projectNameWithZip=projectName;
								if(folder!=null && folder!='undefined'){
									if(folder.includes(".zip")){
										projectNameWithZip=projectName+".zip";
									}
									/*if(folder != projectNameWithZip){
										showMessageDialog("You are not authorized to upload this project ! Please select the correct project.");
										document.getElementById("loader").style.display = "none";
									}else{*/
										$http({
											method : "GET",
											url : "./gituploadshared",
											params : {
												"gitUrl" : gitUrl,
												"username" : username,
												"password" : password,
												"folder" : folder,
												"projectId" : projectId
											}
										})
												.then(
														function successCallback(
																response) {															
															var result = response.data;
															myfactory.set(response);
															var output = response.data;
															
															var json_git = response.data;
															if (json_git["errorMsg"] == "error in shared flow") {
																var filename = json_git["errorMsgfilepath"];
																showMessageDialog("Please upload shared flow bundle"+filename);
															
																//showMessageDialog("Please upload shared flow bundle.");
																document
																.getElementById("loader").style.display = "none"; 
																document.getElementById("whole_div").style.display = 'none';
																document.getElementById("shared_div_git").style.display = 'block';
																}
															else {
															
															apiAppService.setReportJson(JSON.stringify(response.data));

															$scope.errVisibility = true;
															
															apiAppService.setEnableUpdatePolicyBtn("false"); //Enabling Remediate button to solve Remeidate button disabling issue
															
															apiAppService.setIsProjectScanned("true");
															$location.path('/scanReport');
														}},
														function errorCallback(response) {
															document
																	.getElementById("loader").style.display = "none";
															$scope.codeScanningResults = "";
															$scope.authentication = "";
															$scope.inputvalidation = "";
															$scope.loggingAuditing = "";
															$scope.authenticationValue = "";
															$scope.loggingValue = "";
															$scope.inputvalidationValue = "";
															document
																	.getElementById("file").value = "";
															showMessageDialog("Please select valid proxy bundle.");

														});
									//}
								}																															
							}
							
													
															
							
							$scope.uploadFile = function() {
								document.getElementById("loader").style.display = "block";
								var file = document.getElementById('file').files[0];
										
								if(file!=undefined){
									
									var filename=document.getElementById('file').files[0].name;
																		
									var projectId="";
									var projectName="";
									if($scope.adminUserDTO!=null && $scope.adminUserDTO!='undefined'){
										projectId=$scope.adminUserDTO.projectId;
										projectName=$scope.adminUserDTO.projectName;
									}

									if(filename.includes(".zip")){
										if(projectName.length>0){
											var projectNameWithZip=projectName+".zip";
											if(filename != projectNameWithZip){
												showMessageDialog("You are not authorized to upload this project ! Please select the correct project.");
												document.getElementById("loader").style.display = "none";
											}else{
												//If User uploading the same project then allow them to upload and scan the project
												var uploadUrl = "./upload";
												apiAppService
														.uploadFileToUrl(file, uploadUrl,projectId, projectName)
														.then(
																function(result) {
																//	var json = JSON.parse(result.data);
																	var json = result.data;
																	if (json["errorMsg"] == "error in shared flow") {
																		var filename = json["errorMsgfilepath"];
																		showMessageDialog("Please upload shared flow bundle"+filename);
																		//showMessageDialog("Please upload shared flow bundle.");
																		document
																		.getElementById("loader").style.display = "none";
																		document.getElementById("whole_div").style.display = 'none';
																		document.getElementById("shared_div").style.display = 'block';
																$scope.codeScanningResults = "";
																$scope.authentication = "";
																$scope.inputvalidation = "";
																$scope.loggingAuditing = "";
																$scope.authenticationValue = "";
																$scope.loggingValue = "";
																$scope.inputvalidationValue = "";
																	    
																	} else{
																		myfactory.set(result);
																		var output = result.data;																	

																		$scope.errVisibility = true;
																		
																		apiAppService.setEnableUpdatePolicyBtn("false"); //Enabling Remediate button to solve Remeidate button disabling issue
																		
																		apiAppService.setIsProjectScanned("true");
																		
																		apiAppService.setReportJson(JSON.stringify(result.data));
																		$location.path('/scanReport');
																	}
																	
																},
																function(error) {
																	document
																			.getElementById("loader").style.display = "none";
																	$scope.codeScanningResults = "";
																	$scope.authentication = "";
																	$scope.inputvalidation = "";
																	$scope.loggingAuditing = "";
																	$scope.authenticationValue = "";
																	$scope.loggingValue = "";
																	$scope.inputvalidationValue = "";
																	

																	document
																			.getElementById("file").value = "";																	
																	showMessageDialog("Please select valid proxy bundle.");

																})
											}
										}else{
											showMessageDialog("Please select project.");
											document.getElementById("loader").style.display = "none";
										}
								}else{
									showMessageDialog("Please select zip only");
									document
									.getElementById("loader").style.display = "none";
								}
								}else{
									showMessageDialog("Please upload your project to scan");
									document
									.getElementById("loader").style.display = "none";
								}															
							};
							
							
							
							$scope.uploadSharedFile = function() {
								document.getElementById("loader").style.display = "block";
								var file = document.getElementById('file1').files[0];
								if(file!=undefined){
									var filename=document.getElementById('file1').files[0].name;
												
										if(filename.includes(".zip")){
																				
												var uploadUrl = "./uploadsharedflow";
												apiAppService
														.uploadFileToUrl(file, uploadUrl,projectId)
														.then(
																function(result) {
																//	var json = JSON.parse(result.data);
																	var json = result.data;
																	//var json1=resultstmt.data;
																	if (json["errorMsg"] == "error in shared flow") {
																	var filename = json["errorMsgfilepath"];
																		showMessageDialog("Please upload shared flow bundle"+filename);// +json[errorMsgfilepath]
																		document
																		.getElementById("loader").style.display = "none";
																$scope.codeScanningResults = "";
																$scope.authentication = "";
																$scope.inputvalidation = "";
																$scope.loggingAuditing = "";
																$scope.authenticationValue = "";
																$scope.loggingValue = "";
																$scope.inputvalidationValue = "";
																	    
																	} else{
																		myfactory.set(result);
																		var output = result.data;																	

																		$scope.errVisibility = true;
																		
																		apiAppService.setEnableUpdatePolicyBtn("false"); //Enabling Remediate button to solve Remeidate button disabling issue
																		
																		apiAppService.setIsProjectScanned("true");
																		
																		apiAppService.setReportJson(JSON.stringify(result.data));
																		$location.path('/scanReport');
																	}
																	
																},
																function(error) {
																	document
																			.getElementById("loader").style.display = "none";
																	$scope.codeScanningResults = "";
																	$scope.authentication = "";
																	$scope.inputvalidation = "";
																	$scope.loggingAuditing = "";
																	$scope.authenticationValue = "";
																	$scope.loggingValue = "";
																	$scope.inputvalidationValue = "";
																	

																	document
																			.getElementById("file1").value = "";																	
																	showMessageDialog("Please select valid proxy bundle for shared flow.");

																})
											
										
								}else{
									showMessageDialog("Please select zip only");
									document
									.getElementById("loader").style.display = "none";
								}
								}
																						
							};
							
							
							
							
							
							
							
							
							
							
							
							
						} ]);

app.inject = [ 'jsonPath' ];

app.service('apiAppService', [ '$q', '$http', function($q, $http) {	
	var deffered = $q.defer();
	var responseData;
	var reportJson="";
	var userRole="";
	var projectRemediate="false";
	var isProjectScanned="false";
	var enableUpdatePolicyBtn="false";
	var showPreviousReportTab="false";
	var errorMessage="Error.";
	var projectId="";
	var projectName="";
	this.uploadFileToUrl = function(file, uploadUrl,projectId, projectName) {
		var fd = new FormData();
		fd.append('file', file);
		
		//Admin Requirment
		fd.append('projectId', projectId);
		fd.append('projectName', projectName);
		
		return $http.post(uploadUrl, fd, {
			transformRequest : angular.identity,
			headers : {
				'Content-Type' : undefined
			}
		}).success(function(response) {

			responseData = response;

			deffered.resolve(response);
			return deffered.promise;
		}).error(function(error) {
			deffered.reject(error);
			return deffered.promise;
		});
	}
	this.getResponse = function() {
		return responseData;
	}
	
	this.setReportJson = function(reportJson){
		this.reportJson=reportJson;
	}
	this.setUserRole = function(userRole){
		this.userRole=userRole;
	}
	this.setProjectRemediate = function(projectRemediate){
		this.projectRemediate=projectRemediate;
	}
	this.setIsProjectScanned = function(isProjectScanned){
		this.isProjectScanned=isProjectScanned;
	}
	this.setEnableUpdatePolicyBtn = function(enableUpdatePolicyBtn){
		this.enableUpdatePolicyBtn=enableUpdatePolicyBtn;
	}
	this.setShowPreviousReportTab = function(showPreviousReportTab){
		this.showPreviousReportTab=showPreviousReportTab;
	}	
	this.setErrorMessage = function(errorMessage){
		this.errorMessage=errorMessage;
	}
	this.setProjectId = function(projectId){
		this.projectId=projectId;
	}
	this.setProjectName = function(projectName){
		this.projectName=projectName;
	}
} ]);

// singleton factory method

app.factory("myfactory", function() {
	var savedata = {}
	function set(data) {
		savedata = data;
	}
	function get(data) {
		return savedata;
	}
	return {
		set : set,
		get : get
	}
})

app.directive('fileModel', [ '$parse', function($parse) {
	return {
		restrict : 'E',
		link : function(scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function() {
				scope.$apply(function() {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
} ]);
