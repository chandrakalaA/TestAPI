app
		.controller(
				'policydetailsCtrl',
				[
						'$window',
						'$http',
						'$scope','$location','apiAppService',						
						function($window, $http, $scope, $location, apiAppService) {							
							$scope.projectName=apiAppService.projectName;
							$scope.$on( '$viewContentLoaded' , function(){
								$scope.fetchPolicyDetails();
							});
														
							$scope.fetchPolicyDetails = function() {																															
								var req = {
										method : 'POST',
										url : './fetchPolicyDetails',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											projectId:apiAppService.projectId
										}
									}
									$http(req)
											.then(
													function(
															response) {
														$scope.policyMap = response.data;
													},
													function(
															error) {														
														showMessageDialog("Could not fetch users");

													});									
							};
							$scope.onSelectPolicy = function(policyDetailDTO, policyMapIndex) {
								if(!policyDetailDTO.ispolicySelected){
									policyDetailDTO.policyModifiedWeight=0;
								  }else{
									  policyDetailDTO.policyModifiedWeight=policyDetailDTO.policyWeight;
								  }
							};
							$scope.showPolicyDetails = function() {
								$location.path('/policydetails');
							};
							$scope.sum = function(list) {
								  var total=0;
								  angular.forEach(list , function(item){
									  if(item.policyModifiedWeight!=undefined && item.policyModifiedWeight!="" && item.policyModifiedWeight>=0){
										  total+= parseInt(item.policyModifiedWeight);  
									  }else{
										  total+=0;
									  }									   									  
								  });
								  return total;
								 };
							$scope.savePolicyDetails = function(policyMap) {
								var policyGroupList=[];
								angular.forEach($scope.policyMap,function(value, key){						            
									policyGroupList.push(value);
						        });
								$scope.validatePolicies(policyGroupList);								
							};
							
							$scope.readPolicyDetailsFromTableToSave = function(policyGroupList) {
								var req = {
										method : 'POST',
										url : './readPolicyDetailsFromTable',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											policyMap:policyGroupList,
											projectId:apiAppService.projectId
										}
									}
									$http(req)
											.then(
													function(
															response) {
														if(response.data=="success"){
															document.getElementById("validation_successMsg").innerHTML = "Policy details saved successfully";
															window.scrollTo({ top: 0, behavior: 'smooth' });
														}else{
															showMessageDialog("Could not save policy details.");
														}
													},
													function(
															error) {
														showMessageDialog("Could not save policy details.");
													});
							}
							
							$scope.validatePolicies = function(policyGroupList) {								
								var req = {
										method : 'POST',
										url : './validatePolicies',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											policyMap:policyGroupList
										}
									}
									$http(req)
											.then(
													function(
															response) {
														if(response.data=="success"){
															$scope.readPolicyDetailsFromTableToSave(policyGroupList); //Saving policyDetails
															return true;
														}else{
															showMessageDialog(response.data);
															return false;
														}
													},
													function(
															error) {
														showMessageDialog("Could not vaidate policies.");
														return false;
													});
								return true;
							};
							
							$scope.validateModifiedWeight = function(policyDetailDTO) {
								if(policyDetailDTO.ispolicySelected){
									if(policyDetailDTO.policyWeight!=undefined && policyDetailDTO.policyModifiedWeight!=undefined){
										if(policyDetailDTO.policyWeight!="" && policyDetailDTO.policyModifiedWeight!=""){
											if(Number(policyDetailDTO.policyModifiedWeight) < Number(policyDetailDTO.policyWeight)){
												showMessageDialog("Policy Weight should not be less than Default weight.");
											}
										}
									}
								}
								
							};
						}
						]);