app
		.controller(
				'adminUserCtrl',
				[
						'$window',
						'$http',
						'$scope','$location','apiAppService',						
						function($window, $http, $scope, $location, apiAppService) {
							$scope.userRole="";
							$scope.$on( '$viewContentLoaded' , function(){
								var userRole=apiAppService.userRole;
								$scope.userRole=userRole;
								if(userRole!=null && userRole!= 'undefined'){
									if(userRole=="admin"){
										if(document.getElementById("projectAdminDivId")!=null){
											document.getElementById("projectAdminDivId").style.display = 'block';
																						
											var fd = new FormData();
											fd.append('userRole', userRole);
											
											$http.get("./fetchProjectAdmin").then(
													function(response) {
														$scope.projectAdminList = response.data;
													});
											$http.post("./fetchProjectAdminDetails", fd, {
												transformRequest : angular.identity,
												headers : {
													'Content-Type' : undefined
												}
											}).then(
													function(response) {												
														$scope.projectDetailsList = response.data;
													});
										}										
									}else if(userRole=="projectadmin"){
										if(document.getElementById("projectAdminDivId")!=null){
											document.getElementById("projectAdminDivId").style.display = 'none';
											
											var fd = new FormData();
											fd.append('userRole', userRole);
											
											$http.post("./fetchProjectAdminDetails", fd, {
												transformRequest : angular.identity,
												headers : {
													'Content-Type' : undefined
												}
											}).then(
													function(response) {												
														$scope.projectDetailsList = response.data;
													});
										}
										
									}
									
								}
							});
							
							$scope.saveAdminDetails = function() {
								if(validateAdminDetails()){
									if($scope.projectName != null && $scope.projectName.length>0 && $scope.projectType != null && $scope.projectType.length>0){
										var projectAdminId="";
										if($scope.projectAdminDTO!=null && $scope.projectAdminDTO!='undefined'){
											projectAdminId=$scope.projectAdminDTO.projectAdminId;
										}
										
										var req = {
											method : 'POST',
											url : './checkProjectAdminExists',
											headers : {
												'Content-Type' : undefined
											},
											params : {
												projectName : $scope.projectName,
												projectType : $scope.projectType,
												projectAdmin:projectAdminId,
												userRole:$scope.userRole
											}
										}
										$http(req)
												.then(
														function(response) {
															var json = JSON
																	.parse(JSON
																			.stringify(response.data));
															if (json["result"] == "exist") {															
																showMessageDialog("Project already exists.");
															} else {
																saveAdminDetailsToDB(projectAdminId);
															}

														},
														function(error) {
															showMessageDialog("Could not check project exists");

														});
										
										
									}
								}								
							};
							
							function saveAdminDetailsToDB(projectAdminId) {																
								var req = {
										method : 'POST',
										url : './saveAdminDetails',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											projectName:$scope.projectName,
											projectType:$scope.projectType,
											projectAdmin:projectAdminId,
											userRole:$scope.userRole
										}
									}
									$http(req)
											.then(
													function(
															response) {
														$scope.projectDetailsList = response.data;
														if($scope.projectDetailsList.length>0){
															document
															.getElementById("validation_successMsg").innerHTML = "Project details saved successfully";
															
															$scope.projectName="";
															$scope.projectType="";
															document.getElementById("projectAdminId").selectedIndex = "0";
														}else{
															document
															.getElementById("validation_successMsg").innerHTML = "";
														}																												
													},
													function(
															error) {														
														showMessageDialog("Could not save Project details");

													});
							};
							
							$scope.showAdminPage = function() {
								var req = {
										method : 'POST',
										url : './showAdminPage',
										headers : {
											'Content-Type' : 'text/plain'
										},
										params : {}
									}
									$http(req)
											.then(
													function(
															response) {																												
														var userRole=response.data;
														if(userRole!=null && userRole!= 'undefined'){
															if(userRole.toLowerCase()!="user"){																
																apiAppService.setUserRole(userRole.toLowerCase());
																$location.path('/adminUser');
															}															
														}
													},
													function(
															error) {														
														showMessageDialog("Could not open Admin page");

													});
								
							};
							
							$scope.addUser = function(projectId) {
								
								$scope.projectIdForUser=projectId; //Assiging ProjectId to this hidden variable for using on saving the user details
								document.getElementById("validationMsgSave").innerHTML = "";								
								
								$http.get("./fetchUsers").then(
										function(response) {
											$scope.userList = response.data;
										});
								
								var req = {
										method : 'POST',
										url : './fetchProjectUsers',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											projectId:projectId,											
										}
									}
									$http(req)
											.then(
													function(
															response) {
														$scope.projectUserList = response.data;
													},
													function(
															error) {														
														showMessageDialog("Could not fetch users");

													});	
								showManageUserModal();
							};
							
							$scope.viewUser = function(projectId) {
								document.getElementById("ruleFileNameSpanId").innerHTML="View User";
								document.getElementById("validationMsgSave").innerHTML = "";
								document.getElementById("projectUserHeaderDivId").style.display = 'none';
								
								$scope.projectIdForUser=projectId;																
								
								var req = {
										method : 'POST',
										url : './fetchProjectUsers',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											projectId:projectId,											
										}
									}
									$http(req)
											.then(
													function(
															response) {
														$scope.projectUserList = response.data;
													},
													function(
															error) {														
														showMessageDialog("Could not fetch users");

													});	
								showManageUserModal();
							};
							
							$scope.selectAllUser = function () {
								$scope.isAll = !$scope.isAll;
								angular.forEach($scope.projectUserList, function (user) {
							 
									user.rowSelect = $scope.isAll;
								});								
							};							
							
							$scope.deleteUser = function() {
								
									var projectId="";
						            var newDataList=[];
						            var userIdList=[];
						            angular.forEach($scope.projectUserList,function(v){
						            if(v.rowSelect){						                
						                userIdList.push(v.projectUserId);
						                projectId=v.projectId;
						            }else{
						            	newDataList.push(v);
						            }
						        });
								
						        if(userIdList.length>0){
									document.getElementById("validationMsgSave").innerHTML = "";																								
									
									var req = {
											method : 'POST',
											url : './deleteUser',
											headers : {
												'Content-Type' : 'text/plain'
											},
											params : {
												userIdList:userIdList,
												projectId:projectId
											}
										}
										$http(req)
												.then(
														function(
																response) {
															var deleteStatus=response.data;
															if(deleteStatus!='undefined'){
																if(deleteStatus == 'success'){																	
																	$scope.projectUserList=newDataList;
																	document.getElementById("validationMsgSave").innerHTML = "User deleted successfully";																	 																	
																}																
															}															
														},
														function(
																error) {														
															showMessageDialog("Could not delete users");

														});
						        }else{
						        	showMessageDialog("Please select user to delete");
						        }								
							};
							
							$scope.saveUser = function() {								
								var selectedUser=document.getElementById("projectUserId").value;
								if(selectedUser!=undefined && selectedUser.length>0){
									if($scope.adminUserDTO.projectUserId != null && $scope.adminUserDTO.projectUserId.length>0 && $scope.projectIdForUser != null){
										var req = {
												method : 'POST',
												url : './checkUserExists',
												headers : {
													'Content-Type' : undefined
												},
												params : {
													projectId : $scope.projectIdForUser,
													projectUserId : $scope.adminUserDTO.projectUserId
												}
											}
											$http(req)
													.then(
															function(response) {
																var json = JSON
																		.parse(JSON
																				.stringify(response.data));
																if (json["result"] == "exist") {																	
																	showMessageDialog("Cannot add, user already exists for this project");
																} else {
																	saveUserToDB(
																			$scope.projectIdForUser,
																			$scope.adminUserDTO.projectUserId);
																}

															},
															function(error) {
																showMessageDialog("Could not check user exists");

															});
									}else{
										showMessageDialog("Please select user to add.");
									}
								}else{
									showMessageDialog("Please select user to add.");
								}								
							};
							
							function saveUserToDB(projectId, projectUserId){
								var req = {
										method : 'POST',
										url : './saveProjectUser',
										headers : {
											'Content-Type' : undefined
										},
										params : {
											projectId:projectId,
											projectUserId:projectUserId
										}
									}
									$http(req)
											.then(
													function(
															response) {
														$scope.projectUserList = response.data;
														
														document
														.getElementById("validationMsgSave").innerHTML = "User added successfully";
														
														$scope.projectName="";
														$scope.projectType="";
														document.getElementById("projectUserId").selectedIndex = "0";
													},
													function(
															error) {														
														showMessageDialog("Could not add user");

													});
							};
							
							$scope.clear = function() {
								$scope.projectName = "";
								document.getElementById("projectTypeSelectId").value = "";
								document.getElementById("projectAdminId").value = "";
							};
							
							function validateAdminDetails() {								
								if($scope.userRole!=null && $scope.userRole!= 'undefined' && $scope.userRole.length>0){
									if($scope.projectName == null || $scope.projectName==undefined || $scope.projectName.length == 0){
										showMessageDialog("Please enter project name.");
										return false;
									}else if($scope.projectType==null || $scope.projectType==undefined || $scope.projectType.length == 0){
										showMessageDialog("Please select project type.");
										return false;
									}
									if($scope.userRole=="admin"){
										if(document.getElementById("projectAdminId")!=null){
											var projectAdminId=document.getElementById("projectAdminId").value;
											if(projectAdminId==null || projectAdminId=='undefined' || projectAdminId.length==0){
												showMessageDialog("Please select project admin.");
												return false;
											}											
										}										
									}
								}
								return true;
							};
							$scope.showPolicyDetails = function(projectId, projectName) {
								apiAppService.setProjectId(projectId);
								apiAppService.setProjectName(projectName);
								$location.path('/policydetails');
							};
						}
						]);
function showManageUserModal() {	
	document.getElementById('addUserModal').style.display = "block";
}
function closeManageUserDialog() {
	var modal = document.getElementById('addUserModal');	
	modal.style.display = "none";
}