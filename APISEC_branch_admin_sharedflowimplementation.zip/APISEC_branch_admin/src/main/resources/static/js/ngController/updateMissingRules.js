app
		.controller(
				'remediateCtrl',
				[
						'$scope',
						'$http',
						'$window','$location','apiAppService',
						function($scope, $http, $window,$location,apiAppService) {
							apiAppService.setProjectRemediate("true");//Setting this flag in apiAppService, which is used while loggingOut/moving to any menus for showing 'Project Remediated dialog message'
							document.getElementById("loader").style.display = "none";
							$scope.$on( '$viewContentLoaded' , function(){
								loadRemediatePage();
								showAdminName();
							});
							
							$scope.rescanUpdatedProxy = function() {
								document.getElementById("loader").style.display = "block";

								var req = {
									method : 'POST',
									url : './rescanUpdatedProxy',
									headers : {
										'Content-Type' : undefined
									},
									params : {}
								}
								$http(req)
										.then(
												function(response) {
													var jsonResult = response.data;
													if (jsonResult != null) {
														apiAppService.setReportJson(JSON.stringify(jsonResult));
														$location.path('/scanReport');
													} else {														
														document
																.getElementById("validation_successMsg").innerHTML = 'Project not scanned';
														document.getElementById("loader").style.display = "none";
													}
												},
												function(error) {
													document.getElementById("loader").style.display = "none";													
													showMessageDialog("Could not rescan the project.");													
												});
							};
							function showAdminName() {								
								var userRole=apiAppService.userRole;
								if(userRole!=null && userRole!= 'undefined'){															
									if(userRole=="user"){
										fetchProjectAdminNameForUser(); // Fetching ProjectAdminName for displaying in UI if the User logs-in.																										
									}
								}								
							};
							function fetchProjectAdminNameForUser() {								
								var req = {
										method : 'POST',
										url : './fetchProjectAdminNameForUser',
										headers : {
											'Content-Type' : 'text/plain'
										},
										params : {}
									}
									$http(req)
											.then(function(
															response) {																												
														var projectAdminName=response.data;
														if(projectAdminName!=null && projectAdminName!= 'undefined'){
															if(projectAdminName.length>0){
																document.getElementById("projectAdmin_HeadingId").innerHTML="Project Admin - "+projectAdminName;
															}																																												
														}
													},
													function(error) {														
														showMessageDialog("Could not fetch Project Admin");
													});
								
							};
						}]);

function loadRemediatePage(){			
	$(function() {		
		  loadMissedRule();
		  fetchProjectDetails();		  
		});
}

function loadMissedRule() {
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "./showMissedRules",
		dataType : 'json',
		success : function(data) {
			$('#missedRuleTree').jstree({
			    'core' : {
			        'data' : data,
			        check_callback: false
			      }, 
			      checkbox: {       
			          three_state : false, // to avoid that fact that checking a node also check others
			          whole_node : true,  // to avoid checking the box just clicking the node 
			          tie_selection : true // for checking without selecting and selecting without checking
			        },
			      "plugins" : ["checkbox"]
			    });
			loadExistingRule();
						
			$("#missedRuleTree").bind("select_node.jstree", function(evt, data){
				if((data.node.text).indexOf(".")==-1){ // Removing node selection if the user clicks on folder, because multiple folder selection are possible
					data.instance.deselect_node(data.node);
				}				
			});
			
			$("#existingRuleTree").bind("select_node.jstree", function(evt, data){
				if((data.node.text).indexOf(".")==-1){ // Removing node selection if the user clicks on folder, because multiple folder selection are possible
					data.instance.deselect_node(data.node);
				}				
			});
		},
		error : function(e) {
			showMessageDialog("Error in loading missed policies"+e);
		}
	});
}

function loadExistingRule() {
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "./showExistingRules",
		dataType : 'json',
		success : function(data) {
			$('#existingRuleTree').jstree({
			    'core' : {
			        'data' : data
			      },			     
			      removeNode: {
			    	  click : "removeMissedRuleFromExistingRule()"  
			      },
			      editNode: {
			    	  click : "editMissedRuleContent()"  
			      },
			      viewNode: {
			    	  click : "viewExistingRuleContent()"  
			      },
			      "plugins" : ["removeNode", "editNode", "viewNode"]
			    });
			//Displaying uploaded projet structure in the below code
			$('#existingRuleTree_Initial').jstree({
			    'core' : {
			        'data' : data
			      }
			});
		},
		error : function(e) {
			showMessageDialog("Error in loading existing policies"+e);
		}
	});
}

function fetchProjectDetails(){	
	/*fetchProjectDetails*/
	$.ajax({
		type : "POST",		
		url : "./fetchProjectName",
		success : function(response) {
			/*var projectDetailsList = response;
			var projectId;
			if (projectDetailsList.length > 0) {
				projectId = projectDetailsList[0];
			}*/
			var projectId=response;
			document
					.getElementById('projectIdTitle').innerHTML = "Project ID - "
					+ projectId;
		},
		error : function(e) {
			showMessageDialog("Could not fetch project details.");
		}
	});
}

function addMissedRuleToExistingRule() {
	var selectedMissedRulesArray = $("#missedRuleTree").jstree(true).get_selected("full", true);
	var missedRuleIDandName=new Array();
	if(selectedMissedRulesArray!=null && selectedMissedRulesArray.length>0 && selectedMissedRulesArray!='undefined'){
		for(i=0;i<selectedMissedRulesArray.length;i++){
			if(selectedMissedRulesArray[i].text.indexOf(".") > -1){
				missedRuleIDandName.push(selectedMissedRulesArray[i].id+":"+selectedMissedRulesArray[i].text);
			}			
		}		
	}
	if (missedRuleIDandName != null
			&& missedRuleIDandName != "undefined"
			&& missedRuleIDandName.length > 0) {
		
		$.ajax({
			type : "POST",
			url : "./addMissedRuleToExistingRule",
			data : {selectedMissedRulesArray:missedRuleIDandName},
			success : function(response) {				
				var ruleList = response;
				if (ruleList != null
						&& ruleList.length > 0) {
					var highPriorityPolicyFileNames=ruleList[0].highPriorityPolicyFileNames;//Checking if any highpriority policies(jwt, oauth, saml) already exists, if so we need to show the validation
					if (highPriorityPolicyFileNames != null
							&& highPriorityPolicyFileNames.length > 0) {
						document
						.getElementById("validation_successMsg").innerHTML="";						
						
						for(i=0;i<selectedMissedRulesArray.length;i++){													
							var selectedFileName=selectedMissedRulesArray[i].text.toLowerCase();
							if(selectedFileName.indexOf('jwt')!=-1){
								if(highPriorityPolicyFileNames.toLowerCase().indexOf('jwt')!=-1){
									disableMissedRule(selectedMissedRulesArray[i].id);
								}else{																		
									showWarningDialog("Security Policy \""+ruleList[0].highPriorityPolicyFileNames+"\" already Present ,");
								}																									
							} else if(selectedFileName.indexOf('oauth')!=-1){								
								if(highPriorityPolicyFileNames.toLowerCase()==selectedFileName){
									disableMissedRule(selectedMissedRulesArray[i].id);
								}else{									
									showWarningDialog("Security Policy \""+ruleList[0].highPriorityPolicyFileNames+"\" already Present ,");
								}																																
							}/*else if(selectedFileName.indexOf('oauthv1')!=-1){
								if(highPriorityPolicyFileNames.toLowerCase().indexOf('oauth1')!=-1){
									disableMissedRule(selectedMissedRulesArray[i].id);
								}else{									
									showWarningDialog("Security Policy \""+ruleList[0].highPriorityPolicyFileNames+"\" already Present ,");
								}																																
							} else if(selectedFileName.indexOf('oauth-v2')!=-1){
								if(highPriorityPolicyFileNames.toLowerCase().indexOf('oauth2')!=-1){
									disableMissedRule(selectedMissedRulesArray[i].id);
								}else{									
									showWarningDialog("Security Policy \""+ruleList[0].highPriorityPolicyFileNames+"\" already Present ,");
								}																																
							}*/ else if(selectedFileName.indexOf('saml')!=-1){
								if(highPriorityPolicyFileNames.toLowerCase().indexOf('saml')!=-1){
									disableMissedRule(selectedMissedRulesArray[i].id);
								}else{									
									showWarningDialog("Security Policy \""+ruleList[0].highPriorityPolicyFileNames+"\" already Present ,");
								}																														
							}else{
								disableMissedRule(selectedMissedRulesArray[i].id);								
							}							
						}
					} else {																
						document.getElementById("validation_successMsg").innerHTML = 'Policy Added Successfully';
												
						for(i=0;i<selectedMissedRulesArray.length;i++){
							if(selectedMissedRulesArray[i].text.indexOf(".")>-1){ // If selected node is not folder then disabling it, for folder there wont be "." present
								disableMissedRule(selectedMissedRulesArray[i].id);
							}														
						}						
					}
					$('#existingRuleTree').jstree(true).settings.core.data = response;
					$('#existingRuleTree').jstree(true).refresh(true);
				}
			},
			error : function(e) {
				showMessageDialog("Could not add policies.");
			}
		});
	}
}		

	function viewExistingRuleContent() {
		var selectedExistingRulesArray = $("#existingRuleTree").jstree(true).get_selected("full", true);		
		if(selectedExistingRulesArray!=null && selectedExistingRulesArray.length>0 && selectedExistingRulesArray!='undefined'){
			if(selectedExistingRulesArray.length==1){
				var ruleId=selectedExistingRulesArray[0].id;
				var ruleFileName=selectedExistingRulesArray[0].text;
				
				document
				.getElementById("validationMsgSave").innerHTML = "";
				if (ruleFileName.indexOf(".") > -1) {
					if (ruleId != null && ruleId != 'undefined') {
						$.ajax({
							type : "POST",
							url : "./viewExistingRuleContent",
							data : {node : ruleId},
							success : function(data) {
								
								var list = data;
								if (list.length > 0) {
									var value = "";
									for (i = 0; i < list.length; i++) {
										value += list[i]
												+ "\n";
									}
									//document
											//.getElementById('ruleFileNameSpanId').innerHTML = ruleFileName;
									document
									        .getElementById('ruleFileNameSpanId').textContent = ruleFileName;
									document
											.getElementById('editorTextAreaId').value = value;
									document
											.getElementById('myModal').style.display = "block";
									document
											.getElementById('saveFileImgId').style.visibility = "hidden";
								}
							},
							error : function(e) {
								showMessageDialog("Could not open selected policy to view.");
							}
						});
					}
				} else {										
					document.getElementById("validation_successMsg").innerHTML = 'Please select policy to view.';
				}
			}else {									
				document.getElementById("validation_successMsg").innerHTML = 'Cannot view multiple policies.';
			}					
		}else {									
			document.getElementById("validation_successMsg").innerHTML = 'Please select policy to view.';
		}
	}
	
	function closeEditor() {
		var modal = document.getElementById('myModal');
		modal.style.display = "none";
	}
	
	function editMissedRuleContent() {		
		var selectedExistingRulesArray = $("#existingRuleTree").jstree(true).get_selected("full", true);		
		if(selectedExistingRulesArray!=null && selectedExistingRulesArray.length>0 && selectedExistingRulesArray!='undefined'){
			if(selectedExistingRulesArray.length==1){
				var ruleId=selectedExistingRulesArray[0].id;
				var ruleFileName=selectedExistingRulesArray[0].text;
				
				document
				.getElementById("validationMsgSave").innerHTML = "";
				if (ruleFileName.indexOf(".") > -1) {
					if (ruleId != null
							&& ruleId != 'undefined') {
						$.ajax({
							type : "POST",
							url : "./editMissedRuleContent",
							data : {node : ruleId, nodeName : ruleFileName},
							success : function(response) {
								
								var list = response;
								if (list.length > 0) {
									var value = "";
									for (i = 0; i < list.length; i++) {
										value += list[i]
												+ "\n";
									}
									//document
										//	.getElementById('ruleFileNameSpanId').innerHTML = ruleFileName;
									document
									        .getElementById('ruleFileNameSpanId').textContent = ruleFileName;
									document
											.getElementById('editorTextAreaId').value = value;
									document
											.getElementById('myModal').style.display = "block";
									document
											.getElementById('saveFileImgId').style.visibility = "visible";
								}
							},
							error : function(e) {
								showMessageDialog("Could not open selected policy to edit.");
							}
						});
					}
				} else {										
					document.getElementById("validation_successMsg").innerHTML = "Please select policy to edit.";
				}
			}else {									
				document.getElementById("validation_successMsg").innerHTML = 'Cannot edit multiple policies.';
			}
		}else {									
			document.getElementById("validation_successMsg").innerHTML = 'Please select policy to edit.'
		}		
	}
	
	function saveEditedFile() {
		var selectedExistingRulesArray = $("#existingRuleTree").jstree(true).get_selected("full", true);		
		if(selectedExistingRulesArray!=null && selectedExistingRulesArray.length>0 && selectedExistingRulesArray!='undefined'){
			if(selectedExistingRulesArray.length==1){
				var ruleId=selectedExistingRulesArray[0].id;

					if (ruleId != null
							&& ruleId != 'undefined') {
						var fileContent = document
						.getElementById('editorTextAreaId').value;
						
						$.ajax({
							type : "POST",
							url : "./saveEditedFile",
							data : {node : ruleId, fileContent : fileContent},
							success : function(response) {
								var json = JSON.parse(response);
								if (json["result"] == "exist") {																
									document
											.getElementById("validationMsgSave").innerHTML = "Policy saved successfully";
								} else {																
									document
											.getElementById("validationMsgSave").innerHTML = "Policy not saved";
								}
							},
							error : function(e) {
								showMessageDialog("Could not save policy.");
							}
						});
					}
			}else {									
				document.getElementById("validation_successMsg").innerHTML = 'Cannot save multiple policies.';
			}
		}				
	}
	
	function removeMissedRuleFromExistingRule() {
		var selectedExistingRulesArray = $("#existingRuleTree").jstree(true).get_selected("full", true);		
		if(selectedExistingRulesArray!=null && selectedExistingRulesArray.length>0 && selectedExistingRulesArray!='undefined'){
			if(selectedExistingRulesArray.length==1){
				var selectedNode=selectedExistingRulesArray[0].id;				
				var selectedRuleName = selectedExistingRulesArray[0].text;

				if (selectedRuleName.indexOf(".") > -1) {
					if (selectedNode != null
							&& selectedNode != "undefined"
							&& selectedNode.length > 0) {
						var fileContent = document
						.getElementById('editorTextAreaId').value;
						
						$.ajax({
							type : "POST",
							url : "./removeMissedRuleFromExistingRule",
							data : {selectedRuleIds : selectedNode, selectedRuleName : selectedRuleName},
							success : function(response) {
								var existingRuleList = response;
								if (existingRuleList.length > 0) {									
										document
										.getElementById("validation_successMsg").innerHTML = 'Policy Removed Successfully';

										$('#existingRuleTree').jstree(true).settings.core.data = response;
										$('#existingRuleTree').jstree(true).refresh(true);
										
										var missedRuleTree=$("#missedRuleTree").jstree(true).get_json('#', {flat:true});
										
										for(i=0;i<missedRuleTree.length;i++){											
											if(missedRuleTree[i].text==selectedRuleName){
												$("#missedRuleTree").jstree("enable_node", missedRuleTree[i].id);
												missedRuleTree[i].a_attr.style = "color:none";
												
												var missedRuleTreeInstance=$('#missedRuleTree').jstree(true);
												missedRuleTreeInstance.get_node(missedRuleTree[i].id).a_attr.style = "color:none";							
												$('#missedRuleTree').jstree(true).redraw(true);
											}
										}																																								
								}else{
									document
									.getElementById("validation_successMsg").innerHTML="";
								}
							},
							error : function(e) {
								showMessageDialog("Could not remove policy.");
							}
						});
					}
				}else{
					document.getElementById("validation_successMsg").innerHTML = 'Cannot delete multiple policies.';
				}				
			}else {									
				document.getElementById("validation_successMsg").innerHTML = 'Cannot delete multiple policies.';
			}
		}						
	}		
	
	function disableMissedRule(ruleId){
		$("#missedRuleTree").jstree("disable_node", ruleId);
		$("#missedRuleTree").jstree("uncheck_node", ruleId);
		$("#missedRuleTree").jstree("deselect_node", ruleId);
		
		var missedRuleTreeInstance=$('#missedRuleTree').jstree(true);
		missedRuleTreeInstance.get_node(ruleId).a_attr.style = "color:lightgray";							
		$('#missedRuleTree').jstree(true).redraw(true);
	}			