/*history.pushState(null, null, location.href);
window.onpopstate = function () {
    history.go(1);
};*/
function showMessageDialog(message){   
     //  document.getElementById("validationMessageSpan").innerHTML=message;
	 document.getElementById("validationMessageSpan").textContent=message;
       document.getElementById("messageDialog").style.display="block";   
}
function closeMessageDialog(){
       document.getElementById("messageDialog").style.display="none";
}
jQuery(document).ready(function() {
	document.getElementById("loader").style.display = "none";
	 //$('#loginLinkId')[0].click();	 
});
function disableAllMenu(){
	$("#loginLinkId").removeClass('disableMenu');
	
	$("#adminLinkId").addClass('disableMenu');
	$("#scanTypeLinkId").addClass('disableMenu');
	$("#selectAPISourceLinkId").addClass('disableMenu');
	$("#reportLinkId").addClass('disableMenu');
	
	document.getElementById("adminMenuId").style.display="block";//Displaying Admin menu if it is hidden
}
function enableAllMenu(){
	$("#loginLinkId").addClass('disableMenu');
	
	$("#adminLinkId").removeClass('disableMenu');
	$("#scanTypeLinkId").removeClass('disableMenu');
	$("#selectAPISourceLinkId").removeClass('disableMenu');
	$("#reportLinkId").removeClass('disableMenu');			
}
<!-- Script for apiscan page -->
function idForm() {
	var selectvalue = $('input[name=optradio]:checked', '#idForm').val();

	if (selectvalue == "sc") { 
		$('#selectAPISourceLinkId')[0].click();
		return true;
	} else if (selectvalue == "dc") {
		return true;
	}
	return false;
}
/* Script for selectAPISource page */
function onselectChange(selectComponent){			
	$(selectComponent).find("option:selected").each(function() {
		var optionValue = $(this).attr("value");
		if (optionValue) {
			$(".box").not("." + optionValue).hide();
			$("." + optionValue).show();
		} else {
			$(".box").hide();
		}
	});	
}

/* Scripts for scanReport page*/
function closeTrendGraphDialog() {
	document.getElementById("trendGraphDialog").style.display = "none";
}

function downloadReportAsPDF() {
	var noOfPolicyGroup=0;
	//Expanding Logging Panel if it is collapsed
	$('.panel-group').each(function() {		
		//Expanding Logging Panel if it is collapsed
		var policyGroupExpandAttrPresent = document.getElementById("policyGroup_panel_header_id_"+noOfPolicyGroup).hasAttribute("aria-expanded");    	
		if(policyGroupExpandAttrPresent){
			var policyGroupPanelExpanded = document.getElementById("policyGroup_panel_header_id_"+noOfPolicyGroup).getAttribute("aria-expanded");
			if(policyGroupPanelExpanded=="false"){
				$("#policyGroup_panel_header_id_"+noOfPolicyGroup).trigger("click");
			}
		}
		noOfPolicyGroup=noOfPolicyGroup+1;
	});		 	
	    	   	
    var pdf = new jsPDF('p', 'pt','a4');
    pdf.page = 1;
    var totalPages=1;
        
    pdf.text("API Security Report", 220, 22);// set your margins
    
    var str = "Page " + pdf.page  + " of " +  totalPages;
    pdf.setFontSize(9);// optional
    pdf.text(str, 250, pdf.internal.pageSize.height - 10);//key is the interal pageSize function
    pdf.text("Accenture Confidential", 490, pdf.internal.pageSize.height - 10);//key is the interal pageSize function
    
    
    pdf.internal.scaleFactor = 2.10;
    pdf.addHTML($('#reportTabContent')[0], 30, 30, {
    	'height': 1750,
    	'width': 1058, //1150
//        'margin': 4,
        background: '#fff', //background is transparent if you don't set it, which turns it black for some reason.
        pageSplit:'true'
      },function () {    	
          pdf.save('Reports.pdf');
      }); 
}

function showModal() {
	document.getElementById('myModal').style.display = "block";
}

//<!-- Error Message Dialog-->
function showWarningDialog(message){	
	//document.getElementById("warningMessageSpan").innerHTML=message;
	document.getElementById("warningMessageSpan").textContent=message;
	document.getElementById("messageDialog_Warning").style.display="block";	
}
function closeWarningDialog(){
	document.getElementById("messageDialog_Warning").style.display="none";
}