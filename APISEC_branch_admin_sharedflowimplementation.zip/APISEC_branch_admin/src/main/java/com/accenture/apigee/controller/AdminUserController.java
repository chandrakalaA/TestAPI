package com.accenture.apigee.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.accenture.apigee.main.CodeAnalysis;
import com.accenture.apigee.model.AdminUserDTO;

@Controller
public class AdminUserController {
		
	@Autowired
	private CodeAnalysis codeAnalysis;
	private final String RESP_EXIST = "{\"result\" : \"exist\"}";
    private final String RESP_NOT_EXIST = "{\"result\" : \"notExist\"}";
	

	public CodeAnalysis getCodeAnalysis() {
		return codeAnalysis;
	}

	public void setCodeAnalysis(CodeAnalysis codeAnalysis) {
		this.codeAnalysis = codeAnalysis;
	}	
	
	
	/**
	 * Fetching admin page details from database like "All ProjectAdmin, project details" of the logged in user 
	 * @param session - Fetching logged in user-id from session.
	 * @return - List of projectAdmin from database whose role is ProjectAdmin, for mapping this list to projectAdmin dropdown in UI
	 * @throws IOException
	 * @throws SQLException
	 */
	@RequestMapping(value = "/fetchProjectAdmin")
	private ResponseEntity<ArrayList<AdminUserDTO>> fetchProjectAdmin(HttpSession session) throws IOException, SQLException {
		
		String userName=(String)session.getAttribute("username");
		ArrayList<AdminUserDTO> projectAdminList=null;
		if(userName!=null) {
			projectAdminList=codeAnalysis.fetchProjectAdmin("ProjectAdmin");
			
		}		
		return new ResponseEntity<ArrayList<AdminUserDTO>>(projectAdminList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/fetchUsers")
	private ResponseEntity<ArrayList<AdminUserDTO>> fetchUsers() throws IOException, SQLException {				
		ArrayList<AdminUserDTO> userList=null;
		userList=codeAnalysis.fetchProjectAdmin("User");			
		return new ResponseEntity<ArrayList<AdminUserDTO>>(userList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/fetchProjectAdminDetails")
	private ResponseEntity<ArrayList<AdminUserDTO>> fetchProjectAdminDetails(@RequestParam("userRole") String userRole, HttpSession session) throws IOException, SQLException {
		ArrayList<AdminUserDTO> projectAdminList=null;
		String userName=(String)session.getAttribute("username");
			if(userRole!=null) {
				if(userRole.equalsIgnoreCase("Admin")) {
					projectAdminList=codeAnalysis.retrieveProjectDetails(null);
				}else if(userRole.equalsIgnoreCase("ProjectAdmin")) {
					projectAdminList=codeAnalysis.retrieveProjectDetails(userName);
				}
			}
		return new ResponseEntity<ArrayList<AdminUserDTO>>(projectAdminList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/saveAdminDetails")
	private ResponseEntity<ArrayList<AdminUserDTO>> saveAdminDetails(@RequestParam(value="projectName") String projectName, String projectType, String projectAdmin, @RequestParam(value="userRole") String userRole, HttpSession session) throws IOException, SQLException {
		ArrayList<AdminUserDTO> projectDetailsList=null;
		String userName=(String)session.getAttribute("username");
		AdminUserDTO adminUserDTO= new AdminUserDTO();
		adminUserDTO.setProjectName(projectName);
		adminUserDTO.setProjectType(projectType);		
		
		
		DateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date currentDate=new Date();
        String currentDateTime=dateformat.format(currentDate);
        adminUserDTO.setCreateDate(currentDateTime);
		
		if(userRole!=null && projectAdmin.length()==0) {
			if(userRole.equalsIgnoreCase("ProjectAdmin")) {
				adminUserDTO.setProjectAdminId(codeAnalysis.fetchUserId(userName));
			}else {
				adminUserDTO.setProjectAdminId(Integer.parseInt(projectAdmin));
			}
		}else {
			adminUserDTO.setProjectAdminId(Integer.parseInt(projectAdmin));
		}
		adminUserDTO.setProjectId(projectName+"$"+projectType+"$"+adminUserDTO.getProjectAdminId());
		projectDetailsList=codeAnalysis.saveAdminDetails(adminUserDTO, userRole, userName);
				
		return new ResponseEntity<ArrayList<AdminUserDTO>>(projectDetailsList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/saveProjectUser")
	private ResponseEntity<ArrayList<AdminUserDTO>> saveProjectUser(@RequestParam(value="projectId") String projectId, @RequestParam(value="projectUserId") String projectUserId, HttpSession session) throws IOException, SQLException {
		ArrayList<AdminUserDTO> projectUserList=null;
		AdminUserDTO adminUserDTO= new AdminUserDTO();
		adminUserDTO.setProjectUserId(projectUserId);		
		adminUserDTO.setProjectId(projectId);
		
		DateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date currentDate=new Date();
        String currentDateTime=dateformat.format(currentDate);
        adminUserDTO.setCreateDate(currentDateTime);
		
		Integer saveIndex=codeAnalysis.saveProjectUser(adminUserDTO);
		if(saveIndex>0) {
			projectUserList=codeAnalysis.retrieveProjectUser(projectId);
		}
				
		return new ResponseEntity<ArrayList<AdminUserDTO>>(projectUserList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/fetchProjectUsers")
	private ResponseEntity<ArrayList<AdminUserDTO>> fetchProjectUsers(@RequestParam(value="projectId") String projectId) throws IOException, SQLException {
		ArrayList<AdminUserDTO> projectUserList=null;		
		if(projectId!=null) {
			projectUserList=codeAnalysis.retrieveProjectUser(projectId);
		}
				
		return new ResponseEntity<ArrayList<AdminUserDTO>>(projectUserList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/checkUserExists")
	@ResponseBody
	   public String checkUserExists(@RequestParam(value="projectId") String projectId, @RequestParam(value="projectUserId") String projectUserId) throws IOException, ParseException, SQLException {
		Boolean userExist=codeAnalysis.checkUserExists(projectId, projectUserId);
		if(userExist) {
			return RESP_EXIST;
		}		
		return RESP_NOT_EXIST;
	   }
	
	@RequestMapping(value = "/checkProjectAdminExists")
	@ResponseBody
	public String checkProjectAdminExists(@RequestParam(value="projectName") String projectName, @RequestParam(value="projectType") String projectType, String projectAdmin, @RequestParam(value="userRole") String userRole, HttpSession session) throws IOException, ParseException, SQLException {
		//Fetch UserId for the logged-in Username
		Integer userId=null;
		if(userRole!=null && projectAdmin.length()==0) {
			if(userRole.equalsIgnoreCase("ProjectAdmin")) {
				userId=codeAnalysis.fetchUserId((String)session.getAttribute("username"));
			}else {
				userId=Integer.parseInt(projectAdmin);
			}
		}else {
			userId=Integer.parseInt(projectAdmin);
		}
		if(userId!=null && userId>0) {
			Boolean userExist=codeAnalysis.checkProjectAdminExists(projectName, projectType, userId);
			if(userExist) {
				return RESP_EXIST;
			}
		}				
		return RESP_NOT_EXIST;
	   }
	
	@RequestMapping(value = "/showAdminPage", produces="text/plain")
	@ResponseBody
	private String showAdminPage(HttpSession session) throws IOException, SQLException {
		String userRole=null;
//		String userName=(String)session.getAttribute("username");
		userRole=(String)session.getAttribute("roleName");
		/*if(userName!=null) {
			userRole=codeAnalysis.fetchUserRole(userName);
			
		}*/		
		return userRole;
	}	
	
	@RequestMapping(value = "/deleteUser", produces="text/plain")
	@ResponseBody
	private String deleteUser(@RequestParam(value="userIdList") String[] userIdList, @RequestParam(value="projectId") String projectId, HttpSession session) throws IOException, SQLException {
		if(userIdList!=null && userIdList.length>0 && projectId.length()>0) {
			Integer deleteFlag=codeAnalysis.deleteUser(projectId, userIdList);
			if(deleteFlag>0) {
				return "success";
			}
		}				
		return "fail";
	}
	
	/**
	 * Fetching projectAdminName for the logged-in user and if their Role is "User", based on ProjectId and UserId
	 * ProjectId - Fetching from codeAnalysis, once the project is scanned the projectId will be available in "codeAnalysis.getProjectId()".
	 * UserId - Fetching from session and converting it into Integer.
	 * @param session
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 */
	@RequestMapping(value = "/fetchProjectAdminNameForUser", produces="text/plain")
	@ResponseBody
	private String fetchProjectAdminNameForUser(HttpSession session) throws IOException, SQLException {
		String projectAdminName=null;
		Integer userId=(Integer)session.getAttribute("userId");
		if(userId!=null) {			
			if(codeAnalysis.getProjectId()!=null && codeAnalysis.getProjectId().length()>0) {				
				projectAdminName=codeAnalysis.fetchProjectAdminName(userId, codeAnalysis.getProjectId());
			}			
			
		}		
		return projectAdminName;
	}		
}