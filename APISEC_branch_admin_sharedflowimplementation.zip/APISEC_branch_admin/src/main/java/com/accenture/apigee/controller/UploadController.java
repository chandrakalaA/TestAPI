package com.accenture.apigee.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;

import javax.servlet.http.HttpSession;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.xml.sax.SAXException;

import com.accenture.apigee.main.CodeAnalysis;
import com.accenture.apigee.model.AdminUserDTO;
import com.accenture.apigee.model.StoreJson;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

@Controller
@PropertySource("classpath:apisecConfig.properties")
public class UploadController {

	final Logger logger = LoggerFactory.getLogger(UploadController.class);
	@Autowired
	Environment env;

	@Value("${UPLOADED_FOLDER}")
	private String tempDirPath;

	private String destination;
	String fileName;
	String pathForExtraction;

	@Autowired
	private CodeAnalysis codeAnalysis;
	@Autowired
	private StoreJson storeJson;

	@Autowired
	private UpdateVulnerabilityRule updateVulnerabilityRule;

	public UpdateVulnerabilityRule getUpdateVulnerabilityRule() {
		return updateVulnerabilityRule;
	}

	public void setUpdateVulnerabilityRule(UpdateVulnerabilityRule updateVulnerabilityRule) {
		this.updateVulnerabilityRule = updateVulnerabilityRule;
	}

	public StoreJson getStoreJson() {
		return storeJson;
	}

	public void setStoreJson(StoreJson storeJson) {
		this.storeJson = storeJson;
	}

	private String finalDirectoryURL = "";
	private String directoryURLVerified = "";
	private String directoryURLVerifiedshared="";

	@PostMapping("/upload")
	public ResponseEntity<String> singleFileUpload(@RequestParam("file") MultipartFile file,
			@RequestParam(value = "projectId") String projectId,
			@RequestParam(value = "projectName") String projectName, RedirectAttributes redirectAttributes,
			HttpSession session) throws SQLException, ParseException {
		String userName = (String) session.getAttribute("username");
		Integer userId = (Integer) session.getAttribute("userId");

		destination = System.getProperty(tempDirPath);
//		if(destination.endsWith("\\Temp\\")|| destination.endsWith("\\tmp\\")|| destination.endsWith("\\temp\\") ){ //maybe needed for linux servers.
		try {
			/**
			 * save file to temp
			 */
			File zip = File.createTempFile(UUID.randomUUID().toString(), env.getProperty("TEMP_FOLDER"));
			FileOutputStream o = new FileOutputStream(zip);
			IOUtils.copy(file.getInputStream(), o);
			o.close();

			try {
				ZipFile zipFile = new ZipFile(zip);
				// Random rnd = new Random();
				SecureRandom rnd = new SecureRandom();
				/*
				 * String pathForExtraction = destination +
				 * file.getOriginalFilename().substring(0,
				 * file.getOriginalFilename().indexOf(".")) + rnd.nextInt();
				 */
				pathForExtraction = destination
						+ file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf("."))
						+ rnd.nextInt();
				zipFile.extractAll(pathForExtraction);
				finalDirectoryURL = pathForExtraction;
			} catch (ZipException e) {

				logger.error("error found in method ResponseEntity :", e);
			} finally {
				/**
				 * delete temp file
				 */
				zip.delete();
			}

			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded '" + file.getOriginalFilename() + "'");

		} catch (IOException e) {

			logger.error("error found in method ResponseEntity", e);
		}

		directoryURLVerified = findDir(new File(finalDirectoryURL + File.separator),
				env.getProperty("API_PROXY_FOLDER"));

		if (directoryURLVerified != null) {
			String resultString = null;
			try {

				fileName = file.getOriginalFilename();
				resultString = codeAnalysis.listFiles(directoryURLVerified, fileName, userName, finalDirectoryURL,
						userId, projectId, session);
				if (resultString.length() == 0) {
					return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
				} else if (resultString == "error in shared flow") {
					String errorMsgPolicyFile=(String) session.getAttribute("policyFileName");
					String result = "{\"errorMsg\" : \"error in shared flow\",\"errorMsgfilepath\" : \""+errorMsgPolicyFile+"\"}";
					//String result = "{\"errorMsg\" : \"error in shared flow\"}";
					return new ResponseEntity<String>(result, HttpStatus.OK);

				}
			} catch (ParserConfigurationException | SAXException | IOException e) {
				logger.error("error found in method ResponseEntity", e);
				return new ResponseEntity<String>("Successfully uploaded - " + "", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<String>(resultString, HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
		}
		/*
		 * }else { return new ResponseEntity<String>("", HttpStatus.NOT_FOUND); }
		 */
	}

			
		@PostMapping("/uploadsharedflow")
		public ResponseEntity<String> singleFileUploadshared(@RequestParam("file") MultipartFile file,@RequestParam(value = "projectId") String projectId,@RequestParam(value ="projectName") String projectName, RedirectAttributes redirectAttributes, HttpSession session) throws SQLException, ParseException, IOException {
		String userName = (String) session.getAttribute("username");
		Integer userId = (Integer) session.getAttribute("userId");
	    String destination;
	    String finalDirectoryURL_shared="";

		destination = System.getProperty(tempDirPath);
//		if(destination.endsWith("\\Temp\\")|| destination.endsWith("\\tmp\\")|| destination.endsWith("\\temp\\") ){ //maybe needed for linux servers.
		try {
			/**
			 * save file to temp
			 */
			File zip = File.createTempFile(UUID.randomUUID().toString(), env.getProperty("TEMP_FOLDER"));
			FileOutputStream o = new FileOutputStream(zip);
			IOUtils.copy(file.getInputStream(), o);
			o.close();

			try {
				ZipFile zipFile = new ZipFile(zip);
				// Random rnd = new Random();
				SecureRandom rnd = new SecureRandom();
				String pathForExtraction_shared = destination
						+ file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf("."))
						+ rnd.nextInt()+File.separator+file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf("."));
				//String pathForExtractionUnZip= file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf("."));
					
				zipFile.extractAll(pathForExtraction_shared);
			     finalDirectoryURL_shared = pathForExtraction_shared;
			} catch (ZipException e) {

				logger.error("error found in method uploadsharedflow :", e);
			} finally {
				/**
				 * delete temp file
				 */
				zip.delete();
			}

			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded '" + file.getOriginalFilename() + "'");

		} catch (IOException e) {

			logger.error("error found in method uploadsharedflow", e);
		}

		//directoryURLVerifiedshared = findDir(new File(finalDirectoryURL_shared + File.separator),
				//env.getProperty("SHARED_FLOW_BUNDLE"));
		directoryURLVerifiedshared = finalDirectoryURL_shared;
		File s=new File(directoryURLVerifiedshared);
         String filePath=(String)session.getAttribute("directoryName");
         File filepathshared=new File((String) session.getAttribute("directoryName"));
         
         
         String filePath1= filepathshared.getParent();
        
		if (directoryURLVerifiedshared != null) {
			String resultString = null;
			try {
				
				//copyFiles(s.getParentFile(),filePath);             //file,string//src,destination
				//copyFiles(s,filePath);
				
				copyFiles(s.getParentFile(),filePath1);
        		fileName = file.getOriginalFilename();
				resultString = codeAnalysis.listFiles(directoryURLVerified, fileName, userName, finalDirectoryURL,
						userId, projectId,session);
				String errorMsgPolicyFile=(String) session.getAttribute("policyFileName");
				if (resultString.length() == 0) {
					return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
				} else if (resultString == "error in shared flow") {
//					String result = "{\"errorMsg\" : \"error in shared flow\"}";
					String result = "{\"errorMsg\" : \"error in shared flow\",\"errorMsgfilepath\" : \""+errorMsgPolicyFile+"\"}";
					String resultstmt="{\"errorMsgfilepath\" : errorMsgPolicyFile}";
					return new ResponseEntity<String>(result, HttpStatus.OK);
					

				}
			} catch (ParserConfigurationException | SAXException | IOException e) {
				logger.error("error found in method ResponseEntity", e);
				return new ResponseEntity<String>("Successfully uploaded - " + "", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<String>(resultString, HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
		}
		/*
		 * }else { return new ResponseEntity<String>("", HttpStatus.NOT_FOUND); }
		 */
	}


	/**
	 * @param root
	 * @param name
	 * @return
	 */
	public String findDir(File root, String name) {

		if (root.getName().equals(name)) {
			return root.getAbsolutePath();
		}

		File[] files = root.listFiles();

		if (files != null) {
			for (File f : files) {
				if (f.isDirectory()) {
					String myResult = findDir(f, name);
					if (myResult != null) {
						return myResult;
					}
				}
			}
		}

		return null;
	}

	public String getFinalDirectoryURL() {
		return finalDirectoryURL;
	}

	public void setFinalDirectoryURL(String finalDirectoryURL) {
		this.finalDirectoryURL = finalDirectoryURL;
	}

	public String getDirectoryURLVerified() {
		return directoryURLVerified;
	}

	public void setDirectoryURLVerified(String directoryURLVerified) {
		this.directoryURLVerified = directoryURLVerified;
	}

	@RequestMapping(value = "/fetchProjectsForUser")
	private ResponseEntity<ArrayList<AdminUserDTO>> fetchProjectsForUser(HttpSession session)
			throws IOException, SQLException {
		String userName = (String) session.getAttribute("username");
		String roleName = (String) session.getAttribute("roleName");
		ArrayList<AdminUserDTO> projectList = null;
		if (userName != null) {
			projectList = codeAnalysis.fetchProjectsForUser(userName, roleName);

		}
		return new ResponseEntity<ArrayList<AdminUserDTO>>(projectList, HttpStatus.OK);
	}

	
	public void copyFiles(File fileDirectory, String fileDirectoryName) throws IOException {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			//new File("/fileDirectory/sharedflowbundle").mkdirs();
			
			/*
			 * File folder_shared = new File(fileDirectory + "\\" + "sharedflowbundle");
			 * folder_shared.mkdir();
			 */
			/*
			 * if(!fileDirectory.isFile()) { fileDirectory.mkdir(); }
			 */
			if (fileDirectory.listFiles() != null) {
				File[] filesArr = fileDirectory.listFiles();
				for (File file : filesArr) {
					if (file.isDirectory()) {
						File folder = new File(fileDirectoryName + "\\" + file.getName());
						folder.mkdir();
						copyFiles(file, folder.getCanonicalPath());
					} else if (file.isFile()) {
						fis = new FileInputStream(file);
						fos = new FileOutputStream(fileDirectoryName + "\\" + file.getName());
						int count = 0;
						while ((count = fis.read()) != -1) {
							fos.write(count);
						}
					}
				}
			} else {
				if (fileDirectory.isFile()) {
					fis = new FileInputStream(fileDirectory);
					fos = new FileOutputStream(fileDirectoryName + "\\" + fileDirectory.getName());
					int count = 0;
					while ((count = fis.read()) != -1) {
						fos.write(count);
					}
				}
			}
		} catch (IOException ioexp) {
			ioexp.printStackTrace();
		} finally {
			if (fis != null && fos != null) {
				fis.close();
				fos.close();
			}
		}
	}

}