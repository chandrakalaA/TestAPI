package com.accenture.apigee.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ApplicationErrorController implements ErrorController {
	
	@RequestMapping("/error")
	@ResponseBody
    public String handleError(HttpServletRequest request) {		
		if(request.getAttribute("error")!=null) {
			if(request.getAttribute("error") instanceof Exception) {
				Exception exc=(Exception)request.getAttribute("error");
				return "<html><body><h2>Error Page!</h2>"
		                + "<p>"+exc.getMessage()+"</p>"
		                		+ "<ul>\r\n" + 
		                		"		<li><a href=\""+request.getContextPath()
		                		+ "/index.html\">Home Page</a></li>\r\n" + 
		                		"	</ul></body></html>";
			}
		}		
		Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");        
        return String.format("<html><body><h2>Error Page!</h2><div>Status code: <b>%s</b></div>"
                        + "<div>Exception Message: <b>%s</b></div>"
//                        + "<body></html>",
                        + "<ul>\r\n" + 
                		"		<li><a href=\""+request.getContextPath()
                		+ "/index.html\">Home Page</a></li>\r\n" + 
                		"	</ul></body></html>",
                statusCode==null?"404":statusCode, exception==null? "Oops! Application error. Please contact system administrator": exception.getMessage());        
    }

	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return "/error";
	}
		
}