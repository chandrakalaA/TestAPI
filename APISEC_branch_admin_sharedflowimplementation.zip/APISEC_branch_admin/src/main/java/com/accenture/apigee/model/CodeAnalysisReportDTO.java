package com.accenture.apigee.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class CodeAnalysisReportDTO {
	private ReportTO reportTO;
	private Map<String, ArrayList<PolicyModelClass>> policyMap=new LinkedHashMap<String, ArrayList<PolicyModelClass>>();
	private ArrayList<ReportTO> policyGroupTotalList=null;
	private APIMappingOWASP apiMappingOWASP;
	public ReportTO getReportTO() {
		return reportTO;
	}
	public void setReportTO(ReportTO reportTO) {
		this.reportTO = reportTO;
	}	
	public Map<String, ArrayList<PolicyModelClass>> getPolicyMap() {
		return policyMap;
	}
	public void setPolicyMap(Map<String, ArrayList<PolicyModelClass>> policyMap) {
		this.policyMap = policyMap;
	}
	public ArrayList<ReportTO> getPolicyGroupTotalList() {
		return policyGroupTotalList;
	}
	public void setPolicyGroupTotalList(ArrayList<ReportTO> policyGroupTotalList) {
		this.policyGroupTotalList = policyGroupTotalList;
	}
	public APIMappingOWASP getApiMappingOWASP() {
		return apiMappingOWASP;
	}
	public void setApiMappingOWASP(APIMappingOWASP apiMappingOWASP) {
		this.apiMappingOWASP = apiMappingOWASP;
	}
	
	
}
