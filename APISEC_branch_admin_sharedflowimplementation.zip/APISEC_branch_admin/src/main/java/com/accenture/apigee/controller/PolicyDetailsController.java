package com.accenture.apigee.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.accenture.apigee.main.CodeAnalysis;
import com.accenture.apigee.model.PolicyDetailsDTO;

@Controller
public class PolicyDetailsController {
		
	@Autowired
	private CodeAnalysis codeAnalysis;	

	public CodeAnalysis getCodeAnalysis() {
		return codeAnalysis;
	}

	public void setCodeAnalysis(CodeAnalysis codeAnalysis) {
		this.codeAnalysis = codeAnalysis;
	}						
	
	/**
	 * @param projectId
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 */
	@RequestMapping(value = "/fetchPolicyDetails")
	private ResponseEntity<Map<String, ArrayList<PolicyDetailsDTO>>> fetchPolicyDetails(@RequestParam(value="projectId") String projectId) throws IOException, SQLException {
		Map<String, ArrayList<PolicyDetailsDTO>> policyMap=null;
		
		//Check if policydetails are available in DB for the given project, if so fetch and display the same otherwise show policy details from policyMapping file.
		if(projectId!=null && projectId.length()>0) {
			if(codeAnalysis.isPolicyMappedForProject(projectId)) {
				policyMap=codeAnalysis.retrievePolicyDetails(projectId);
			}else {
				policyMap=codeAnalysis.retrievePolicyMappingDetails();
			}
		}else {
			policyMap=codeAnalysis.retrievePolicyMappingDetails();
		}
		return new ResponseEntity<Map<String, ArrayList<PolicyDetailsDTO>>>(policyMap, HttpStatus.OK);
	}			
	
	/**
	 * @param policyMap
	 * @param projectId
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/readPolicyDetailsFromTable", produces="text/plain")
	@ResponseBody
	private String readPolicyDetailsFromTable(@RequestParam(value="policyMap") Object[] policyMap, @RequestParam(value="projectId") String projectId) throws IOException, SQLException, ParseException {
		if(policyMap!=null && policyMap.length>0) {
			ArrayList<PolicyDetailsDTO> existingPolicyDetList=codeAnalysis.checkPolicyExistForProject(projectId);
			ArrayList<PolicyDetailsDTO> policyDetailsList=new ArrayList<PolicyDetailsDTO>();
			DateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        Date currentDate=new Date();
	        String currentDateTime=dateformat.format(currentDate);
			
			for(Object policyListObj:policyMap) {
				
				JSONParser parser = new JSONParser();
				JSONArray policyListJSONArray=(JSONArray)parser.parse(policyListObj.toString());
				
				if(policyListJSONArray!=null && policyListJSONArray.size()>0) {
					for(int i=0;i<policyListJSONArray.size();i++) {
						JSONObject policyMappingJSONObj=(JSONObject)policyListJSONArray.get(i);
							PolicyDetailsDTO policyDetailsDTO=new PolicyDetailsDTO();
							policyDetailsDTO.setPolicyGroupName((String)policyMappingJSONObj.get("groupName"));
							policyDetailsDTO.setIspolicySelected((Boolean)policyMappingJSONObj.get("ispolicySelected"));
							if((policyMappingJSONObj.get("policyModifiedWeight")+"").length()==0) {
								policyDetailsDTO.setPolicyModifiedWeight(0);
							}else
								policyDetailsDTO.setPolicyModifiedWeight(Integer.parseInt(policyMappingJSONObj.get("policyModifiedWeight")+""));
							policyDetailsDTO.setPolicyName((String)policyMappingJSONObj.get("policyName"));
							policyDetailsDTO.setPolicyFileName((String)policyMappingJSONObj.get("policyFileName"));
							policyDetailsDTO.setPolicyGroupId(Integer.parseInt(policyMappingJSONObj.get("policyGroupId")+""));
							policyDetailsDTO.setProjectId(projectId);
							policyDetailsDTO.setCreateDate(currentDateTime);
							policyDetailsDTO.setIspolicySelected((Boolean)policyMappingJSONObj.get("ispolicySelected"));
							
							policyDetailsList.add(policyDetailsDTO);					
					}
					//the code were here
				}							
			}
			if(policyDetailsList.size()>0) {
				if(existingPolicyDetList!=null && existingPolicyDetList.size()>0) {							
					ArrayList<PolicyDetailsDTO> deletePolicyDetList=new ArrayList<PolicyDetailsDTO>();
					
					Iterator<PolicyDetailsDTO> iterPoliciesFromUI=policyDetailsList.iterator();
					while(iterPoliciesFromUI.hasNext()) {
						PolicyDetailsDTO policyDetDTO=(PolicyDetailsDTO)iterPoliciesFromUI.next();
						Iterator<PolicyDetailsDTO> iterPoliciesFromDB=existingPolicyDetList.iterator();
						while(iterPoliciesFromDB.hasNext()) {
							PolicyDetailsDTO policyDetDTOFromDB=(PolicyDetailsDTO)iterPoliciesFromDB.next();
								if(policyDetDTO.getPolicyName().equals(policyDetDTOFromDB.getPolicyName())){ //If same policy already available in database then updating that policyWeight otherwise inserting policydetails into DB
									if(policyDetDTO.getIspolicySelected()) {
										if(policyDetDTO.getPolicyModifiedWeight()!=policyDetDTOFromDB.getPolicyModifiedWeight()) {
											policyDetDTOFromDB.setPolicyModifiedWeight(policyDetDTO.getPolicyModifiedWeight());
											policyDetDTOFromDB.setCreateDate(policyDetDTO.getCreateDate());
											policyDetDTOFromDB.setPolicyGroupId(policyDetDTO.getPolicyGroupId());
										}else {
											iterPoliciesFromDB.remove();
										}
										
									}else {
										deletePolicyDetList.add(policyDetDTOFromDB);
										iterPoliciesFromDB.remove();
									}
									iterPoliciesFromUI.remove();
								}
						}							
					}
					
					//update PolicyDetails into database if it is already saved
					if(existingPolicyDetList.size()>0) {
						codeAnalysis.updatePolicyDetails(existingPolicyDetList);
					}					
					if(deletePolicyDetList.size()>0) {
						codeAnalysis.deletePolicyDetails(deletePolicyDetList);
					}
					if(policyDetailsList.size()>0) {
						codeAnalysis.savePolicyDetails(policyDetailsList);
					}
				}else {
					boolean recordSaved=codeAnalysis.savePolicyDetails(policyDetailsList);
					if(!recordSaved) {
						return "fail";
					}
				}												
			}
		}		
		return "success";
	}
	
	/**
	 * @param policyMap
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/validatePolicies", produces="text/plain")
	@ResponseBody
	private String validatePolicies(@RequestParam(value="policyMap") Object[] policyMap) throws IOException, SQLException, ParseException {
		if(policyMap!=null && policyMap.length>0) {
			String policyGroupName="";			
			for(Object policyListObj:policyMap) {
				Integer policyTotal=0;
				JSONParser parser = new JSONParser();
				JSONArray policyListJSONArray=(JSONArray)parser.parse(policyListObj.toString());
				if(policyListJSONArray!=null && policyListJSONArray.size()>0) {
					for(int i=0;i<policyListJSONArray.size();i++) {
						JSONObject policyMappingJSONObj=(JSONObject)policyListJSONArray.get(i);						
						if((Boolean)policyMappingJSONObj.get("ispolicySelected")) {
							if((policyMappingJSONObj.get("policyModifiedWeight")+"").length()==0) {
								return "Selected Policy "+(String)policyMappingJSONObj.get("policyFileName")+" should be greater than 0.";
							}else if(Integer.parseInt(policyMappingJSONObj.get("policyModifiedWeight")+"")==0) {
								return "Selected Policy "+(String)policyMappingJSONObj.get("policyFileName")+" should be greater than 0.";
							}else if(Integer.parseInt(policyMappingJSONObj.get("policyModifiedWeight")+"")<Integer.parseInt(policyMappingJSONObj.get("policyWeight")+"")) {
								return "Policy "+(String)policyMappingJSONObj.get("policyFileName")+" weight should not be less than Default weight.";
							}else if(Integer.parseInt(policyMappingJSONObj.get("policyModifiedWeight")+"")>0) {
								policyTotal+=Integer.parseInt(policyMappingJSONObj.get("policyModifiedWeight")+"");
							}
						}
					}
					if(policyTotal>0 && policyTotal!=100) {
						policyGroupName=(String)((JSONObject)policyListJSONArray.get(0)).get("policyGroupName");
						return policyGroupName+" Policy Total should be 100.";
					}
				}							
			}			
		}		
		return "success";
	}
}