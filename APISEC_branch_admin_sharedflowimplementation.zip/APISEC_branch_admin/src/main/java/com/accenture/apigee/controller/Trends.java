package com.accenture.apigee.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.accenture.apigee.main.CodeAnalysis;
import com.accenture.apigee.model.ReportDO;

/**
 * @author kanchan.khushboo
 *
 */
@Controller
public class Trends {

	@Autowired
	private CodeAnalysis codeAnalysis;	

	/**
	 * @param model
	 * @param name
	 * @param password
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/trends")
	@ResponseBody
	private ResponseEntity<ArrayList<ReportDO>> loadTrends(@RequestParam(value = "projectId") String projectId, @RequestParam(value = "date") String date,
			HttpSession session, HttpServletRequest request)
			throws InvalidRemoteException, TransportException, GitAPIException, SQLException {		
		Integer userId = (Integer) session.getAttribute("userId");

		ArrayList<ReportDO> trendList=codeAnalysis.fetchTrendDetails(projectId,date,userId);
		return new ResponseEntity<ArrayList<ReportDO>>(trendList, HttpStatus.OK);
	}

	

	
}
