package com.accenture.apigee.model;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:apisecConfig.properties")
public class StoreJson {

	final Logger logger = LoggerFactory.getLogger(StoreJson.class);
	@Autowired
	Environment env;
	
	String username;
	public String jsonFileAbsolutePath;

	// create directory of username
	public void createDirectory(String reportPath, String userName2) {
		File file = new File(reportPath + File.separator + userName2);
		if (!file.exists()) {
			file.mkdir();
		} 
	}

	// write json string to file

	public void copyFiles(String storagePath, String resultString, String username2, String name, String lastUpdated) throws IOException {

		PrintWriter out = null;
//		Date date = java.util.Calendar.getInstance().getTime();
		String strDate=null;
		if(lastUpdated!=null) {
			strDate=convertStringDateToDateTime(lastUpdated);
		}else {
			Date date = java.util.Calendar.getInstance().getTime();
			DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			strDate = dateFormat.format(date);
		}
		

//		DateFormat dateFormat = new SimpleDateFormat("yyyymmddshhmmss");
//		DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		String strDate = dateFormat.format(date);
		if(strDate!=null) {
			strDate=strDate.replaceAll(" ", "_");
			strDate=strDate.replaceAll(":", "_");
		}		

		jsonFileAbsolutePath = storagePath + File.separator + username2 + File.separator + name + "_" + strDate + env.getProperty("JSON_EXTN");

		try {
			out = new PrintWriter(jsonFileAbsolutePath);

			out.print(resultString);

		} catch (IOException ioexp) {
			logger.error("error in copyFiles:",ioexp);
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	// download report function

	public void downloadReport(String resultString, String userName, String projectName, String lastUpdated) {
		if (projectName.contains(env.getProperty("ZIP_EXTN"))) {
			projectName = projectName.substring(0, projectName.indexOf("."));			
		}
		
		/*
		 * String storagePath=""; ClassLoader classLoader = getClass().getClassLoader();
		 * if(classLoader.getResource(env.getProperty("REPORTS_FOLDER"))!=null) {
		 * storagePath=classLoader.getResource(env.getProperty("REPORTS_FOLDER")).
		 * getPath(); }
		 * 
		 * if(storagePath.contains("/")) { storagePath=storagePath.replace("/",
		 * File.separator); }else if(storagePath.contains("\"")) {
		 * storagePath=storagePath.replace("\"", File.separator); }
		 */
        String storagePath="src"+File.separator+"main"+File.separator+"resources"+File.separator+"reports";
		
		createDirectory(storagePath, userName);
		try {
			copyFiles(storagePath, resultString, userName, projectName, lastUpdated);
		} catch (IOException e) {						
			logger.error("error in downloadReport is",e);
		}

	}
	
	/**
	 * Converting LastUpdatedDate from String to Date with format
	 * @param lastUpdatedDate
	 * @return
	 */
	private String convertStringDateToDateTime(String lastUpdatedDate) {
		DateFormat readFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		DateFormat writeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = null;
		try {
			date = readFormat.parse(lastUpdatedDate);
		} catch (ParseException e) {			
			logger.error("error convertStringDateToDateTime is",e);
		}

		String formattedDate = "";
		if (date != null) {
			formattedDate = writeFormat.format(date);
		}

		return formattedDate;

	}
}

