package com.accenture.apigee.model;

import java.io.Serializable;
import java.util.LinkedList;

public class MissedRulesDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	private String ruleId;
//	private String ruleName;
	private String highPriorityPolicyFileNames;
	private Boolean collapsed;
	private Boolean disabled;
	
	private String id;
	private String text;
	private LinkedList<MissedRulesDTO> children;
	private String icon;
	private JSTree_State state;
	private Boolean checkbox=false;
	private JSTree_A_attr a_attr;
	private String li_attr;
	
	public Boolean getDisabled() {
		return disabled;
	}
	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}
//	private LinkedList<MissedRulesDTO1> childRuleList=new LinkedList<MissedRulesDTO1>();
//	public String getRuleId() {
//		return ruleId;
//	}
//	public void setRuleId(String ruleId) {
//		this.ruleId = ruleId;
//	}
//	public String getRuleName() {
//		return ruleName;
//	}
//	public void setRuleName(String ruleName) {
//		this.ruleName = ruleName;
//	}	
//	public LinkedList<MissedRulesDTO1> getChildRuleList() {
//		return childRuleList;
//	}
//	public void setChildRuleList(LinkedList<MissedRulesDTO1> childRuleList) {
//		this.childRuleList = childRuleList;
//	}
	public Boolean getCollapsed() {
		return collapsed;
	}
	public void setCollapsed(Boolean collapsed) {
		this.collapsed = collapsed;
	}
	public String getHighPriorityPolicyFileNames() {
		return highPriorityPolicyFileNames;
	}
	public void setHighPriorityPolicyFileNames(String highPriorityPolicyFileNames) {
		this.highPriorityPolicyFileNames = highPriorityPolicyFileNames;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public LinkedList<MissedRulesDTO> getChildren() {
		return children;
	}
	public void setChildren(LinkedList<MissedRulesDTO> children) {
		this.children = children;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public JSTree_State getState() {
		return state;
	}
	public void setState(JSTree_State state) {
		this.state = state;
	}
	public Boolean getCheckbox() {
		return checkbox;
	}
	public void setCheckbox(Boolean checkbox) {
		this.checkbox = checkbox;
	}	
	public JSTree_A_attr getA_attr() {
		return a_attr;
	}
	public void setA_attr(JSTree_A_attr a_attr) {
		this.a_attr = a_attr;
	}
	public String getLi_attr() {
		return li_attr;
	}
	public void setLi_attr(String li_attr) {
		this.li_attr = li_attr;
	}
	
}