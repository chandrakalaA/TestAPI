package com.accenture.apigee.model;

public class PolicyDetailsDTO {
	private String projectId;
	private String projectName;	
	private String policyName;
	private String policyFileName;
	private String policyWeight;
	private Integer policyModifiedWeight;
	private Integer policyGroupId;
	private String policyGroupName;
	private Boolean ispolicySelected=true;
	private String createDate;
	private String policyRisk;
	private String policyRefLink;
	
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}	
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyFileName() {
		return policyFileName;
	}
	public void setPolicyFileName(String policyFileName) {
		this.policyFileName = policyFileName;
	}
	public String getPolicyWeight() {
		return policyWeight;
	}
	public void setPolicyWeight(String policyWeight) {
		this.policyWeight = policyWeight;
	}
	public Integer getPolicyModifiedWeight() {
		return policyModifiedWeight;
	}
	public void setPolicyModifiedWeight(Integer policyModifiedWeight) {
		this.policyModifiedWeight = policyModifiedWeight;
	}	
	public Boolean getIspolicySelected() {
		return ispolicySelected;
	}
	public void setIspolicySelected(Boolean ispolicySelected) {
		this.ispolicySelected = ispolicySelected;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public Integer getPolicyGroupId() {
		return policyGroupId;
	}
	public void setPolicyGroupId(Integer policyGroupId) {
		this.policyGroupId = policyGroupId;
	}
	public String getPolicyGroupName() {
		return policyGroupName;
	}
	public void setPolicyGroupName(String policyGroupName) {
		this.policyGroupName = policyGroupName;
	}
	public String getPolicyRisk() {
		return policyRisk;
	}
	public void setPolicyRisk(String policyRisk) {
		this.policyRisk = policyRisk;
	}
	public String getPolicyRefLink() {
		return policyRefLink;
	}
	public void setPolicyRefLink(String policyRefLink) {
		this.policyRefLink = policyRefLink;
	}
	
}
