package com.accenture.apigee.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.accenture.apigee.main.CodeAnalysis;
import com.accenture.apigee.model.UserDTO;
import com.accenture.apigee.util.AuthHelper;
import com.microsoft.aad.adal4j.AuthenticationResult;

/**
 * @author kanchan.khushboo
 *
 */
@Controller
@PropertySource("classpath:application.properties")
public class LoginController {

	@Autowired
	private CodeAnalysis codeAnalysis;
	@Autowired
	private UpdateVulnerabilityRule updateVulnerabilityRule;
	private static final String RESP_ERROR = "{\"result\" : \"Fail\"}";

	final Logger logger = LoggerFactory.getLogger(LoginController.class);

	/**
	 * @param model
	 * @param name
	 * @param password
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping("/login")
	@ResponseBody
	public String insert(@RequestParam(value = "username") String userName, @RequestParam(value = "password") String pw,
			HttpSession session, HttpServletRequest request)
			throws InvalidRemoteException, TransportException, GitAPIException, SQLException {

		boolean isValidUser = validateUser(userName, pw);
		if (isValidUser) {
			session = request.getSession();
			session.setAttribute("username", userName);

			// Admin Requirment
			UserDTO userDTO = codeAnalysis.getUserRole(userName);
			if (userDTO != null) {
				session.setAttribute("userId", userDTO.getUserId());
				session.setAttribute("roleId", userDTO.getRoleId());
				session.setAttribute("roleName", userDTO.getRoleName());
			}
			return "{\"result\" : \"" + userDTO.getRoleName() + "\"}";
		}

		return RESP_ERROR;

	}

	/**
	 * @param userid
	 * @param password
	 * @return
	 * @throws SQLException
	 */
	public boolean validateUser(String userId, String password) throws SQLException {
		boolean validate = false;
		String str = codeAnalysis.loginCheck(userId, password);

		if (str == "success") {
			validate = true;
		} else {
			validate = false;
		}
		return validate;
	}

	/**
	 * @param session
	 *            - HttpSession
	 * @param response
	 *            - HttpResponse
	 * @return - Logout page to render in UI
	 * @throws InvalidRemoteException
	 * @throws TransportException
	 * @throws GitAPIException
	 * @throws SQLException
	 * @throws IOException
	 *             In this method checking whether the User details available in
	 *             session, if it is not available then assuming the user is not
	 *             accessing via SSO so redirecting them to Index page
	 */
	@RequestMapping(value = "/logout", produces = "text/plain")
	@ResponseBody
	public String logout(HttpSession session, HttpServletResponse response)
			throws InvalidRemoteException, TransportException, GitAPIException, SQLException, IOException {
		AuthenticationResult result = (AuthenticationResult) session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
		session.invalidate();
		if (result != null) {
			return "https://federation-sts.accenture.com/adfs/ls/?wa=wsignout1.0";
		} else
			return "index";
	}

	/**
	 * While logging out from application, we are checking whether the Project is
	 * "Remediated", if so then we are not allowing the user to Logout. The User
	 * have to download the project if it is remediated with any policies, then only
	 * they will be able to logout from the application.
	 * 
	 * @param session
	 * @param response
	 * @return
	 * @throws InvalidRemoteException
	 * @throws TransportException
	 * @throws GitAPIException
	 * @throws SQLException
	 * @throws IOException
	 */
	@RequestMapping(value = "/isProjectRemediated", produces = "text/plain")
	@ResponseBody
	public String isProjectRemediated(HttpSession session, HttpServletResponse response)
			throws InvalidRemoteException, TransportException, GitAPIException, SQLException, IOException {
		if (!updateVulnerabilityRule.isProjectDownloaded) {
			return "Fail";
		}
		return "Success";
	}

	/**
	 * @param session
	 * @param request
	 * @param response
	 * @return - Returns Role if user comes with SSO otherwise error/index page
	 * @throws InvalidRemoteException
	 * @throws TransportException
	 * @throws GitAPIException
	 * @throws SQLException
	 * @throws IOException
	 *             Checking if user exists in session, then assuming they are
	 *             logging with SSO so we will bypass the loginpage and will
	 *             directly display ProjectAdmin/Apiscan page based on userRole,
	 *             otherwise display login page
	 */
	@RequestMapping(value = "/checkUserAccess", produces = "text/plain")
	@ResponseBody
	public String checkUserAccess(HttpSession session, HttpServletRequest request, HttpServletResponse response)
			throws InvalidRemoteException, TransportException, GitAPIException, SQLException, IOException {
		AuthenticationResult result = (AuthenticationResult) session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
		if (result != null) {
			String userId = result.getUserInfo().getDisplayableId();
			if (userId.contains("@")) {
				userId = userId.substring(0, userId.indexOf("@"));
				boolean isValidUser = validateUser(userId, userId);
				if (isValidUser) {
					session = request.getSession();
					session.setAttribute("username", userId);

					// Admin Requirment
					UserDTO userDTO = codeAnalysis.getUserRole(userId);
					if (userDTO != null) {
						session.setAttribute("userId", userDTO.getUserId());
						session.setAttribute("roleId", userDTO.getRoleId());
						session.setAttribute("roleName", userDTO.getRoleName());
					}
					return userDTO.getRoleName();
				} else {
					return "error";
				}
			}
		}
		return "index";
	}
}
