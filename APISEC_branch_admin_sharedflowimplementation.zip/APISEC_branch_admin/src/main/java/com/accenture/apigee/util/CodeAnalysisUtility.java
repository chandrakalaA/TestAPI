package com.accenture.apigee.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.accenture.apigee.dao.PolicyDetailsDAOImpl;
import com.accenture.apigee.dao.ReportDAOImpl;
import com.accenture.apigee.model.AdminUserDTO;
import com.accenture.apigee.model.CodeAnalysisReportDTO;
import com.accenture.apigee.model.PolicyDetailsDTO;
import com.accenture.apigee.model.PolicyModelClass;
import com.accenture.apigee.model.PreviousReportDTO;
import com.accenture.apigee.model.ReportDO;
import com.accenture.apigee.model.ReportTO;

@Component
@PropertySource("classpath:apisecConfig.properties")
public class CodeAnalysisUtility {
	
	final Logger logger = LoggerFactory.getLogger(CodeAnalysisUtility.class);
	@Autowired
	Environment env;
	String policyFileMsg;
	
	@Autowired
	private ReportDAOImpl reportDAO;
	
	@Autowired
	private PolicyDetailsDAOImpl policyDetailsDAO;	

	public ReportDAOImpl getReportDAO() {
		return reportDAO;
	}

	public void setReportDAO(ReportDAOImpl reportDAO) {
		this.reportDAO = reportDAO;
	}	

	public PolicyDetailsDAOImpl getPolicyDetailsDAO() {
		return policyDetailsDAO;
	}

	public void setPolicyDetailsDAO(PolicyDetailsDAOImpl policyDetailsDAO) {
		this.policyDetailsDAO = policyDetailsDAO;
	}

	/**
	 * Reading apiproxy and its sharedflowbundle and dynamically rendering policy enabled status as PolicyGroup wise in Report UI.
	 * @param directoryName
	 * @param isSharedFlow
	 * @param fileName
	 * @param version
	 * @param policyDetailsMap
	 * @param codeAnalysisReportDTO
	 * @param proxyEndPoint
	 * @throws Exception 
	 */
	public void validatePolicies(String directoryName, boolean isSharedFlow, String fileName, String version, Map<String, PolicyDetailsDTO> policyDetailsMap, CodeAnalysisReportDTO codeAnalysisReportDTO, String proxyEndPoint,HttpSession session)
			throws Exception {				
		ArrayList<PolicyModelClass> policyModelList=new ArrayList<PolicyModelClass>();
		if(proxyEndPoint==null || proxyEndPoint.length()==0) {
			proxyEndPoint=env.getProperty("DEFAULT_FILE");
		}
		String defaultProxyFile = "";
		if (isSharedFlow) {
			
			  File checkDefaultProxyFile = new File(directoryName + File.separator +
			  env.getProperty("SHARED_FLOW_BUNDLE"));
			 
			  
			  session.setAttribute("directoryName", directoryName);
			  
			  
			if (!checkDefaultProxyFile.exists()) {
				throw new Exception("SharedFlowBundle does not exist");
			}
			 
			defaultProxyFile = directoryName + File.separator + env.getProperty("SHARED_FLOW_BUNDLE") + File.separator + env.getProperty("SHARED_FLOWS")
					+ File.separator + env.getProperty("DEFAULT_FILE") + env.getProperty("XML_EXTN");
		} else {
			defaultProxyFile = directoryName + File.separator + env.getProperty("PROXIES_FOLDER") + File.separator + proxyEndPoint + env.getProperty("XML_EXTN");
		}

		File file = new File(defaultProxyFile);

		if (file.exists()) {

			DocumentBuilder dBuilder;

			dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = dBuilder.parse(file);
			doc.getDocumentElement().normalize();
			NodeList nList;
			if (isSharedFlow) {
				nList = doc.getElementsByTagName(env.getProperty("SHARED_FLOW_TAG"));
			} else {

				nList = doc.getElementsByTagName(env.getProperty("PRE_FLOW_TAG"));
			}

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					for (int count = 0; count < eElement.getElementsByTagName(env.getProperty("NAME_ATTR")).getLength(); count++) {

						String policyFile;
						String policyFileName;
						if (isSharedFlow) {
							policyFile = directoryName + File.separator + env.getProperty("SHARED_FLOW_BUNDLE") + File.separator
									 + env.getProperty("POLICIES_FOLDER") + File.separator
									+ eElement.getElementsByTagName(env.getProperty("NAME_ATTR")).item(count).getTextContent() + env.getProperty("XML_EXTN");
						} else {
							policyFile = directoryName + File.separator + env.getProperty("POLICIES_FOLDER") + File.separator
									+ eElement.getElementsByTagName(env.getProperty("NAME_ATTR")).item(count).getTextContent() + env.getProperty("XML_EXTN");
						
							policyFileName= eElement.getElementsByTagName(env.getProperty("NAME_ATTR")).item(count).getTextContent();
							//session.setAttribute("policyFileName", policyFileName);
						}
						//DocumentBuilder policyBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
						
						DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
						factory.setValidating(true);
						factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

						TransformerFactory trfactory = TransformerFactory.newInstance();
						try {
							trfactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
						} catch (TransformerConfigurationException e) {
							// TODO Auto-generated catch block						
							logger.error("error found in method validatePolicies :",e);
						}
						trfactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
						trfactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
						DocumentBuilder policyBuilder=factory.newDocumentBuilder();
						
						
						Document policyDoc = policyBuilder.parse(policyFile);
						policyDoc.getDocumentElement().normalize();

						//Code for Dynamic policy handling
						
						if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase(env.getProperty("OAUTH1_NODE")) || policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase(env.getProperty("OAUTH2_NODE"))) {
							if(policyDetailsMap.containsKey(policyDoc.getDocumentElement().getNodeName()) 
									&& ((policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).length() == 0))) {
								for (int i = 0; i < policyDoc.getDocumentElement().getChildNodes().getLength(); i++) {
									if (policyDoc.getDocumentElement().getChildNodes().item(i).getNodeName()
											.equalsIgnoreCase(env.getProperty("OPERATION_NODE"))
											&& policyDoc.getDocumentElement().getChildNodes().item(i).getTextContent()
													.equalsIgnoreCase(env.getProperty("VERIFY_ACCESS_TOKEN"))) {
										String policyGroupName=policyDetailsMap.get(policyDoc.getDocumentElement().getNodeName()).getPolicyGroupName();
										policyModelList=codeAnalysisReportDTO.getPolicyMap().get(policyGroupName);
										for(PolicyModelClass policyModelClass:policyModelList) {
											if(policyModelClass.getPolicyName().equalsIgnoreCase(policyDoc.getDocumentElement().getNodeName())) {
												policyModelClass.setEnabled(true);
											}
										}																		
										break;
									}
								}	
							}							
						}else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase(env.getProperty("ASSIGN_MESSAGE_NODE"))) {
							if(policyDetailsMap.containsKey(env.getProperty("CROSS_ORIGIN_RESOURCE_SHARING")) 
									&& ((policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).length() == 0))) {
								if (policyDoc.getElementsByTagName(env.getProperty("HEADER_NODE")) != null) {
									NodeList nList1 = policyDoc.getElementsByTagName(env.getProperty("HEADER_NODE"));
									for (int i = 0; i < nList1.getLength(); i++) {
										Node nNode1 = nList1.item(i);
										String st1 = nNode1.getAttributes().item(0).getTextContent();
										if ((st1.equalsIgnoreCase(env.getProperty("ACCESS_CONTROL_ALLOW_ORIGIN")))
												|| (st1.equalsIgnoreCase(env.getProperty("ACCESS_CONTROL_ALLOW_HEADERS")))
												|| (st1.equalsIgnoreCase(env.getProperty("ACCESS_CONTROL_MAX_AGE")))
												|| (st1.equalsIgnoreCase(env.getProperty("ACCESS_CONTROL_ALLOW_METHODS")))) {																						
											String policyGroupName=policyDetailsMap.get(env.getProperty("CROSS_ORIGIN_RESOURCE_SHARING")).getPolicyGroupName();
											policyModelList=codeAnalysisReportDTO.getPolicyMap().get(policyGroupName);
											for(PolicyModelClass policyModelClass:policyModelList) {
												if(policyModelClass.getPolicyName().equalsIgnoreCase(env.getProperty("CROSS_ORIGIN_RESOURCE_SHARING"))) {
													policyModelClass.setEnabled(true);
													break;
												}
											}
											break;
										}
									}
								}																
							}
						}else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase(env.getProperty("FLOW_CALL_OUT_NODE"))) {

							for (int i = 0; i < policyDoc.getDocumentElement().getChildNodes().getLength(); i++) {
								if (policyDoc.getDocumentElement().getChildNodes().item(i).getNodeName()
										.equalsIgnoreCase(env.getProperty("SHARED_FLOW_BUNDLE_NODE"))) {
									String sharedFlow = policyDoc.getDocumentElement().getChildNodes().item(i)
											.getTextContent();
									String proxyFile = new File(directoryName).getParentFile().getAbsolutePath()
											+ File.separator + sharedFlow;
									policyFileMsg=sharedFlow;
									session.setAttribute("policyFileName", sharedFlow);
									validatePolicies(proxyFile, true, fileName, version, policyDetailsMap, codeAnalysisReportDTO, proxyEndPoint,session);
								}
							}
						}else {
							if(policyDetailsMap.containsKey(policyDoc.getDocumentElement().getNodeName()) && ((policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).equalsIgnoreCase("true"))
									|| (policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).length() == 0))) {
								
								String policyGroupName=policyDetailsMap.get(policyDoc.getDocumentElement().getNodeName()).getPolicyGroupName();
								policyModelList=codeAnalysisReportDTO.getPolicyMap().get(policyGroupName);
								for(PolicyModelClass policyModelClass:policyModelList) {
									if(policyModelClass.getPolicyName().equalsIgnoreCase(policyDoc.getDocumentElement().getNodeName())) {
										policyModelClass.setEnabled(true);
										break;
									}
								}
							}
						}
					}
				}
			}

			nList = doc.getElementsByTagName(env.getProperty("POST_CLIENT_FLOW_NODE"));
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					for (int count = 0; count < eElement.getElementsByTagName(env.getProperty("NAME_ATTR")).getLength(); count++) {

						String policyFile = directoryName + File.separator + env.getProperty("POLICIES_FOLDER") + File.separator
								+ eElement.getElementsByTagName(env.getProperty("NAME_ATTR")).item(count).getTextContent() + env.getProperty("XML_EXTN");
						//DocumentBuilder policyBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
						
						
						DocumentBuilderFactory factory= DocumentBuilderFactory.newInstance();
						factory.setValidating(true);
						factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

						TransformerFactory trfactory = TransformerFactory.newInstance();
						try {
							trfactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
						} catch (TransformerConfigurationException e) {
							// TODO Auto-generated catch block
							
							logger.error("error found in method validatePolicies :",e);
						}
						trfactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
						trfactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
						
						DocumentBuilder policyBuilder=factory.newDocumentBuilder();
						
						Document policyDoc = policyBuilder.parse(policyFile);
						policyDoc.getDocumentElement().normalize();
						if(policyDetailsMap.containsKey(policyDoc.getDocumentElement().getNodeName()) && ((policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).equalsIgnoreCase("true"))
								|| (policyDoc.getDocumentElement().getAttribute(env.getProperty("ENABLED_ATTR")).length() == 0))) {							
							String policyGroupName=policyDetailsMap.get(policyDoc.getDocumentElement().getNodeName()).getPolicyGroupName();
							policyModelList=codeAnalysisReportDTO.getPolicyMap().get(policyGroupName);
							for(PolicyModelClass policyModelClass:policyModelList) {
								if(policyModelClass.getPolicyName().equalsIgnoreCase(policyDoc.getDocumentElement().getNodeName())) {
									policyModelClass.setEnabled(true);
									break;
								}
							}
						}
					}
				}
			}

			nList = doc.getElementsByTagName(env.getProperty("HTTP_PROXY_CONNECTION_TAG"));
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					for (int count = 0; count < eElement.getElementsByTagName(env.getProperty("VIRTUAL_HOST_TAG")).getLength(); count++) {
						if (eElement.getElementsByTagName(env.getProperty("VIRTUAL_HOST_TAG")).item(count).getTextContent()
								.equalsIgnoreCase("secure")) {
							if(policyDetailsMap.containsKey(env.getProperty("TLS_ENABLED_POLICY"))) {								
								String policyGroupName=policyDetailsMap.get(env.getProperty("TLS_ENABLED_POLICY")).getPolicyGroupName();
								policyModelList=codeAnalysisReportDTO.getPolicyMap().get(policyGroupName);
								for(PolicyModelClass policyModelClass:policyModelList) {
									if(policyModelClass.getPolicyName().equalsIgnoreCase(env.getProperty("TLS_ENABLED_POLICY"))) {
										policyModelClass.setEnabled(true);
										break;
									}
								}
							}
						}
					}

				}
			}
			if (!fileName.isEmpty()) {
				setReportDetail(fileName, version, directoryName, codeAnalysisReportDTO);
			}
		}
		
		
	}		

	/**
	 * Reading policydetails and adding into another Map called policyMap in PolicyGroup wise, policyGroupName as "key" and its policydetails as "value".
	 * @param policyDetailsMap - Contains all policy names as "key" and its details as "value"
	 * @param codeAnalysisReportDTO
	 */
	public void mapAssignedPoliciesForProject(Map<String, PolicyDetailsDTO> policyDetailsMap, CodeAnalysisReportDTO codeAnalysisReportDTO) {
		ArrayList<PolicyModelClass> policyModelList=null;
		for(PolicyDetailsDTO poliydetailsDTO:policyDetailsMap.values()) {
			PolicyModelClass policyModel=new PolicyModelClass();
			policyModel.setPolicyFileName(poliydetailsDTO.getPolicyFileName());
			policyModel.setPolicyName(poliydetailsDTO.getPolicyName());
			policyModel.setWeight(poliydetailsDTO.getPolicyModifiedWeight());
			policyModel.setEnabled(false);
			policyModel.setPolicyRisk(poliydetailsDTO.getPolicyRisk());
			policyModel.setComments(poliydetailsDTO.getPolicyRefLink());
			policyModel.setPolicyGroupName(poliydetailsDTO.getPolicyGroupName());
			policyModelList=getPolicyModelList(codeAnalysisReportDTO.getPolicyMap(), poliydetailsDTO.getPolicyGroupName());
			policyModelList.add(policyModel);
		}
	}

	public void saveReport(String jsonAbsolutePath, Integer userId, String projectId, CodeAnalysisReportDTO codeAnalysisReportDTO) {
		ReportDO reportDO;
		reportDO = new ReportDO();
		reportDO.setUserId(userId);
		reportDO.setProjectId(projectId);		
		reportDO.setReportLocation(jsonAbsolutePath);
		if(codeAnalysisReportDTO.getReportTO()!=null) {
			String convertedDate = convertStringDateToDateTime(
					codeAnalysisReportDTO.getReportTO().getLastUpdatedDate());
			reportDO.setLastUpdatedDate(convertedDate);
			reportDO.setVersionId(codeAnalysisReportDTO.getReportTO().getVersionId());
			reportDO.setVulCount(codeAnalysisReportDTO.getReportTO().getVulCount());						
		}		

		try {
			getReportDAO().insert(reportDO);
		} catch (Exception e) {
			
			logger.info("This is an info message");
			logger.error("error message is",e);
		}

	}

	/**
	 * Converting String Date to DateandTime Type
	 * 
	 * @param lastUpdatedDate
	 * @return
	 */
	private String convertStringDateToDateTime(String lastUpdatedDate) {

		String dateStr = lastUpdatedDate;
		DateFormat readFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		DateFormat writeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = null;
		try {
			date = readFormat.parse(dateStr);
		} catch (ParseException e) {
			
			logger.info("This is an info message");
			logger.error("error message is",e);
		}

		String formattedDate = "";
		if (date != null) {
			formattedDate = writeFormat.format(date);
		}

		return formattedDate;

	}

	/**
	 * Adding Project MetaData Information
	 * 
	 * @param orgFileName
	 * @param version
	 * @param directoryName
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 */
	private void setReportDetail(String orgFileName, String version, String directoryName, CodeAnalysisReportDTO codeAnalysisReportDTO)
			throws ParserConfigurationException, SAXException, IOException {
		if(codeAnalysisReportDTO.getReportTO()==null) {
			codeAnalysisReportDTO.setReportTO(new ReportTO());
		}
		String pattern = "dd/MM/yyyy HH:mm:ss";
		int countAPI = 0;
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			// total Number policies
			if (file.getName().equals(env.getProperty("PROXIES_FOLDER"))) {
				for (File file1 : file.listFiles()) {
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document doc = dBuilder.parse(file1);
					doc.getDocumentElement().normalize();
					NodeList nList = (NodeList) doc.getElementsByTagName(env.getProperty("FLOW_TAG"));
					if (nList.getLength() == 0) {
						countAPI = 1;
					} else {
						countAPI = nList.getLength();
					}
				}
			}
		}
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		if (orgFileName.contains(env.getProperty("ZIP_EXTN"))) {
			String fileName = orgFileName.substring(0, orgFileName.indexOf("."));
			codeAnalysisReportDTO.getReportTO().setProjectId(fileName);
		} else {
			codeAnalysisReportDTO.getReportTO().setProjectId(orgFileName);
		}
		String currentDate = simpleDateFormat.format(new Date());
		codeAnalysisReportDTO.getReportTO().setLastUpdatedDate(currentDate);
		codeAnalysisReportDTO.getReportTO().setVersionId(Integer.parseInt(version));
		codeAnalysisReportDTO.getReportTO().setTotalAPIScanned(countAPI);

	}
	
	/**
	 * Adding policydetails into Map with policyGroupName as key and policydetails as value, so that in Report UI, we can dynamically show the PolicyGroup with policydetails like DeveloperView & ExecutiveView
	 * @param scanReportMap - policyGroupName as key and policydetails as value
	 * @param policyGroupName
	 * @return
	 */
	private ArrayList<PolicyModelClass> getPolicyModelList(Map<String, ArrayList<PolicyModelClass>> scanReportMap, String policyGroupName){		
		ArrayList<PolicyModelClass> policyModelList=null;
		if(scanReportMap.get(policyGroupName)!=null) {
			return scanReportMap.get(policyGroupName);
		}else {
			policyModelList=new ArrayList<PolicyModelClass>();		
			scanReportMap.put(policyGroupName, policyModelList);
		}
		return policyModelList;
	}

	/**
	 * Fetching previous report details
	 * 
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<ReportDO> fetchPreviousReportDetails(Integer userId) throws SQLException {
		return getReportDAO().fetchPreviousReportDetails(userId);
	}
	
	public LinkedHashMap<String, ArrayList<PreviousReportDTO>> fetchPreviousReports(Integer userName) throws SQLException {
		return getReportDAO().fetchPreviousReports(userName);
	}
	
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> fetchProjectAdmin(String userName) throws SQLException {
		return getReportDAO().fetchProjectAdmin(userName);
	}
	
	/**
	 * @param adminUserDTO
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> saveAdminDetails(AdminUserDTO adminUserDTO, String userRole, String userName) throws SQLException {
		return getReportDAO().saveAdminDetails(adminUserDTO, userRole, userName);
	}
	
	/**
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> retrieveProjectDetails(String userName) throws SQLException{
		return getReportDAO().retrieveProjectDetails(userName);
	}
	
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public String fetchUserRole(String userName) throws SQLException {
		return getReportDAO().fetchUserRole(userName);
	}
	
	/**
	 * @param adminUserDTO
	 * @return
	 * @throws SQLException
	 */
	public Integer saveProjectUser(AdminUserDTO adminUserDTO) throws SQLException {
		return getReportDAO().saveProjectUser(adminUserDTO);
	}
	
	/**
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> retrieveProjectUser(String projectId) throws SQLException {
		return getReportDAO().retrieveProjectUser(projectId);
	}
	
	/**
	 * @param projectId
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	public Boolean checkUserExists(String projectId, String userId) throws SQLException {
		return getReportDAO().checkUserExists(projectId, userId);
	}
	
	/**
	 * @param projectName
	 * @param projectType
	 * @return
	 * @throws SQLException
	 */
	public Boolean checkProjectAdminExists(String projectName, String projectType, Integer userId) throws SQLException {
		return getReportDAO().checkProjectAdminExists(projectName, projectType, userId);
	}
	
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public Integer fetchUserId(String userName) throws SQLException {
		return getReportDAO().fetchUserId(userName);
	}
	
	/**
	 * @param projectId
	 * @param userIdArray
	 * @return
	 * @throws SQLException
	 */
	public Integer deleteUser(String projectId, String[] userIdArray) throws SQLException {
		return getReportDAO().deleteUser(projectId, userIdArray);
	}
		
	/**
	 * @param userId
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public String fetchProjectAdminName(Integer userId, String projectId) throws SQLException {
		return getReportDAO().fetchProjectAdminName(userId, projectId);
	}
	
	/**
	 * Saving PolicyDetails into Database
	 * @param policyDetailsList
	 * @return
	 * @throws SQLException
	 */
	public boolean savePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
		return getPolicyDetailsDAO().savePolicyDetails(policyDetailsList);
	}
	
	/**
	 * Fetching Policy details from database for the selected project.
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyDetails(String projectId) throws SQLException {
		return getPolicyDetailsDAO().retrievePolicyDetails(projectId);
	}
	
	/**
	 * @return Retrieving PolicyMapping details
	 * @throws SQLException
	 */
	public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyMappingDetails() throws SQLException {
		return getPolicyDetailsDAO().retrievePolicyMappingDetails();
	}
	
	/**
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<PolicyDetailsDTO> checkPolicyExistForProject(String projectId) throws SQLException {
		return getPolicyDetailsDAO().checkPolicyExistForProject(projectId);
	}
	
	/**
	 * @param policyDetailsList
	 * @return
	 * @throws SQLException
	 */
	public boolean updatePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
		return getPolicyDetailsDAO().updatePolicyDetails(policyDetailsList);
	}
	
	/**
	 * @param policyDetailsList
	 * @return
	 * @throws SQLException
	 */
	public boolean deletePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
		return getPolicyDetailsDAO().deletePolicyDetails(policyDetailsList);
	}
	
	/**
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public boolean isPolicyMappedForProject(String projectId) throws SQLException {
		return getPolicyDetailsDAO().isPolicyMappedForProject(projectId);
	}
	
	/**
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public Map<String, PolicyDetailsDTO> fetchPolicydetailsForProject(String projectId) throws SQLException {
		return getPolicyDetailsDAO().fetchPolicydetailsForProject(projectId);
	}
	
	/**
	 * @param projectId
	 * @return
	 * @throws SQLException
	 */
	public Map<String, ArrayList<PolicyDetailsDTO>> fetchPolicyMappingDetails(String projectId) throws SQLException {
		return getPolicyDetailsDAO().fetchPolicyMappingDetails(projectId);
	}
	
	/**
	 * @return
	 * @throws SQLException
	 */
	public Map<String, PolicyDetailsDTO> fetchPolicyMappingForScan() throws SQLException {
		return getPolicyDetailsDAO().fetchPolicyMappingForScan();
	}
}
