package com.accenture.apigee.dao;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.accenture.apigee.main.MySqlConnection;
import com.accenture.apigee.model.AdminUserDTO;
import com.accenture.apigee.model.PreviousReportDTO;
import com.accenture.apigee.model.ReportDO;
import com.accenture.apigee.model.UserDTO;

/**
 * @author kanchan.khushboo
 *
 */
@Repository
public class ReportDAOImpl {
	final Logger logger = LoggerFactory.getLogger(ReportDAOImpl.class);
	
	@Autowired
	MySqlConnection mySqlConn;
	
	
	
	public MySqlConnection getMySqlConn() {
		return mySqlConn;
	}

	public void setMySqlConn(MySqlConnection mySqlConn) {
		this.mySqlConn = mySqlConn;
	}

	/**
	 * @param reportDO
	 * @throws SQLException 
	 * Insert the record in vulnerabilityreport Table
	 */
	public void insert(ReportDO reportDO) throws SQLException {
//		String username = reportDO.getUsername();
		Integer userId = reportDO.getUserId();
		String projectId = reportDO.getProjectId();
		Integer revisionId = reportDO.getVersionId();
		String lastScanDate = reportDO.getLastUpdatedDate();
		String location = reportDO.getReportLocation();
//		Integer vulCount=(17-reportDO.getVulCount());
		Connection connection = null;
		PreparedStatement stmt = null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			
			stmt = connection
					.prepareStatement("INSERT INTO vulnerabilityreport VALUES (?,?,?,?,?,?)");
			stmt.setInt(1, userId);
			stmt.setString(2, projectId);
			stmt.setInt(3, revisionId);
			stmt.setString(4, lastScanDate);
			stmt.setString(5, location);
			stmt.setInt(6,reportDO.getVulCount());
			stmt.executeUpdate();

		} catch (SQLException e) {
			
			logger.error("error found in method insert",e);
			return;
		} finally {
			MySqlConnection.close(connection);
		}
	}

	/**Login Validation through DB Check
	 * @param userId
	 * @param password
	 * @throws SQLException 
	 */
	public String loginValidation(String userName, String password) throws SQLException {

		Connection connection = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		String msg = null;
//		String dbUsername, dbPassword;
		try {
			connection = getMySqlConn().getConnectionInstance();
			String query = "SELECT 1 FROM user where userName=? and password=?";
			psmt = connection.prepareStatement(query);
			psmt.setString(1, userName);
			psmt.setString(2, password);
			rs = psmt.executeQuery();
			if (rs.next()) {
				/*dbUsername = rs.getString("userName");
				dbPassword = rs.getString("password");
			
				if (dbUsername.equals(userName) && dbPassword.equals(password)) {*/
					msg = "success";

				/*} else {
					msg = "fail";
				}*/
			}else {
				msg = "fail";
			}
		}
		catch (SQLException e) {
			
			logger.error("error found in method loginValidation",e);
		} finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return msg;

	}
	
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<ReportDO> fetchPreviousReportDetails(Integer userId) throws SQLException {
		ArrayList<ReportDO> prevReportList = new ArrayList<ReportDO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select vulnerabilityreport.*, projectdetails.projectName from vulnerabilityreport left join projectdetails on vulnerabilityreport.projectId=projectdetails.projectId where vulnerabilityreport.userId=? order by lastScanDate desc");
			stmt.setInt(1, userId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				ReportDO reportDO = new ReportDO();
				reportDO.setProjectId(rs.getString("projectId"));
				reportDO.setLastUpdatedDate(rs.getString("lastScanDate"));
				reportDO.setReportLocation(rs.getString("reportLocation"));
				reportDO.setVersionId(rs.getInt("projectRevision"));
				reportDO.setProjectName(rs.getString("projectName"));
				prevReportList.add(reportDO);
			}
		} catch (SQLException e) {
			
			logger.error("error found in method fetchPreviousReportDetails :",e);
			return prevReportList;
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return prevReportList;
	}
	public LinkedHashMap<String, ArrayList<PreviousReportDTO>> fetchPreviousReports(Integer userId) throws SQLException {
		ArrayList<PreviousReportDTO> prevReportList = new ArrayList<PreviousReportDTO>();		
		LinkedHashMap<String, ArrayList<PreviousReportDTO>> prevReportMap = new LinkedHashMap<String, ArrayList<PreviousReportDTO>>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select vulnerabilityreport.*, projectdetails.projectName from vulnerabilityreport left join projectdetails on vulnerabilityreport.projectId=projectdetails.projectId where vulnerabilityreport.userId=? order by lastScanDate desc");
			stmt.setInt(1, userId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				if(!prevReportMap.containsKey(rs.getString("projectId"))) {
					prevReportList = new ArrayList<PreviousReportDTO>();
					prevReportMap.put(rs.getString("projectId"), prevReportList);
				}else {
					prevReportList=prevReportMap.get(rs.getString("projectId"));
				}
				
				PreviousReportDTO prevReportDTO = new PreviousReportDTO();
				prevReportDTO.setProjectId(rs.getString("projectId"));
				prevReportDTO.setProjectName(rs.getString("projectName"));
				prevReportDTO.setLastUpdated(rs.getString("lastScanDate"));
				prevReportDTO.setVersionId(""+rs.getInt("projectRevision"));
				prevReportDTO.setReportLocation(rs.getString("reportLocation"));
				prevReportDTO.setVulCount(rs.getInt("vulcount"));
				
				if(prevReportDTO.getReportLocation()!=null) { //"/"  && prevReportDTO.getReportLocation().contains(File.separator)
					if(prevReportDTO.getReportLocation().contains(File.separator)) {
						prevReportDTO.setPrevReportName(prevReportDTO.getReportLocation().substring(prevReportDTO.getReportLocation().lastIndexOf(File.separator)+1, prevReportDTO.getReportLocation().length()));
					} else if(prevReportDTO.getReportLocation().contains("/")) {
						prevReportDTO.setPrevReportName(prevReportDTO.getReportLocation().substring(prevReportDTO.getReportLocation().lastIndexOf("/")+1, prevReportDTO.getReportLocation().length()));
					}else if(prevReportDTO.getReportLocation().contains("\"")) {
						prevReportDTO.setPrevReportName(prevReportDTO.getReportLocation().substring(prevReportDTO.getReportLocation().lastIndexOf("\"")+1, prevReportDTO.getReportLocation().length()));
					}
					if(prevReportDTO.getPrevReportName()!=null && prevReportDTO.getPrevReportName().endsWith(".json")) {
						prevReportDTO.setPrevReportName(prevReportDTO.getPrevReportName().substring(0, prevReportDTO.getPrevReportName().indexOf(".json")));
					}
				}
				prevReportList.add(prevReportDTO);
			}			
		} catch (SQLException e) {
			
			logger.error("error found in method fetchPreviousReports :",e);
			return prevReportMap;
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return prevReportMap;
	}
	//trends implementation
	
		public ArrayList<ReportDO> fetchTrendsDetails(String projectId,String date,Integer userId) throws SQLException {
			ArrayList<ReportDO> trendList = new ArrayList<ReportDO>();
			Connection connection = null;
			PreparedStatement stmt = null;
			try {
				connection = getMySqlConn().getConnectionInstance();
				stmt = connection
						.prepareStatement("select vulnerabilityreport.*, projectdetails.projectName from vulnerabilityreport left join projectdetails on vulnerabilityreport.projectId=projectdetails.projectId where vulnerabilityreport.userId=? and vulnerabilityreport.projectId=? and lastScanDate<=(?) order by lastScanDate desc limit 5");				
				stmt.setInt(1,userId);
				stmt.setString(2, projectId);
				stmt.setString(3,date);
				ResultSet rs = stmt.executeQuery();
			
				while (rs.next()) {
					ReportDO reportDO = new ReportDO();
					reportDO.setProjectId(rs.getString("projectId"));
					reportDO.setLastUpdatedDate(rs.getString("lastScanDate"));
					reportDO.setReportLocation(rs.getString("reportLocation"));
					reportDO.setVersionId(rs.getInt("projectRevision"));
					reportDO.setVulCount(rs.getInt("vulcount"));
					reportDO.setProjectName(rs.getString("projectName"));
					trendList.add(reportDO);
					
				}
			} catch (SQLException e) {
				
				logger.error("error found in method fetchTrendsDetails :",e);
				return trendList;
			}
			return trendList;
		}
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> fetchProjectAdmin(String userName) throws SQLException {
		ArrayList<AdminUserDTO> projectAdminList = new ArrayList<AdminUserDTO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select * from user where roleId in (select roleId from role where roleName=?);");
//			stmt.setString(1, "projectadmin");
			stmt.setString(1, userName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				AdminUserDTO adminUserDTO = new AdminUserDTO();				
				adminUserDTO.setProjectAdminId(rs.getInt("userId"));
				adminUserDTO.setProjectAdminName(rs.getString("userName"));
				adminUserDTO.setProjectUserId(rs.getString("userId"));
				adminUserDTO.setProjectUserName(rs.getString("userName"));
				projectAdminList.add(adminUserDTO);
			}
		} catch (SQLException e) {
			
			logger.error("error found in method fetchProjectAdmin : ",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return projectAdminList;
	}
	
	/**
	 * @param adminUserDTO
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> saveAdminDetails(AdminUserDTO adminUserDTO, String userRole, String userName) throws SQLException {
		ArrayList<AdminUserDTO> projectAdminList = null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("INSERT INTO projectdetails VALUES (?,?,?,?,?)");
			if(adminUserDTO!=null) {
				stmt.setString(1, adminUserDTO.getProjectId());
				stmt.setString(2, adminUserDTO.getProjectName());
				stmt.setString(3, adminUserDTO.getProjectType());
				stmt.setInt(4, adminUserDTO.getProjectAdminId());
				stmt.setString(5, adminUserDTO.getCreateDate());
			}
			
//			stmt.setString(2, userName);
			int successIndex=stmt.executeUpdate();
			if(successIndex>0) {
				if(userRole!=null && userRole.length()>0) {
					if(userRole.equalsIgnoreCase("ProjectAdmin")) {
						//Fetch saved project details to display in AdminPage tabular column.
						projectAdminList=retrieveProjectDetailsForProjectAdminFromDB(connection, stmt, rs, projectAdminList, userName);
					}else {
						//Fetch saved project details to display in AdminPage tabular column.
						projectAdminList=retrieveProjectDetailsForAdminFromDB(connection, stmt, rs, projectAdminList);
					}
				}
												
			}
		} catch (SQLException e) {
			
			logger.error("error found in method saveAdminDetails :",e);
		}finally {			
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return projectAdminList;
	}
	
	public ArrayList<AdminUserDTO> retrieveProjectDetailsForAdminFromDB(Connection connection, PreparedStatement stmt, ResultSet rs, ArrayList<AdminUserDTO> projectAdminList) throws SQLException {
		try {
			projectAdminList = new ArrayList<AdminUserDTO>();
			stmt = connection
					.prepareStatement("select projectdetails.*,user.userName from projectdetails left join user on projectdetails.userId=user.userId order by CreateDate desc;");
			
			rs = stmt.executeQuery();
			while (rs.next()) {
				AdminUserDTO projectDetailsDTO = new AdminUserDTO();
				projectDetailsDTO.setProjectId(rs.getString("projectId"));
				projectDetailsDTO.setProjectName(rs.getString("projectName"));
				projectDetailsDTO.setProjectType(rs.getString("projectType"));
				projectDetailsDTO.setProjectAdminId(rs.getInt("userId"));
				projectDetailsDTO.setProjectAdminName(rs.getString("userName"));
				projectDetailsDTO.setCreateDate(rs.getString("CreateDate"));
				projectAdminList.add(projectDetailsDTO);
			}
		}catch (SQLException e) {
			throw e;
		}
		return projectAdminList;
	}
	
	public ArrayList<AdminUserDTO> retrieveProjectDetailsForProjectAdminFromDB(Connection connection, PreparedStatement stmt, ResultSet rs, ArrayList<AdminUserDTO> projectAdminList, String userName) throws SQLException {
		try {
			projectAdminList = new ArrayList<AdminUserDTO>();
			stmt = connection
					.prepareStatement("select projectdetails.*,user.userName from projectdetails left join user on projectdetails.userId=user.userId where projectdetails.userId in (select userId from user where userName=?) order by CreateDate desc");
			stmt.setString(1, userName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				AdminUserDTO projectDetailsDTO = new AdminUserDTO();
				projectDetailsDTO.setProjectId(rs.getString("projectId"));
				projectDetailsDTO.setProjectName(rs.getString("projectName"));
				projectDetailsDTO.setProjectType(rs.getString("projectType"));
				projectDetailsDTO.setProjectAdminId(rs.getInt("userId"));
				projectDetailsDTO.setProjectAdminName(rs.getString("userName"));
				projectDetailsDTO.setCreateDate(rs.getString("CreateDate"));
				projectAdminList.add(projectDetailsDTO);
			}
		}catch (SQLException e) {
			throw e;
		}
		return projectAdminList;
	}
	
	public ArrayList<AdminUserDTO> retrieveProjectDetails(String userName) throws SQLException {
		ArrayList<AdminUserDTO> projectAdminList = null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			
			//Fetch saved project details to display in AdminPage tabular column.
			if(userName!=null) {
				projectAdminList=retrieveProjectDetailsForProjectAdminFromDB(connection, stmt, rs, projectAdminList, userName);
			}else {
				projectAdminList=retrieveProjectDetailsForAdminFromDB(connection, stmt, rs, projectAdminList);
			}													
		} catch (SQLException e) {
			
			logger.error("error message is in method retrieveProjectDetails : ",e);
		}finally {			
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return projectAdminList;
	}
	
	public String fetchUserRole(String userName) throws SQLException {
		String roleName=null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select roleName from role where roleId in (select roleId from user where userName=?);");
//			stmt.setString(1, "projectadmin");
			stmt.setString(1, userName);
			rs = stmt.executeQuery();
			if(rs.next()) {				
				roleName=rs.getString("roleName");								
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method fetchUserRole : ",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return roleName;
	}
	
	/**
	 * @param adminUserDTO
	 * @return
	 * @throws SQLException
	 */
	public Integer saveProjectUser(AdminUserDTO adminUserDTO) throws SQLException {
		Connection connection = null;
		PreparedStatement stmt = null;		
		Integer successIndex=-1;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("INSERT INTO projectuser VALUES (?,?,?)");
			if(adminUserDTO!=null) {
				stmt.setString(1, adminUserDTO.getProjectId());
				stmt.setString(2, adminUserDTO.getProjectUserId());	
				stmt.setString(3, adminUserDTO.getCreateDate());
			}
			
			successIndex=stmt.executeUpdate();			
		} catch (SQLException e) {
			
			logger.error("error message is in method saveProjectUser :",e);
		}finally {			
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return successIndex;
	}
	
	public ArrayList<AdminUserDTO> retrieveProjectUser(String projectId) throws SQLException {
		ArrayList<AdminUserDTO> projectUserList = new ArrayList<AdminUserDTO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select projectuser.*, user.userName from projectuser left join user on projectuser.userId=user.userId where projectId=? order by CreateDate desc");
//			stmt.setString(1, "projectadmin");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				AdminUserDTO adminUserDTO = new AdminUserDTO();				
				adminUserDTO.setProjectUserId(rs.getString("userId"));
				adminUserDTO.setProjectUserName(rs.getString("userName"));
				adminUserDTO.setProjectId(rs.getString("projectId"));
				adminUserDTO.setCreateDate(rs.getString("CreateDate"));
				projectUserList.add(adminUserDTO);
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method retrieveProjectUser :",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return projectUserList;
	}
	
	public Boolean checkUserExists(String projectId, String userId) throws SQLException {		
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select * from projectuser where projectId=? and userId=?;");
			stmt.setString(1, projectId);
			stmt.setString(2, userId);
			rs = stmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method checkUserExists :",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return false;
	}
	
	public Boolean checkProjectAdminExists(String projectName, String projectType, Integer userId) throws SQLException {		
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select * from projectdetails where projectName=? and projectType=? and userId=?");
			stmt.setString(1, projectName);
			stmt.setString(2, projectType);
			stmt.setInt(3, userId);			
			rs = stmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method checkProjectAdminExists :",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return false;
	}
	
	public Integer fetchUserId(String userName) throws SQLException {
		Integer userId=null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select * from user where userName=?;");
//			stmt.setString(1, "projectadmin");
			stmt.setString(1, userName);
			rs = stmt.executeQuery();
			if(rs.next()) {				
				userId=rs.getInt("userId");								
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method fetchUserId : ",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return userId;
	}

	public ArrayList<AdminUserDTO> fetchProjectsForUser(String username, String roleName) throws SQLException {
		ArrayList<AdminUserDTO> projectList = new ArrayList<AdminUserDTO>();
		Connection connection = null;
		PreparedStatement psmt = null;
		ResultSet results = null;
		String query = null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			if (roleName.equalsIgnoreCase("Admin")) {
				query = "SELECT * from projectdetails order by CreateDate desc";
				psmt = connection.prepareStatement(query);
			} else if (roleName.equalsIgnoreCase("ProjectAdmin")) {
				query = "SELECT projectdetails.* from projectdetails where userId in (select userId from user where username= ?) order by CreateDate desc";
				psmt = connection.prepareStatement(query);
				psmt.setString(1, username);
			}else if (roleName.equalsIgnoreCase("User")) {
				query = "SELECT projectdetails.* from projectdetails left join projectuser on projectdetails.projectId=projectuser.projectId where projectuser.userId in (select userId from user where userName=?) order by CreateDate desc";
				psmt = connection.prepareStatement(query);
				psmt.setString(1, username);

			}			
			results = psmt.executeQuery();
			while(results.next()) {
				AdminUserDTO projectDetailsDTO = new AdminUserDTO();
				projectDetailsDTO.setProjectId(results.getString("projectId"));
				projectDetailsDTO.setProjectName(results.getString("projectName"));
				projectDetailsDTO.setProjectType(results.getString("projectType"));
				projectDetailsDTO.setProjectAdminId(results.getInt("userId"));
				projectDetailsDTO.setCreateDate(results.getString("CreateDate"));
				projectList.add(projectDetailsDTO);
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method fetchProjectsForUser : ",e);
		} finally {
			results.close();
			MySqlConnection.close(connection);
		}
		return projectList;
	}

	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public UserDTO getUserRole(String userName) throws SQLException {
		Connection connection = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		UserDTO userDTO = null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			String query = "select userId,user.roleId,role.roleName FROM user left join role on user.roleId=role.roleId where userName=?;";
			psmt = connection.prepareStatement(query);
			psmt.setString(1, userName);
			rs = psmt.executeQuery();
			if (rs.next()) {
				userDTO = new UserDTO();
				userDTO.setUserId(rs.getInt("userId"));
				userDTO.setRoleId(rs.getInt("roleId"));
				userDTO.setRoleName(rs.getString("roleName"));
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method  getUserRole",e);
		} finally {
			rs.close();
			MySqlConnection.close(connection);
		}
		return userDTO;
	}
	
	public Integer deleteUser(String projectId, String[] userIdArray) throws SQLException {
		Connection connection = null;
		PreparedStatement stmt = null;		
		Integer successIndex=-1, rowCount=2;
		String whereParam="";
		if(userIdArray!=null && userIdArray.length>0) {
			for(int i=0;i<userIdArray.length;i++) {
				whereParam=whereParam+"?,";
			}
			if(whereParam.endsWith(",")) {
				whereParam=whereParam.substring(0, whereParam.length()-1);
			}
			
			String deleteQry="delete from projectuser where projectId=? and userId in ("+whereParam+");";
			try {
				connection = getMySqlConn().getConnectionInstance();
				stmt = connection
						.prepareStatement(deleteQry);			
				stmt.setString(1, projectId);							
				for(String userId:userIdArray) {
					stmt.setString(rowCount, userId);
					rowCount++;
				}
				successIndex=stmt.executeUpdate();			
			} catch (SQLException e) {
				
				logger.error("error message is in method deleteUser :",e);
			}finally {			
				if(connection!=null)
					MySqlConnection.close(connection);
			}
		}		
		return successIndex;
	}
	
	public String fetchProjectAdminName(Integer userId, String projectId) throws SQLException {
		String projectAdminName=null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select userName from user where userId in (select projectdetails.userId from projectdetails,projectuser where projectdetails.projectId=projectuser.projectId and projectuser.projectId=? and projectuser.userId=?)");
			stmt.setString(1, projectId);
			stmt.setInt(2, userId);
			rs = stmt.executeQuery();
			if(rs.next()) {				
				projectAdminName=rs.getString("userName");								
			}
		} catch (SQLException e) {
			
			logger.error("error message is in method fetchProjectAdminName",e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return projectAdminName;
	}
}