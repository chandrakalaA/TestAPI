package com.accenture.apigee.main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.accenture.apigee.dao.ReportDAOImpl;
import com.accenture.apigee.model.APIMapping;
import com.accenture.apigee.model.AdminUserDTO;
import com.accenture.apigee.model.CodeAnalysisReportDTO;
import com.accenture.apigee.model.PolicyDetailsDTO;
import com.accenture.apigee.model.PolicyModelClass;
import com.accenture.apigee.model.PreviousReportDTO;
import com.accenture.apigee.model.ReportDO;
import com.accenture.apigee.model.ReportTO;
import com.accenture.apigee.model.StoreJson;
import com.accenture.apigee.model.UserDTO;
import com.accenture.apigee.util.CodeAnalysisUtility;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
@PropertySource("classpath:apisecConfig.properties")
public class CodeAnalysis {
	
	
	@Autowired
	Environment env;
	
	@Autowired
	CodeAnalysisUtility analysisUtility;

	@Autowired
	public StoreJson storeJson;

	@Autowired
	ReportDAOImpl reportDAO;
	
	@Autowired
	APIMapping apiMapping;

	public String apiProxyDirectory;
	public String projectName;
	public String projectDirectoryURL;
	public String userName;
	
	//For AdminPage Requirement
	public String projectId;
	public Integer userId;
	
	public String proxyEndPoint;

	public String getProxyEndPoint() {
		return proxyEndPoint;
	}

	public void setProxyEndPoint(String proxyEndPoint) {
		this.proxyEndPoint = proxyEndPoint;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getApiProxyDirectory() {
		return apiProxyDirectory;
	}

	public void setApiProxyDirectory(String apiProxyDirectory) {
		this.apiProxyDirectory = apiProxyDirectory;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDirectoryURL() {
		return projectDirectoryURL;
	}

	public void setProjectDirectoryURL(String projectDirectoryURL) {
		this.projectDirectoryURL = projectDirectoryURL;
	}

	/**
	 * List all the files under a directory
	 * 
	 * @param directoryName
	 *            to be listed
	 * @param userName
	 * @param finalDirectoryURL
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 */
	public String listFiles(String directoryName, String fileName, String userName, String finalDirectoryURL, Integer userId, String projectId,HttpSession session)
			throws ParserConfigurationException, SAXException, IOException, SQLException, ParseException {
		apiProxyDirectory = directoryName;
		projectName = fileName;
		projectDirectoryURL = finalDirectoryURL;
		this.userName = userName;
		
		this.projectId=projectId;
		this.userId=userId;
		String jsonString = "", proxyEndPoint="";
		String version ="0";
		String s="";
		CodeAnalysisReportDTO codeAnalysisReportDTO=new CodeAnalysisReportDTO();
		Map<String, PolicyDetailsDTO> policyDetailsMap=null;
		//Fetching policymapping details from database for the scanned project with projectId, if there is no policymapping configured then we will fetch all default policymapping details from database
		if(analysisUtility.isPolicyMappedForProject(projectId)) {
			policyDetailsMap=analysisUtility.fetchPolicydetailsForProject(projectId);
		}else {
			policyDetailsMap=analysisUtility.fetchPolicyMappingForScan();
		}
		
		if(policyDetailsMap!=null && policyDetailsMap.size()>0) {
			File directory = new File(directoryName);
			
			// get all the files from a directory
			File[] fList = directory.listFiles();
			for (File file : fList) {
				if (file.isFile()) {
					DocumentBuilder dBuilder;
					dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
					Document doc = dBuilder.parse(file);
					doc.getDocumentElement().normalize();
					doc.getElementsByTagName(env.getProperty("PROXY_END_POINTS"));
					// code added to fecth revisionId.
					NodeList nList = (NodeList) doc.getElementsByTagName(env.getProperty("API_PROXY_TAG"));
					for (int temp = 0; temp < nList.getLength(); temp++) {
						Node nNode = nList.item(temp);
						if (nNode.getNodeType() == Node.ELEMENT_NODE) {
							Element eElement = (Element) nNode;
							if(eElement.getAttribute(env.getProperty("REVISION_ATTR")) != "") {
							version = eElement.getAttribute(env.getProperty("REVISION_ATTR"));
						}
						
						}
					}
						//Fetching proxyEndPoint name from given project's APIProxy file, if it is not available, we are checking defualt.xml file is present, if defualt.xml file also not present then the project is not able to scan so returning empty json string to show validation message in UI
						proxyEndPoint=fetchProxyEndPoint(doc);
						this.setProxyEndPoint(proxyEndPoint);
						if(proxyEndPoint==null || proxyEndPoint.length()==0) {
//							proxyEndPoint="default";
							return "";
						}
						File proxyEndPointFile = new File(directoryName + File.separator + env.getProperty("PROXIES_FOLDER") + File.separator + proxyEndPoint + env.getProperty("XML_EXTN"));
						if(!proxyEndPointFile.exists()) {
							return "";
						}						
						analysisUtility.mapAssignedPoliciesForProject(policyDetailsMap, codeAnalysisReportDTO);
						try {
						analysisUtility.validatePolicies(directoryName, false,
								fileName, version, policyDetailsMap, codeAnalysisReportDTO, proxyEndPoint,session);
						}catch(Exception e)
						{
							s = e.getMessage();
							System.out.println(s);
							if(s=="SharedFlowBundle does not exist")
								return "error in shared flow";
						}	 
						
						calculatePolicyGroupTotal(codeAnalysisReportDTO);
						apiMapping.getMappingAPI(codeAnalysisReportDTO);
						Gson gson = new GsonBuilder().setPrettyPrinting().create();
						jsonString = gson.toJson(codeAnalysisReportDTO);						
				}
			}

			if(jsonString.length()>0) {
				storeJson.downloadReport(jsonString, userName, projectName, codeAnalysisReportDTO.getReportTO()!=null?codeAnalysisReportDTO.getReportTO().getLastUpdatedDate():null);
				String jsonAbsolutePath = storeJson.jsonFileAbsolutePath;				  
				// code added to save record in db.
				analysisUtility.saveReport(jsonAbsolutePath, userId, projectId, codeAnalysisReportDTO);
			}			
		}		
		return jsonString;
	}
	
	/**
	 * Finding proxy_end_point in base xml of apiproxy, if it does not contain then considering the proxy as invalid proxy bundle and returning "" string to show validation message in UI
	 * @param doc - base xml document inside apiproxy
	 * @return
	 */
	private String fetchProxyEndPoint(Document doc) {
		String proxyEndPoint=null;
		if(doc.getElementsByTagName(env.getProperty("PROXY_END_POINTS")).item(0)!=null) {
			Node proxyEndPointsNode=doc.getElementsByTagName(env.getProperty("PROXY_END_POINTS")).item(0);
			NodeList nList=proxyEndPointsNode.getChildNodes();
			if(nList!=null) {
				for(int i=0;i<nList.getLength();i++) {
					if(nList.item(i).getNodeName().equalsIgnoreCase(env.getProperty("PROXY_END_POINT"))) {
						proxyEndPoint=nList.item(i).getTextContent();
						if(proxyEndPoint.length()>0) {
							return proxyEndPoint;							
						}else {
//							return "default";
							return "";
						}
					}					
				}				
			}
		}
//		return "default";
		return "";
	}
	
	/**
	 * This method is for rendering Executive View Speedometer and Donut chart with values in Report UI
	 * @param codeAnalysisReportDTO - contains report details to render in UI
	 */
	private void calculatePolicyGroupTotal(CodeAnalysisReportDTO codeAnalysisReportDTO) {
		ArrayList<ReportTO> policyGroupTotalList=new ArrayList<ReportTO>();
		Integer critical=0, high=0, medium=0, low=0, totalPoliciesScanned=0, totalSecurityPoliciesAvailable=0;
		if(codeAnalysisReportDTO.getPolicyMap()!=null && codeAnalysisReportDTO.getPolicyMap().size()>0) {
			for(ArrayList<PolicyModelClass> policyModelList:codeAnalysisReportDTO.getPolicyMap().values()) {
				Integer policyTotal=0;
				if(policyModelList!=null && policyModelList.size()>0) {
					for(PolicyModelClass policyModelClass:policyModelList) {
						if(policyModelClass!=null) {
							if(policyModelClass.isEnabled()) {
								policyTotal+=policyModelClass.getWeight();		
								totalPoliciesScanned+=1;
							}else {
								if(policyModelClass.getPolicyRisk()!=null) {
									if(policyModelClass.getPolicyRisk().equalsIgnoreCase(env.getProperty("CRITICAL_RISK"))) {
										critical+=1;
									}else if(policyModelClass.getPolicyRisk().equalsIgnoreCase(env.getProperty("MEDIUM_RISK"))) {
										medium+=1;
									}else if(policyModelClass.getPolicyRisk().equalsIgnoreCase(env.getProperty("HIGH_RISK"))) {
										high+=1;
									}else if(policyModelClass.getPolicyRisk().equalsIgnoreCase(env.getProperty("LOW_RISK"))) {
										low+=1;
									}
								}								
							}
						}
						totalSecurityPoliciesAvailable+=1;
					}
					ReportTO reportTO=new ReportTO();
					reportTO.setPolicyGroupName(policyModelList.get(0).getPolicyGroupName());
					reportTO.setPolicyGroupTotal(policyTotal);
					policyGroupTotalList.add(reportTO);
				}
			}
		}
		//Assigning PolicyRisk to render in Overall Vulnerability Donut chart in UI
		if(codeAnalysisReportDTO.getReportTO()!=null) {
			codeAnalysisReportDTO.getReportTO().setCritical(critical);
			codeAnalysisReportDTO.getReportTO().setHigh(high);
			codeAnalysisReportDTO.getReportTO().setMedium(medium);
			codeAnalysisReportDTO.getReportTO().setLow(low);
			codeAnalysisReportDTO.getReportTO().setTotalPolicyScanned(totalPoliciesScanned);
			codeAnalysisReportDTO.getReportTO().setTotalSecurityPoliciesAvailable(totalSecurityPoliciesAvailable);			
			codeAnalysisReportDTO.getReportTO().setVulCount(totalSecurityPoliciesAvailable-totalPoliciesScanned);			
		}
		//Below code is for rendering Executive View Speedometer with PolicyGroup wise Total in UI
		codeAnalysisReportDTO.setPolicyGroupTotalList(policyGroupTotalList);
	}

	/**
	 * List all files from a directory and its subdirectories
	 * 
	 * @param directoryName
	 *            to be listed
	 */
	public void listFilesAndFilesSubDirectories(String directoryName) {
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isFile()) {
			} else if (file.isDirectory()) {
				listFilesAndFilesSubDirectories(file.getAbsolutePath());
			}
		}
	}

	/**
	 * @param userId
	 * @param password
	 * @return
	 * @throws SQLException
	 *             Login Validation from db
	 */
	public String loginCheck(String userId, String password) throws SQLException {
		String str = reportDAO.loginValidation(userId, password);
		return str;
	}

	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<ReportDO> fetchPreviousReportDetails(Integer userName) throws SQLException {
		return analysisUtility.fetchPreviousReportDetails(userName);
	}
	
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public LinkedHashMap<String, ArrayList<PreviousReportDTO>> fetchPreviousReports(Integer userName) throws SQLException {
		return analysisUtility.fetchPreviousReports(userName);
	}

	//trends
	
	public ArrayList<ReportDO> fetchTrendDetails(String projectId,String date,Integer userId) throws SQLException {
		return reportDAO.fetchTrendsDetails(projectId, date,userId);
	}

	/**
	 * Fetching ProjectAdmin users list from database of role "ProjectAdmin"
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> fetchProjectAdmin(String userName) throws SQLException {
		return analysisUtility.fetchProjectAdmin(userName);
	}
	
	/**
	 * @param adminUserDTO - Contains Admin page field values
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> saveAdminDetails(AdminUserDTO adminUserDTO, String userRole, String userName) throws SQLException {
		return analysisUtility.saveAdminDetails(adminUserDTO, userRole, userName);
	}
	
	/**
	 * Fetching ProjectDetails from database for displaying in ProjectDetails table of UI
	 * @return
	 * @throws SQLException
	 */
	public ArrayList<AdminUserDTO> retrieveProjectDetails(String userName) throws SQLException{
		return analysisUtility.retrieveProjectDetails(userName);
	}
	
	public String fetchUserRole(String userName) throws SQLException{
		return analysisUtility.fetchUserRole(userName);
	}
	
	/**
	 * @param adminUserDTO
	 * @return
	 * @throws SQLException
	 */
	public Integer saveProjectUser(AdminUserDTO adminUserDTO) throws SQLException {
		return analysisUtility.saveProjectUser(adminUserDTO);
	}
	
	public ArrayList<AdminUserDTO> retrieveProjectUser(String projectId) throws SQLException {
		return analysisUtility.retrieveProjectUser(projectId);
	}
	
	/**
	 * @param projectId
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	public Boolean checkUserExists(String projectId, String userId) throws SQLException {
		return analysisUtility.checkUserExists(projectId, userId);
	}
	
	/**
	 * @param projectName
	 * @param projectType
	 * @return
	 * @throws SQLException
	 */
	public Boolean checkProjectAdminExists(String projectName, String projectType, Integer userId) throws SQLException {
		return analysisUtility.checkProjectAdminExists(projectName, projectType, userId);
	}
	
	/**
	 * @param userName
	 * @return
	 * @throws SQLException
	 */
	public Integer fetchUserId(String userName) throws SQLException {
		return analysisUtility.fetchUserId(userName);
	}

		/**
		 * @param userName
		 * @return
		 * @throws SQLException
		 */
		public UserDTO getUserRole(String userName) throws SQLException {
			return reportDAO.getUserRole(userName);		
		}
		
		/**
		 * @param username
		 * @param roleName
		 * @return
		 * @throws SQLException
		 */
		public ArrayList<AdminUserDTO> fetchProjectsForUser(String username, String roleName) throws SQLException {
			return reportDAO.fetchProjectsForUser(username, roleName);
		}
		
		/**
		 * @param projectId
		 * @param userIdArray
		 * @return
		 * @throws SQLException
		 */
		public Integer deleteUser(String projectId, String[] userIdArray) throws SQLException {
			return analysisUtility.deleteUser(projectId, userIdArray);
		}
		
		/**
		 * @param userId
		 * @param projectId
		 * @return
		 * @throws SQLException
		 */
		public String fetchProjectAdminName(Integer userId, String projectId) throws SQLException {
			return analysisUtility.fetchProjectAdminName(userId, projectId);
		}
		
		/**
		 * @param policyDetailsList
		 * @return
		 * @throws SQLException
		 */
		public boolean savePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException{
			return analysisUtility.savePolicyDetails(policyDetailsList);
		}
		/**
		 * @param projectId
		 * @return
		 * @throws SQLException
		 */
		public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyDetails(String projectId) throws SQLException {
			return analysisUtility.retrievePolicyDetails(projectId);
		}
		
		/**
		 * @return
		 * @throws SQLException
		 */
		public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyMappingDetails() throws SQLException {
			return analysisUtility.retrievePolicyMappingDetails();
		}
		
		/**
		 * @param projectId
		 * @return
		 * @throws SQLException
		 */
		public ArrayList<PolicyDetailsDTO> checkPolicyExistForProject(String projectId) throws SQLException {
			return analysisUtility.checkPolicyExistForProject(projectId);
		}
		
		/**
		 * @param policyDetailsList
		 * @return
		 * @throws SQLException
		 */
		public boolean updatePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
			return analysisUtility.updatePolicyDetails(policyDetailsList);
		}
		
		/**
		 * @param policyDetailsList
		 * @return
		 * @throws SQLException
		 */
		public boolean deletePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
			return analysisUtility.deletePolicyDetails(policyDetailsList);
		}
		
		/**
		 * @param projectId
		 * @return
		 * @throws SQLException
		 */
		public boolean isPolicyMappedForProject(String projectId) throws SQLException {
			return analysisUtility.isPolicyMappedForProject(projectId);
		}
		
		/**
		 * @param projectId
		 * @return
		 * @throws SQLException
		 */
		public Map<String, ArrayList<PolicyDetailsDTO>> fetchPolicyMappingDetails(String projectId) throws SQLException {
			return analysisUtility.fetchPolicyMappingDetails(projectId);
		}
}
