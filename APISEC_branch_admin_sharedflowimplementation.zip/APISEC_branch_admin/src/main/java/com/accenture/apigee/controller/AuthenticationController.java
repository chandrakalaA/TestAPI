/*******************************************************************************
 code for ADFS Single Sign On Integration
 ******************************************************************************/
package com.accenture.apigee.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.accenture.apigee.util.AuthHelper;
import com.microsoft.aad.adal4j.AuthenticationResult;

@Controller
@PropertySource("classpath:application.properties")
@RequestMapping("/")
public class AuthenticationController {
	
	@Value("${AuthenticationController.homePage}")
    private String homePage; 
	
	final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    /**
     * @param model
     * @param httpRequest
     * @return index page if user details available in session otherwise error page
     */
    @RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
    public String getDirectoryObjects(ModelMap model, HttpServletRequest httpRequest) {
    	logger.info("************AuthenticationController-getDirectoryObjects()************");     	
    	if((httpRequest.getRequestURL().toString()).contains(AuthHelper.APISEC_PROD)) {
    		HttpSession session = httpRequest.getSession();
            AuthenticationResult result = (AuthenticationResult) session.getAttribute(AuthHelper.PRINCIPAL_SESSION_NAME);
            if (result == null) {
            	logger.info("************AuthenticationController-getDirectoryObjects()=result************"+result);        	            
                httpRequest.setAttribute("error", new Exception("AuthenticationResult not found in session."));
                return "/error";
            }
    	}        
        return homePage;
    }
}
