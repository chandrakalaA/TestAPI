package com.accenture.apigee.model;
/**
 * @author kanchan.khushboo
 * Transfer object class
 */
public class ReportTO {
	
	private String projectId;
	
	private Integer versionId;

	private String lastUpdatedDate;
	
	private Integer vulCount;
	private String policyGroupName;
	private Integer policyGroupTotal;
	private Integer critical;
	private Integer high;
	private Integer medium;
	private Integer low;
	
	//hardcoded need to get from properties file -- manjunath
	private Integer totalSecurityPoliciesAvailable = 0 ;
	
	public Integer getTotalSecurityPoliciesAvailable() {
		return totalSecurityPoliciesAvailable;
	}

	public void setTotalSecurityPoliciesAvailable(Integer totalSecurityPoliciesAvailable) {
		this.totalSecurityPoliciesAvailable = totalSecurityPoliciesAvailable;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getReportLocation() {
		return reportLocation;
	}

	public void setReportLocation(String reportLocation) {
		this.reportLocation = reportLocation;
	}


	private Integer totalPolicyScanned=0;
	
	private Integer totalAPIScanned;
	
     private String userName;
	
	private String reportLocation; 
	
	
	

	public String getProjectId() {
		return projectId;
	}
	
	
	private static ReportTO reportTo = null;
	
	public static ReportTO getReport(boolean reset) {
		if (reportTo == null || reset) {
			reportTo = new ReportTO();
		}
		return reportTo;
	}
	
	public static ReportTO getReport() {
		if (reportTo == null)  {
			reportTo = new ReportTO();
		}
		return reportTo;
	}
	
	
	

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String currentDate) {
		this.lastUpdatedDate = currentDate;
	}

	public Integer getVulCount() {
		return vulCount;
	}

	public void setVulCount(Integer vulCount) {
		this.vulCount = vulCount;
	}

	public Integer getTotalPolicyScanned() {
		return totalPolicyScanned;
	}

	public void setTotalPolicyScanned(Integer totalPolicyScanned) {
		this.totalPolicyScanned = totalPolicyScanned;
	}

	public static ReportTO getReportTo() {
		return reportTo;
	}

	public static void setReportTo(ReportTO reportTo) {
		ReportTO.reportTo = reportTo;
	}

	public Integer getTotalAPIScanned() {
		return totalAPIScanned;
	}

	public void setTotalAPIScanned(Integer totalAPIScanned) {
		this.totalAPIScanned = totalAPIScanned;
	}

	public Integer getVersionId() {
		return versionId;
	}

	public void setVersionId(Integer versionId) {
		this.versionId = versionId;
	}

	public String getPolicyGroupName() {
		return policyGroupName;
	}

	public void setPolicyGroupName(String policyGroupName) {
		this.policyGroupName = policyGroupName;
	}

	public Integer getPolicyGroupTotal() {
		return policyGroupTotal;
	}

	public void setPolicyGroupTotal(Integer policyGroupTotal) {
		this.policyGroupTotal = policyGroupTotal;
	}

	public Integer getCritical() {
		return critical;
	}

	public void setCritical(Integer critical) {
		this.critical = critical;
	}

	public Integer getHigh() {
		return high;
	}

	public void setHigh(Integer high) {
		this.high = high;
	}

	public Integer getMedium() {
		return medium;
	}

	public void setMedium(Integer medium) {
		this.medium = medium;
	}

	public Integer getLow() {
		return low;
	}

	public void setLow(Integer low) {
		this.low = low;
	}
}
