package com.accenture.apigee.model;
/**
 * @author kanchan.khushboo
 *  Data Access Object Class
 */
public class ReportDO {
	
public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	private String projectId;
	private String username;
	private Integer userId;
	private String projectName;

	private Integer versionId;

	private String lastUpdatedDate;

	private String reportLocation;
	
	private Integer vulCount;

	public Integer getVulCount() {
		return vulCount;
	}

	public void setVulCount(Integer vulCount) {
		this.vulCount = vulCount;
	}


	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	

	public Integer getVersionId() {
		return versionId;
	}

	public void setVersionId(Integer versionId) {
		this.versionId = versionId;
	}

	
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getReportLocation() {
		return reportLocation;
	}

	public void setReportLocation(String reportLocation) {
		this.reportLocation = reportLocation;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	} 
	

}
