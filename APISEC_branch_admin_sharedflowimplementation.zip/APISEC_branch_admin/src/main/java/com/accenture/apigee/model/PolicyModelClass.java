package com.accenture.apigee.model;

public class PolicyModelClass {

	private String policyName;

	private boolean isEnabled;

	private Integer weight;

	private String comments;
	
	private String policyRisk;
	private String policyFileName;
	private String policyGroupName;

	
	public String getPolicyRisk() {
		return policyRisk;
	}

	public void setPolicyRisk(String policyRisk) {
		this.policyRisk = policyRisk;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getPolicyFileName() {
		return policyFileName;
	}

	public void setPolicyFileName(String policyFileName) {
		this.policyFileName = policyFileName;
	}

	public String getPolicyGroupName() {
		return policyGroupName;
	}

	public void setPolicyGroupName(String policyGroupName) {
		this.policyGroupName = policyGroupName;
	}

}
