package com.accenture.apigee.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FilenameUtils;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.xml.sax.SAXException;

import com.accenture.apigee.main.CodeAnalysis;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

/**
 * @author kanchan.khushboo
 *
 */
@Controller
public class FileUploadController {
	@Autowired
	Environment env;
	@Autowired
	private CodeAnalysis codeAnalysis;

	@Autowired
	private UploadController uploadController;
	private String directoryURLVerified = "";
	

	@Value("${UPLOADED_FOLDER}")
	private String tempDirPath;
	final Logger logger = LoggerFactory.getLogger(FileUploadController.class);

	/**
	 * @param req
	 * @param res
	 * @return
	 * @throws GitAPIException
	 * @throws TransportException
	 * @throws InvalidRemoteException
	 * @throws ZipException           Download the Proxy Files from Git Repositry
	 * @throws ParseException
	 * @throws SQLException
	 */

	private String directoryURLVerifiedsharedgit = "";
	private String finalDirectoryPath="";

	@RequestMapping("/gitupload")
	public ResponseEntity<String> insert(@RequestParam(value = "gitUrl") String gitUrl,
			@RequestParam(value = "username") String userName, @RequestParam(value = "password") String pw,
			@RequestParam(value = "folder") String folderName, @RequestParam(value = "projectId") String projectId,
			HttpSession session) throws InvalidRemoteException, TransportException, GitAPIException, IOException,
			ZipException, SQLException, ParseException {
		String Url = gitUrl;
		String username = userName;
		String password = pw;
		String projectName = folderName;
		// String repoUrl=Url+"/"+projectName;
		// Random rnd = new Random();
		SecureRandom rnd = new SecureRandom();
		String inputUser = (String) session.getAttribute("username");
		Integer userId = (Integer) session.getAttribute("userId");

		String destination = System.getProperty(tempDirPath) + rnd.nextInt();

		try {
			if (Url != null) {
				if ((username != null) && (password != null)) {
					CloneCommand cloneCommand = Git.cloneRepository();
					cloneCommand.setURI(Url);
					cloneCommand.setDirectory(Paths.get(destination).toFile());
					cloneCommand
							.setCredentialsProvider(new UsernamePasswordCredentialsProvider("username", "password"));
					cloneCommand.call();
				}
			}
			// String finalDirectoryPath=tempDirectoryPath+"API"+random.nextInt();
			finalDirectoryPath = System.getProperty(tempDirPath) + projectName + rnd.nextInt();

			if (projectName.contains(".")) {
				unzipFile(destination, finalDirectoryPath, projectName);
				directoryURLVerified = uploadController.findDir(new File(finalDirectoryPath + File.separator),
						"apiproxy");

			} else {

				directoryURLVerified = uploadController.findDir(new File(destination + File.separator + projectName),
						"apiproxy");
				finalDirectoryPath = destination + File.separator + projectName;
			}
			if (directoryURLVerified != null) {
				String resultString = null;
				try {
					resultString = codeAnalysis.listFiles(directoryURLVerified, folderName, inputUser,
							finalDirectoryPath, userId, projectId, session);
					if (resultString.length() == 0) {
						return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
					} else if (resultString == "error in shared flow") {
						//String response = "{\"errorMsg\" : \"error in shared flow\"}";
						String errorMsgPolicyFile=(String) session.getAttribute("policyFileName");
						String response = "{\"errorMsg\" : \"error in shared flow\",\"errorMsgfilepath\" : \""+errorMsgPolicyFile+"\"}";
						return new ResponseEntity<String>(response, HttpStatus.OK);
					}
				} catch (ParserConfigurationException | SAXException | IOException e) {
					return new ResponseEntity<String>("Successfully uploaded - " + "", HttpStatus.NOT_FOUND);
				}

				return new ResponseEntity<String>(resultString, HttpStatus.OK);

				// return new ModelAndView("finalJsonView", "message", resultString);
			} else {
				return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
			}
		} finally {
		}
	}

	/**
	 * @param tempDirectoryPath
	 * @param finalDirectoryPath
	 * @param folderName
	 * @throws IOException
	 * @throws ZipException Unzip each and evry File
	 */
	private void unzipFile(String originPath, String finalDirectoryPath, String projectName)
			throws IOException, ZipException {
		// String zipFile1 = originPath+"\\"+projectName+".zip";
		String zipFile1 = originPath + File.separator + projectName;
		File f = new File(zipFile1);
		ZipFile zipFile = null;
		try {
			zipFile = new ZipFile(f);
		} catch (ZipException e) {
			logger.error("error found in method unzipFile :", e);

		}
		zipFile.extractAll(finalDirectoryPath);

	}

	@RequestMapping("/gituploadshared")
	public ResponseEntity<String> insertsharedgit(@RequestParam(value = "gitUrl") String gitUrl,
			@RequestParam(value = "username") String userName, @RequestParam(value = "password") String pw,
			@RequestParam(value = "folder") String folderName,
			@RequestParam(value = "projectId") String projectId, HttpSession session)
			throws InvalidRemoteException, TransportException, GitAPIException, IOException, ZipException, SQLException,
			ParseException {
		String Url = gitUrl;
		String username = userName;
		String password = pw;
		String projectName = folderName;
		//String projectNamenoext=FilenameUtils.getBaseName(projectName);
		//projectName=FilenameUtils.getBaseName(projectName);
		// String repoUrl=Url+"/"+projectName;
		// Random rnd = new Random();
		SecureRandom rnd = new SecureRandom();
		String inputUser = (String) session.getAttribute("username");
		Integer userId = (Integer) session.getAttribute("userId");

		String destination = System.getProperty(tempDirPath) + rnd.nextInt();
		String finalDirectoryPath1="";

		try {
			if (Url != null) {
				if ((username != null) && (password != null)) {
					CloneCommand cloneCommand = Git.cloneRepository();
					cloneCommand.setURI(Url);
					cloneCommand.setDirectory(Paths.get(destination).toFile());
					cloneCommand
							.setCredentialsProvider(new UsernamePasswordCredentialsProvider("username", "password"));
					cloneCommand.call();
				}
			}
			
			//String finalDirectoryPath = System.getProperty(tempDirPath) + projectName + rnd.nextInt();
			finalDirectoryPath1 = System.getProperty(tempDirPath) + projectName + rnd.nextInt() + File.separator + projectName;
			 //String finalDirectoryPath = System.getProperty(tempDirPath) + projectName + rnd.nextInt() + File.separator + projectName.getOriginalFilename().substring(0,projectName.getOriginalFilename().indexOf("."));
			
			if (projectName.contains(".")) {
				
				finalDirectoryPath1 = System.getProperty(tempDirPath) + FilenameUtils.getBaseName(projectName) + rnd.nextInt() + File.separator + FilenameUtils.getBaseName(projectName);
				unzipFile(destination, finalDirectoryPath1, projectName);
				//directoryURLVerifiedsharedgit = uploadController.findDir(new File(finalDirectoryPath + File.separator),
						//env.getProperty("SHARED_FLOW_BUNDLE"));
				directoryURLVerifiedsharedgit= finalDirectoryPath1;

			} else {

				directoryURLVerifiedsharedgit = uploadController.findDir(
						new File(destination + File.separator + projectName), env.getProperty("SHARED_FLOW_BUNDLE"));
				finalDirectoryPath1 = destination + File.separator + projectName;
			}
			if (directoryURLVerifiedsharedgit != null) {
				String resultString = null;
				//directoryURLVerifiedsharedgit=FilenameUtils.getBaseName(projectName);
				File s = new File(directoryURLVerifiedsharedgit);
				String filePath = (String) session.getAttribute("directoryName");
				File filepathshared=new File((String) session.getAttribute("directoryName"));
				String filePath1= filepathshared.getParent();
				

				try {
					

					copyFiles(s.getParentFile(), filePath1); // src, dest
					
					// fileName = file.getOriginalFilename();
					resultString = codeAnalysis.listFiles(directoryURLVerified, folderName, inputUser,
							finalDirectoryPath, userId, projectId, session);
					if (resultString.length() == 0) {
						return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
					} else if (resultString == "error in shared flow") {
						//String response = "{\"errorMsg\" : \"error in shared flow\"}";
						String errorMsgPolicyFile=(String) session.getAttribute("policyFileName");
						String response = "{\"errorMsg\" : \"error in shared flow\",\"errorMsgfilepath\" : \""+errorMsgPolicyFile+"\"}";
						return new ResponseEntity<String>(response, HttpStatus.OK);
					}
				} catch (ParserConfigurationException | SAXException | IOException e) {
					return new ResponseEntity<String>("Successfully uploaded - " + "", HttpStatus.NOT_FOUND);
				}

				return new ResponseEntity<String>(resultString, HttpStatus.OK);

				// return new ModelAndView("finalJsonView", "message", resultString);
			} else {
				return new ResponseEntity<String>("", HttpStatus.NOT_FOUND);
			}
		} finally {
		}
		
		
	}
	public void copyFiles(File fileDirectory, String fileDirectoryName) throws IOException {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			//new File("/fileDirectory/sharedflowbundle").mkdirs();
			
			/*
			 * File folder_shared = new File(fileDirectory + "\\" + "sharedflowbundle");
			 * folder_shared.mkdir();
			 */
			/*
			 * if(!fileDirectory.isFile()) { fileDirectory.mkdir(); }
			 */
			if (fileDirectory.listFiles() != null) {
				File[] filesArr = fileDirectory.listFiles();
				for (File file : filesArr) {
					if (file.isDirectory()) {
						File folder = new File(fileDirectoryName + "\\" + file.getName());
						folder.mkdir();
						copyFiles(file, folder.getCanonicalPath());
					} else if (file.isFile()) {
						fis = new FileInputStream(file);
						fos = new FileOutputStream(fileDirectoryName + "\\" + file.getName());
						int count = 0;
						while ((count = fis.read()) != -1) {
							fos.write(count);
						}
					}
				}
			} else {
				if (fileDirectory.isFile()) {
					fis = new FileInputStream(fileDirectory);
					fos = new FileOutputStream(fileDirectoryName + "\\" + fileDirectory.getName());
					int count = 0;
					while ((count = fis.read()) != -1) {
						fos.write(count);
					}
				}
			}
		} catch (IOException ioexp) {
			ioexp.printStackTrace();
		} finally {
			if (fis != null && fos != null) {
				fis.close();
				fos.close();
			}
		}
	}
}
