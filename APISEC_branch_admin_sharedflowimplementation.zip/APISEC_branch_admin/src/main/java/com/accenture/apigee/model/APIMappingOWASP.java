package com.accenture.apigee.model;

/**
 * @author kanchan.khushboo
 *
 */
public class APIMappingOWASP {
	private String injection;
	private String brokenAuthentication;
	private String sensitiveDataExposure;
	
	private String xmlExternalEntity;
	private String brokenAcessControl;
	private String securityMisconfiguration;
	
	private String crossSiteScripting;
	private String insecureDeserialization;
	private String usingComponent;
	
	private String insufficientLoggingMonitoring;
	
	
	private static  APIMappingOWASP apiMappingOWASP;
	
	
	public static APIMappingOWASP getApiMappingOWASP() {
		if (apiMappingOWASP == null) {
			apiMappingOWASP = new APIMappingOWASP();
		}
		return apiMappingOWASP;
	}
	
	public static APIMappingOWASP getApiMappingOWASP(boolean reset) {
		if (apiMappingOWASP == null) {
			apiMappingOWASP = new APIMappingOWASP();
		}
		return apiMappingOWASP;
	}

	public String getInjection() {
		return injection;
	}

	public void setInjection(String injection) {
		this.injection = injection;
	}

	public String getBrokenAuthentication() {
		return brokenAuthentication;
	}

	public void setBrokenAuthentication(String brokenAuthentication) {
		this.brokenAuthentication = brokenAuthentication;
	}

	public String getSensitiveDataExposure() {
		return sensitiveDataExposure;
	}

	public void setSensitiveDataExposure(String sensitiveDataExposure) {
		this.sensitiveDataExposure = sensitiveDataExposure;
	}

	public String getXmlExternalEntity() {
		return xmlExternalEntity;
	}

	public void setXmlExternalEntity(String xmlExternalEntity) {
		this.xmlExternalEntity = xmlExternalEntity;
	}

	public String getBrokenAcessControl() {
		return brokenAcessControl;
	}

	public void setBrokenAcessControl(String brokenAcessControl) {
		this.brokenAcessControl = brokenAcessControl;
	}

	public String getSecurityMisconfiguration() {
		return securityMisconfiguration;
	}

	public void setSecurityMisconfiguration(String securityMisconfiguration) {
		this.securityMisconfiguration = securityMisconfiguration;
	}

	public String getCrossSiteScripting() {
		return crossSiteScripting;
	}

	public void setCrossSiteScripting(String crossSiteScripting) {
		this.crossSiteScripting = crossSiteScripting;
	}

	public String getInsecureDeserialization() {
		return insecureDeserialization;
	}

	public void setInsecureDeserialization(String insecureDeserialization) {
		this.insecureDeserialization = insecureDeserialization;
	}

	public String getUsingComponent() {
		return usingComponent;
	}

	public void setUsingComponent(String usingComponent) {
		this.usingComponent = usingComponent;
	}

	public String getInsufficientLoggingMonitoring() {
		return insufficientLoggingMonitoring;
	}

	public void setInsufficientLoggingMonitoring(String insufficientLoggingMonitoring) {
		this.insufficientLoggingMonitoring = insufficientLoggingMonitoring;
	}
	
	
	

}
