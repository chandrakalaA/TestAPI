package com.accenture.apigee.model;

import java.util.ArrayList;

public class AdminUserDTO {
	private String projectId;
	private String projectName;
	private String projectType;
//	private String userId;
	private Integer projectAdminId;
	private String projectAdminName;
	private String projectUserId;
	private String projectUserName;
//	private String userName;
	private Boolean rowSelect;
	private String createDate;
	private String policyName;
	private String policyFileName;
	private String policyWeight;
	private String policyModifiedWeight;
	private String groupName;
	private ArrayList<AdminUserDTO> projectAdminList=new ArrayList<AdminUserDTO>();
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}			
	public ArrayList<AdminUserDTO> getProjectAdminList() {
		return projectAdminList;
	}
	public void setProjectAdminList(ArrayList<AdminUserDTO> projectAdminList) {
		this.projectAdminList = projectAdminList;
	}
	public Integer getProjectAdminId() {
		return projectAdminId;
	}
	public void setProjectAdminId(Integer projectAdminId) {
		this.projectAdminId = projectAdminId;
	}
	public String getProjectAdminName() {
		return projectAdminName;
	}
	public void setProjectAdminName(String projectAdminName) {
		this.projectAdminName = projectAdminName;
	}
	public String getProjectUserId() {
		return projectUserId;
	}
	public void setProjectUserId(String projectUserId) {
		this.projectUserId = projectUserId;
	}
	public String getProjectUserName() {
		return projectUserName;
	}
	public void setProjectUserName(String projectUserName) {
		this.projectUserName = projectUserName;
	}
	public Boolean getRowSelect() {
		return rowSelect;
	}
	public void setRowSelect(Boolean rowSelect) {
		this.rowSelect = rowSelect;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyFileName() {
		return policyFileName;
	}
	public void setPolicyFileName(String policyFileName) {
		this.policyFileName = policyFileName;
	}
	public String getPolicyWeight() {
		return policyWeight;
	}
	public void setPolicyWeight(String policyWeight) {
		this.policyWeight = policyWeight;
	}
	public String getPolicyModifiedWeight() {
		return policyModifiedWeight;
	}
	public void setPolicyModifiedWeight(String policyModifiedWeight) {
		this.policyModifiedWeight = policyModifiedWeight;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}		
}
