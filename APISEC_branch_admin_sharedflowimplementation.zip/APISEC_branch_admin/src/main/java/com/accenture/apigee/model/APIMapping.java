package com.accenture.apigee.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * @author kanchan.khushboo
 *
 */
@Component
@PropertySource("classpath:apisecConfig.properties")
public class APIMapping {	
	
	@Autowired
	Environment env;

	public APIMapping() {

	}

	/**
	 * Reading owasp JSON File and current Report JSON file and compare if policy is enabled,
	 * then it will check specific policy belongs to which Threat.
	 * @param codeAnalysisReportDTO
	 * @param jsonAbsolutePath
	 * @throws ParseException
	 * @throws IOException
	 */
	public void getMappingAPI(CodeAnalysisReportDTO codeAnalysisReportDTO) throws IOException, ParseException {
		ArrayList<String> policyEnabledList=new ArrayList<String>();
		if(codeAnalysisReportDTO.getPolicyMap()!=null && codeAnalysisReportDTO.getPolicyMap().size()>0) {
			for(ArrayList<PolicyModelClass> policyModelClassList:codeAnalysisReportDTO.getPolicyMap().values()) {
				for(PolicyModelClass policyModelClass:policyModelClassList) {
					if(policyModelClass.isEnabled()) {
						policyEnabledList.add(policyModelClass.getPolicyName());
					}
				}
			}
		}
		if(codeAnalysisReportDTO.getApiMappingOWASP()==null) {
			codeAnalysisReportDTO.setApiMappingOWASP(new APIMappingOWASP());
		}

		String owaspJsonPath = "";
		ClassLoader classLoader = getClass().getClassLoader();
		if (classLoader.getResource(env.getProperty("OWASP_TOP_10_FOLDER")) != null) {
			owaspJsonPath = classLoader.getResource(env.getProperty("OWASP_TOP_10_FOLDER")).getPath();
		}
		// owaspJsonPath = "src\\main\\resources\\owaspTop10\\owaspMapping.json";

		if (owaspJsonPath.contains("/")) {
			owaspJsonPath = owaspJsonPath + "/" + env.getProperty("OWASP_MAPPING_FILE") + env.getProperty("JSON_EXTN");

		} else if (owaspJsonPath.contains("\"")) {
			owaspJsonPath = owaspJsonPath + "\"" + env.getProperty("OWASP_MAPPING_FILE") + env.getProperty("JSON_EXTN");

		}

		if (owaspJsonPath != null && owaspJsonPath.length() > 0) {
			FileReader fileReader = new FileReader(owaspJsonPath);
			BufferedReader br = new BufferedReader(fileReader);
			JSONParser parser = new JSONParser();
			JSONObject mappingJsonObj = (JSONObject) parser.parse(br);

			// Injection
			JSONArray injectionList = (JSONArray) mappingJsonObj.get(env.getProperty("A1_INJECTION"));

			int i = 0;			
			if (injectionList.size() > 0) {
				int count = 0;
				for (i = 0; i < injectionList.size(); i++) {
					String injectPolicies = (String) injectionList.get(i);
					if(policyEnabledList.contains(injectPolicies)) {
						count++;
					}					
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setInjection("true");					
				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setInjection("false");

				}
			}

			// BrokenAuthenticationAndSessionManagement

			JSONArray brokenAuthList = (JSONArray) mappingJsonObj.get(env.getProperty("A2_BROKENAUTH"));
			if (brokenAuthList.size() > 0) {
				int count = 0;
				for (i = 0; i < brokenAuthList.size(); i++) {
					String brokenPolicies = (String) brokenAuthList.get(i);
					if(policyEnabledList.contains(brokenPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setBrokenAuthentication("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setBrokenAuthentication("false");

				}
			}
			// SensitiveDataExposure

			JSONArray sensitiveDataList = (JSONArray) mappingJsonObj.get(env.getProperty("A3_SENSITIVE_DATA_EXP"));
			if (sensitiveDataList.size() > 0) {
				int count = 0;
				for (i = 0; i < sensitiveDataList.size(); i++) {
					String sensitivePolicies = (String) sensitiveDataList.get(i);
					if(policyEnabledList.contains(sensitivePolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setSensitiveDataExposure("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setSensitiveDataExposure("false");

				}
			}

			// XMLExternalEntities
			JSONArray xmlExtrnalEntitiesList = (JSONArray) mappingJsonObj.get(env.getProperty("A4_XML_ENTITY"));
			if (xmlExtrnalEntitiesList.size() > 0) {
				int count = 0;
				for (i = 0; i < xmlExtrnalEntitiesList.size(); i++) {
					String xmlExtrnalPolicies = (String) xmlExtrnalEntitiesList.get(i);
					if(policyEnabledList.contains(xmlExtrnalPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setXmlExternalEntity("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setXmlExternalEntity("false");

				}
			}

			// BrokenAccessControl

			JSONArray brokenAccessList = (JSONArray) mappingJsonObj.get(env.getProperty("A5_BROKEN_ACCESS"));
			if (brokenAccessList.size() > 0) {
				int count = 0;
				for (i = 0; i < brokenAccessList.size(); i++) {
					String brokenAccessPolicies = (String) brokenAccessList.get(i);
					if(policyEnabledList.contains(brokenAccessPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setBrokenAcessControl("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setBrokenAcessControl("false");

				}
			}

			// SecurityMisconfiguration

			JSONArray securityMisconfgList = (JSONArray) mappingJsonObj.get(env.getProperty("A6_SECURITY_MISCONFIG"));
			if (securityMisconfgList.size() > 0) {
				int count = 0;
				for (i = 0; i < securityMisconfgList.size(); i++) {
					String securityMisconfgPolicies = (String) securityMisconfgList.get(i);
					if(policyEnabledList.contains(securityMisconfgPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setSecurityMisconfiguration("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setSecurityMisconfiguration("false");

				}
			}


			// Cross-SiteScripting
			JSONArray crossSiteScriptingList = (JSONArray) mappingJsonObj.get(env.getProperty("A7_XSS"));
			if (crossSiteScriptingList.size() > 0) {
				int count = 0;
				for (i = 0; i < crossSiteScriptingList.size(); i++) {
					String crossSiteScrptPolicices = (String) crossSiteScriptingList.get(i);
					if(policyEnabledList.contains(crossSiteScrptPolicices)) {
						count++;
					}
				}								
				
				if (count == i){
					codeAnalysisReportDTO.getApiMappingOWASP().setCrossSiteScripting("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setCrossSiteScripting("false");

				}
			}
			
			// InsecureDeserialization
			JSONArray insecureDeserList = (JSONArray) mappingJsonObj.get(env.getProperty("A8_INSECURE_DESERIAL"));
			if (insecureDeserList.size() > 0) {
				int count = 0;
				for (i = 0; i < insecureDeserList.size(); i++) {
					String insecureDeserPolicies = (String) insecureDeserList.get(i);
					if(policyEnabledList.contains(insecureDeserPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setInsecureDeserialization("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setInsecureDeserialization("false");

				}
			}

			// UsingComponentsWithKnownVulnerabilities

			JSONArray usingComponentsList = (JSONArray) mappingJsonObj
					.get(env.getProperty("A9_KNOWN_VUL"));
			if (usingComponentsList.size() > 0) {
				int count = 0;
				for (i = 0; i < usingComponentsList.size(); i++) {
					String usingComponentsPolicies = (String) usingComponentsList.get(i);
					if(policyEnabledList.contains(usingComponentsPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP().setUsingComponent("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP().setUsingComponent("false");

				}
			}

			// InsufficientLogging&Monitoring
			JSONArray insufficientLoggMonitorList = (JSONArray) mappingJsonObj
					.get(env.getProperty("A10_INSUFF_LOG"));
			if (insufficientLoggMonitorList.size() > 0) {
				int count = 0;
				for (i = 0; i < insufficientLoggMonitorList.size(); i++) {
					String insufficientLoggMonitorPolicies = (String) insufficientLoggMonitorList.get(i);
					if(policyEnabledList.contains(insufficientLoggMonitorPolicies)) {
						count++;
					}
				}
				if (count == i) {
					codeAnalysisReportDTO.getApiMappingOWASP()
							.setInsufficientLoggingMonitoring("true");

				} else {
					codeAnalysisReportDTO.getApiMappingOWASP()
							.setInsufficientLoggingMonitoring("false");

				}
			}

		}
	}

}
	
