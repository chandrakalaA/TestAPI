package com.accenture.apigee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.accenture.apigee.main.MySqlConnection;
import com.accenture.apigee.model.PolicyDetailsDTO;

/**
 * @author kanchan.khushboo
 *
 */
@Repository
public class PolicyDetailsDAOImpl {
	
	@Autowired
	MySqlConnection mySqlConn;
	
	final Logger logger = LoggerFactory.getLogger(PolicyDetailsDAOImpl.class);
	
	public MySqlConnection getMySqlConn() {
		return mySqlConn;
	}

	public void setMySqlConn(MySqlConnection mySqlConn) {
		this.mySqlConn = mySqlConn;
	}

	public boolean savePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
		Connection connection = null;
		PreparedStatement stmt = null;		
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("INSERT INTO policydetails VALUES (?,?,?,?,?)");			
			for(PolicyDetailsDTO policyDetailsDTO:policyDetailsList) {
				if(policyDetailsDTO.getIspolicySelected()) {
					stmt.setString(1, policyDetailsDTO.getProjectId());
					stmt.setInt(2, policyDetailsDTO.getPolicyGroupId());
					stmt.setString(3, policyDetailsDTO.getPolicyName());
					stmt.setInt(4, policyDetailsDTO.getPolicyModifiedWeight());
					stmt.setString(5, policyDetailsDTO.getCreateDate());
					stmt.addBatch();
				}				
			}			
			stmt.executeBatch();			
		} catch (SQLException e) {
			logger.error("************savePolicyDetails************", e);
			return false;
		}finally {			
			if(connection!=null)
				MySqlConnection.close(connection);
			if(stmt!=null) {
				stmt.close();
			}
		}
		return true;
	}
	
	public boolean updatePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
		Connection connection = null;
		PreparedStatement stmt = null;		
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("update policydetails set modifiedWeight=?, createDate=?, policyGroupId=? where projectId=? and policyName=?");			
			for(PolicyDetailsDTO policyDetailsDTO:policyDetailsList) {				
				stmt.setInt(1, policyDetailsDTO.getPolicyModifiedWeight());
				stmt.setString(2, policyDetailsDTO.getCreateDate());
				stmt.setInt(3, policyDetailsDTO.getPolicyGroupId());
				stmt.setString(4, policyDetailsDTO.getProjectId());
//				stmt.setInt(2, policyDetailsDTO.getPolicyGroupId());
				stmt.setString(5, policyDetailsDTO.getPolicyName());				
				stmt.addBatch();
			}			
			stmt.executeBatch();			
		} catch (SQLException e) {
			logger.error("************savePolicyDetails************", e);
			return false;
		}finally {			
			if(connection!=null)
				MySqlConnection.close(connection);
			if(stmt!=null) {
				stmt.close();
			}
		}
		return true;
	}
	
	public boolean deletePolicyDetails(ArrayList<PolicyDetailsDTO> policyDetailsList) throws SQLException {
		Connection connection = null;
		PreparedStatement stmt = null;		
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("delete from policydetails where projectId=? and policyName=?");			
			for(PolicyDetailsDTO policyDetailsDTO:policyDetailsList) {				
				stmt.setString(1, policyDetailsDTO.getProjectId());
				stmt.setString(2, policyDetailsDTO.getPolicyName());				
				stmt.addBatch();
			}			
			stmt.executeBatch();			
		} catch (SQLException e) {
			logger.error("************savePolicyDetails************", e);
			return false;
		}finally {			
			if(connection!=null)
				MySqlConnection.close(connection);
			if(stmt!=null) {
				stmt.close();
			}
		}
		return true;
	}
	
	public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyDetails(String projectId) throws SQLException {
		/*ArrayList<PolicyDetailsDTO> projectUserList = new ArrayList<PolicyDetailsDTO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select * from policydetails where projectId=?");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();				
				policyDetailsDTO.setProjectId(rs.getString("projectId"));
				policyDetailsDTO.setPolicyGroupName(rs.getString("policyGroupName"));
				policyDetailsDTO.setPolicyFileName(rs.getString("policyName"));
				policyDetailsDTO.setPolicyModifiedWeight(rs.getInt("modifiedWeight"));			
				policyDetailsDTO.setCreateDate(rs.getString("createDate"));
				projectUserList.add(policyDetailsDTO);
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return projectUserList;*/
		
		Map<String, ArrayList<PolicyDetailsDTO>> policyMap=new LinkedHashMap<String, ArrayList<PolicyDetailsDTO>>();
		ArrayList<PolicyDetailsDTO> projectUserList = null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement(" select policymapping.*,policydetails.policyName policyNamePresent, policydetails.projectId, policydetails.modifiedWeight, policydetails.createDate policyDetCreateDate, policygroup.policyGroupName from policymapping left join policygroup on policymapping.policyGroupId=policygroup.policyGroupId left join policydetails on policymapping.policyName=policydetails.policyName and policydetails.projectId=?");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();	
				policyDetailsDTO.setProjectId(rs.getString("projectId"));
				policyDetailsDTO.setPolicyName(rs.getString("policyName"));				
				policyDetailsDTO.setPolicyFileName(rs.getString("policyFileName"));
				policyDetailsDTO.setPolicyWeight(rs.getString("weight"));		
				if(rs.getString("policyDetCreateDate")!=null) {
					policyDetailsDTO.setCreateDate(rs.getString("policyDetCreateDate"));
				}else
					policyDetailsDTO.setCreateDate(rs.getString("createDate"));
				policyDetailsDTO.setPolicyGroupId(rs.getInt("policyGroupId"));
				policyDetailsDTO.setPolicyGroupName(rs.getString("policyGroupName"));
				if(rs.getString("policyNamePresent")==null) {
					policyDetailsDTO.setIspolicySelected(false);
				}
				
				policyDetailsDTO.setPolicyModifiedWeight(rs.getInt("modifiedWeight"));
				if(policyDetailsDTO.getPolicyModifiedWeight()==null) { // If the Project does not contain this policy then, assing 0 to policymodifiedweight
					policyDetailsDTO.setPolicyModifiedWeight(0);
				}
				if(!policyMap.containsKey(policyDetailsDTO.getPolicyGroupName())) {
					projectUserList=new ArrayList<PolicyDetailsDTO>();
					projectUserList.add(policyDetailsDTO);
					policyMap.put(policyDetailsDTO.getPolicyGroupName(), projectUserList);
				}else {
					policyMap.get(policyDetailsDTO.getPolicyGroupName()).add(policyDetailsDTO);
				}
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyMappingDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return policyMap;
	}
	
	public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyMappingDetails() throws SQLException {
		Map<String, ArrayList<PolicyDetailsDTO>> policyMap=new LinkedHashMap<String, ArrayList<PolicyDetailsDTO>>();
		ArrayList<PolicyDetailsDTO> projectUserList = null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select policymapping.*, policygroup.policyGroupName from policymapping left join policygroup on policymapping.policyGroupId=policygroup.policyGroupId");
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();				
				policyDetailsDTO.setPolicyName(rs.getString("policyName"));				
				policyDetailsDTO.setPolicyFileName(rs.getString("policyFileName"));
				policyDetailsDTO.setPolicyWeight(rs.getString("weight"));			
				policyDetailsDTO.setCreateDate(rs.getString("createDate"));
				policyDetailsDTO.setPolicyGroupId(rs.getInt("policyGroupId"));
				policyDetailsDTO.setPolicyGroupName(rs.getString("policyGroupName"));
				policyDetailsDTO.setPolicyModifiedWeight(Integer.parseInt(policyDetailsDTO.getPolicyWeight()));
				policyDetailsDTO.setIspolicySelected(true);
				if(!policyMap.containsKey(policyDetailsDTO.getPolicyGroupName())) {
					projectUserList=new ArrayList<PolicyDetailsDTO>();
					projectUserList.add(policyDetailsDTO);
					policyMap.put(policyDetailsDTO.getPolicyGroupName(), projectUserList);
				}else {
					policyMap.get(policyDetailsDTO.getPolicyGroupName()).add(policyDetailsDTO);
				}
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyMappingDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return policyMap;
	}
	
	public ArrayList<PolicyDetailsDTO> checkPolicyExistForProject(String projectId) throws SQLException {
		ArrayList<PolicyDetailsDTO> projectUserList = new ArrayList<PolicyDetailsDTO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select * from policydetails where projectId=?");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();				
				policyDetailsDTO.setProjectId(rs.getString("projectId"));
				policyDetailsDTO.setPolicyGroupId(rs.getInt("policyGroupId"));
				policyDetailsDTO.setPolicyName(rs.getString("policyName"));
				policyDetailsDTO.setPolicyModifiedWeight(rs.getInt("modifiedWeight"));			
				policyDetailsDTO.setCreateDate(rs.getString("createDate"));
				projectUserList.add(policyDetailsDTO);
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return projectUserList;		
	}
	
	public boolean isPolicyMappedForProject(String projectId) throws SQLException {		
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select 1 from policydetails where projectId=?");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}
		return false;		
	}
		
	public Map<String, PolicyDetailsDTO> fetchPolicydetailsForProject(String projectId) throws SQLException {		
		Map<String, PolicyDetailsDTO> policyDetailsMap = new LinkedHashMap<String, PolicyDetailsDTO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select policydetails.*,policygroup.policyGroupName, policyFileName, policyRisk, policyRefLink from policydetails left join policymapping on policydetails.policyName=policymapping.policyName left join policygroup on policydetails.policyGroupId=policygroup.policyGroupId where policydetails.projectId=?");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();				
				policyDetailsDTO.setPolicyName(rs.getString("policyName"));
				policyDetailsDTO.setPolicyFileName(rs.getString("policyFileName"));
				policyDetailsDTO.setPolicyRisk(rs.getString("policyRisk"));
				policyDetailsDTO.setPolicyRefLink(rs.getString("policyRefLink"));
				policyDetailsDTO.setPolicyModifiedWeight(Integer.parseInt(rs.getString("modifiedWeight")));							
				policyDetailsDTO.setPolicyGroupId(rs.getInt("policyGroupId"));
				policyDetailsDTO.setPolicyGroupName(rs.getString("policyGroupName"));				
				policyDetailsDTO.setIspolicySelected(true);								
				policyDetailsMap.put(policyDetailsDTO.getPolicyName(), policyDetailsDTO);
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyMappingDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return policyDetailsMap;
	}
	
	public Map<String, PolicyDetailsDTO> fetchPolicyMappingForScan() throws SQLException {		
		Map<String, PolicyDetailsDTO> policyDetailsMap = new LinkedHashMap<String, PolicyDetailsDTO>();
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select policygroup.policyGroupName, policymapping.* from policymapping left join policygroup on policymapping.policyGroupId=policygroup.policyGroupId");
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();				
				policyDetailsDTO.setPolicyName(rs.getString("policyName"));
				policyDetailsDTO.setPolicyFileName(rs.getString("policyFileName"));
				policyDetailsDTO.setPolicyRisk(rs.getString("policyRisk"));
				policyDetailsDTO.setPolicyRefLink(rs.getString("policyRefLink"));
				policyDetailsDTO.setPolicyModifiedWeight(Integer.parseInt(rs.getString("weight")));							
				policyDetailsDTO.setPolicyGroupId(rs.getInt("policyGroupId"));
				policyDetailsDTO.setPolicyGroupName(rs.getString("policyGroupName"));				
				policyDetailsDTO.setIspolicySelected(true);								
				policyDetailsMap.put(policyDetailsDTO.getPolicyName(), policyDetailsDTO);
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyMappingDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return policyDetailsMap;
	}
	
	public Map<String, ArrayList<PolicyDetailsDTO>> fetchPolicyMappingDetails(String projectId) throws SQLException {
		Map<String, ArrayList<PolicyDetailsDTO>> policyMap=null;
		if(projectId!=null) {
			policyMap=retrievePolicyMappingDetailsForProject(projectId);
			if(policyMap.size()==0) {
				policyMap=retrievePolicyMappingDetails();
			}			
		}else {
			policyMap=retrievePolicyMappingDetails();
		}		
		return policyMap;
	}
	
	public Map<String, ArrayList<PolicyDetailsDTO>> retrievePolicyMappingDetailsForProject(String projectId) throws SQLException {
		Map<String, ArrayList<PolicyDetailsDTO>> policyMap=new LinkedHashMap<String, ArrayList<PolicyDetailsDTO>>();
		ArrayList<PolicyDetailsDTO> projectUserList = null;
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try {
			connection = getMySqlConn().getConnectionInstance();
			stmt = connection
					.prepareStatement("select policymapping.policyFileName, policydetails.*, policygroup.policyGroupName from policydetails left join policymapping on policydetails.policyName=policymapping.policyName left join policygroup on policymapping.policyGroupId=policygroup.policyGroupId where policydetails.projectId=?");
			stmt.setString(1, projectId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				PolicyDetailsDTO policyDetailsDTO = new PolicyDetailsDTO();				
				policyDetailsDTO.setPolicyName(rs.getString("policyName"));				
				policyDetailsDTO.setPolicyFileName(rs.getString("policyFileName"));
				policyDetailsDTO.setPolicyModifiedWeight(rs.getInt("modifiedWeight"));							
				policyDetailsDTO.setPolicyGroupId(rs.getInt("policyGroupId"));
				policyDetailsDTO.setPolicyGroupName(rs.getString("policyGroupName"));				
				if(!policyMap.containsKey(policyDetailsDTO.getPolicyGroupName())) {
					projectUserList=new ArrayList<PolicyDetailsDTO>();
					projectUserList.add(policyDetailsDTO);
					policyMap.put(policyDetailsDTO.getPolicyGroupName(), projectUserList);
				}else {
					policyMap.get(policyDetailsDTO.getPolicyGroupName()).add(policyDetailsDTO);
				}
			}
		} catch (SQLException e) {
			logger.error("************retrievePolicyMappingDetails************", e);
		}finally {
			if(rs!=null)
				rs.close();
			if(connection!=null)
				MySqlConnection.close(connection);
		}

		return policyMap;
	}
}