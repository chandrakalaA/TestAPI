package com.accenture.apigee.model;

import java.io.Serializable;

public class JSTree_A_attr implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String style;
	private Boolean removeIcon=false;
	private Boolean editIcon=false;
	private String policyType;
	
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	public JSTree_A_attr(String style, Boolean removeIcon, Boolean editIcon, String policyType){
		this.style=style;
		this.editIcon=editIcon;
		this.removeIcon=removeIcon;
		this.policyType=policyType;
	}	
	public Boolean getRemoveIcon() {
		return removeIcon;
	}
	public void setRemoveIcon(Boolean removeIcon) {
		this.removeIcon = removeIcon;
	}
	public Boolean getEditIcon() {
		return editIcon;
	}
	public void setEditIcon(Boolean editIcon) {
		this.editIcon = editIcon;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	
	
	
}