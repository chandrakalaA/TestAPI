package com.accenture.apigee.model;

import java.util.ArrayList;

public class PreviousReportDTO {
	private String projectId;
	private String projectName;
	private String lastUpdated;
	private String[] trend=new String[3];
	private String prevReportLink;
	private String prevReportName;
	private String reportContent;
	private String versionId;
	private String currProjectId;
	private String currProjectLastUpdated;
	private String reportLocation;
	private ArrayList<PreviousReportDTO> previousReportList;
	private PreviousReportDTO previousReportRowData;
	private Integer vulCount;

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}	

	public String[] getTrend() {
		return trend;
	}

	public void setTrend(String[] trend) {
		this.trend = trend;
	}

	public String getPrevReportLink() {
		return prevReportLink;
	}

	public void setPrevReportLink(String prevReportLink) {
		this.prevReportLink = prevReportLink;
	}

	public String getPrevReportName() {
		return prevReportName;
	}

	public void setPrevReportName(String prevReportName) {
		this.prevReportName = prevReportName;
	}

	public String getReportContent() {
		return reportContent;
	}

	public void setReportContent(String reportContent) {
		this.reportContent = reportContent;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public String getCurrProjectId() {
		return currProjectId;
	}

	public void setCurrProjectId(String currProjectId) {
		this.currProjectId = currProjectId;
	}

	public String getCurrProjectLastUpdated() {
		return currProjectLastUpdated;
	}

	public void setCurrProjectLastUpdated(String currProjectLastUpdated) {
		this.currProjectLastUpdated = currProjectLastUpdated;
	}

	public String getReportLocation() {
		return reportLocation;
	}

	public void setReportLocation(String reportLocation) {
		this.reportLocation = reportLocation;
	}

	public ArrayList<PreviousReportDTO> getPreviousReportList() {
		return previousReportList;
	}

	public void setPreviousReportList(ArrayList<PreviousReportDTO> previousReportList) {
		this.previousReportList = previousReportList;
	}

	public PreviousReportDTO getPreviousReportRowData() {
		return previousReportRowData;
	}

	public void setPreviousReportRowData(PreviousReportDTO previousReportRowData) {
		this.previousReportRowData = previousReportRowData;
	}

	public Integer getVulCount() {
		return vulCount;
	}

	public void setVulCount(Integer vulCount) {
		this.vulCount = vulCount;
	}

}
