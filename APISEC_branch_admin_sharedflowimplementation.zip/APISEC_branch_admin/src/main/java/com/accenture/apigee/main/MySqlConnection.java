package com.accenture.apigee.main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


/**
 * @author kanchan.khushboo
 *
 */
@Component
@PropertySource("classpath:application.properties")

public  class MySqlConnection {

	final static Logger logger = LoggerFactory.getLogger(MySqlConnection.class);
	public Connection conn;
    public static MySqlConnection dbInstance;
    private  String url;    
    private  String userName ;
    private  String password;
    private  String driver ;
	
	@Autowired
	public MySqlConnection(@Value("${MYSQL_DRIVER}") String mySqldDriver, @Value("${PASSWORD}") String dbPassword,@Value("${USER_NAME}") String dbUsername,@Value("${LOCAL_HOST}") String localhost){
		url= localhost;
		userName = dbUsername;
		password = dbPassword;
		driver = mySqldDriver;

	}

    public MySqlConnection() {}


    /** Get the db property Values from application.properties path
     * @return
     */
    public  Connection getConnectionInstance() {
    	Properties prop=new Properties();
    	prop.put("user", userName);
    	prop.put("password", password);    	
    	Connection connection = null;
    	try {
    		Class.forName(driver);
    	} catch (ClassNotFoundException e) {
    		logger.error("error in getConnectionInstance:",e);
    	}
    	try {
    		connection = DriverManager.getConnection(url,prop);
    	} catch (SQLException e) {    		    		
			logger.error("error in getConnectionInstance:",e);
    	}    	 
		return connection;
    }
    
    
 
    
    /** Close DBConnection
     * @param connection
     */
    public static void close(Connection connection)
    {
        try {
            if (connection != null) {
                connection.close();
                connection=null;
            }
        } catch (SQLException e) {            
			logger.error("error in close:",e);
        }
    }
  
	
}
