package com.accenture.apigee.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.stream.Stream;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.accenture.apigee.main.CodeAnalysis;
import com.accenture.apigee.model.PreviousReportDTO;

@Controller
public class PreviousReportController {
		
	@Autowired
	private CodeAnalysis codeAnalysis;
	

	public CodeAnalysis getCodeAnalysis() {
		return codeAnalysis;
	}

	public void setCodeAnalysis(CodeAnalysis codeAnalysis) {
		this.codeAnalysis = codeAnalysis;
	}	
	final Logger logger = LoggerFactory.getLogger(PreviousReportController.class);
	
	/**
	 * Reading report's json file and returning the same to display in UI
	 * @param reportFilePath - Contains report's Json file path
	 * @return - Json file content
	 * @throws IOException
	 */
	@RequestMapping(value = "/fetchReportContent", produces="text/plain")
	@ResponseBody
	private String readReportContent(@RequestParam("reportLocation") String reportFilePath) throws IOException {
		File reportFile=new File(reportFilePath);
		
		InputStream fis=null;
	
	Stream <String> s=Files.lines(Paths.get(reportFilePath));
	
			
		String line = "", jsonContent="";
		
		if(reportFile.exists()) 
		{
			StringBuilder jsonContent1=new StringBuilder();
			try {
				Files.lines(Paths.get(reportFilePath)).forEach(line1-> {jsonContent1.append(line1);
			
			});
			
		    return jsonContent1.toString();  
		    
			}
			
         catch(IOException e) {
				
        	 logger.error("error found in method readReportContent :",e);
			}finally {
				if (fis != null) {
					
					fis.close();
					
				}
			}
		}			
		return jsonContent;
	}
	
	
	/**
	 * Loading Previous Report from database based on logged-in userId and reading JSON report to display Trend value for each Authentication, InputValidation and Logging.
	 * @param session - Fetching logged-in userId from Session
	 * @return - List of PreviousReport to UI
	 * @throws IOException
	 * @throws SQLException
	 */
	@RequestMapping(value = "/loadPreviousReports")
	private ResponseEntity<ArrayList<PreviousReportDTO>> loadPreviousReports(HttpSession session) throws IOException, SQLException {
		
		String userName=(String)session.getAttribute("username");
		Integer userId = (Integer) session.getAttribute("userId");
		ArrayList<PreviousReportDTO> prevReportList = new ArrayList<PreviousReportDTO>();
		if(userName!=null) {
			LinkedHashMap<String, ArrayList<PreviousReportDTO>> reportmap=codeAnalysis.fetchPreviousReports(userId);
			if(reportmap.size()>0) {
				for(ArrayList<PreviousReportDTO> reportList:reportmap.values()) {
					if(reportList!=null) {
						PreviousReportDTO prevReportDTO = new PreviousReportDTO();
						prevReportDTO.setProjectId(reportList.get(0).getProjectId());
						prevReportDTO.setProjectName(reportList.get(0).getProjectName());
						prevReportDTO.setPreviousReportList(reportList);
						prevReportList.add(prevReportDTO);
					}
				}
			}
		}		
		return new ResponseEntity<ArrayList<PreviousReportDTO>>(prevReportList, HttpStatus.OK);
	}
}